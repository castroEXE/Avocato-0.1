# Colocando o Avocato no ar

Tempo estimado: 30 a 40 minutos. Tudo usa planos gratuitos.

| Parte | Onde roda | Plano grátis |
|---|---|---|
| Banco + login | Supabase | Free |
| API (`api/`) | Render (ou Railway) | Free (dorme após 15 min sem uso) |
| Site (`web/`) | Vercel | Hobby |
| IA | Groq (ou Google Gemini) | Free, sem cartão |

> Pré-requisitos: Node.js 20.9+ e o código no GitHub (o repositório guarda só o código; nada de `.env`).

---

## 1. Supabase: criar o projeto

1. Em <https://supabase.com>, crie um projeto (região **South America (São Paulo)**). Guarde a senha do banco.
2. Em **Authentication → URL Configuration**:
   - **Site URL**: o endereço do site (por enquanto `http://localhost:3000`; depois troque pelo da Vercel).
   - **Redirect URLs**: adicione `http://localhost:3000/entrar` e, depois, `https://SEU-SITE.vercel.app/entrar`.
3. Em **Authentication → Providers → Email**, deixe ativo. "Confirm email" ligado é o mais seguro (o usuário confirma pelo e-mail antes de entrar).

## 2. Aplicar as migrations (criar as tabelas)

Na pasta raiz do projeto:

```bash
npx supabase login
npx supabase link --project-ref SEU_PROJECT_REF   # o "ref" está na URL do painel
npx supabase db push
```

Isso aplica, em ordem, os arquivos de `supabase/migrations/`. Se preferir sem CLI, abra o **SQL Editor** e rode cada arquivo na ordem do nome.

## 3. Criar o usuário de banco da API

No **SQL Editor**, troque a senha e rode:

```sql
create role avocato_api login noinherit password 'UMA-SENHA-LONGA-E-ALEATORIA';
grant avocato_app, avocato_platform to avocato_api;
```

Por que isso: a API nunca usa a `service_role` nem o `postgres`. Ela entra com esse usuário limitado, e o Postgres (RLS) garante que uma empresa nunca veja dados de outra, mesmo se houver bug no código.

A string de conexão fica em **Project Settings → Database → Connection string → Session pooler**. Troque o usuário por `avocato_api.SEU_PROJECT_REF` e a senha pela que você criou:

```
postgresql://avocato_api.SEU_PROJECT_REF:SENHA@aws-0-sa-east-1.pooler.supabase.com:5432/postgres
```

## 4. Chave de IA gratuita

**Groq (recomendado):** entre em <https://console.groq.com>, faça login com Google ou GitHub, abra **API Keys → Create API Key** e copie a chave (`gsk_...`).

**Google Gemini (alternativa):** gere uma chave em <https://aistudio.google.com/apikey> e use `AI_PROVIDER=gemini`.

Os planos grátis têm limite de uso por minuto e por dia, de sobra para uma empresa pequena. Sem chave, o sistema funciona normalmente; só a tela do assistente mostra como configurar.

## 5. Rodar no seu computador

**API**

```bash
cd api
cp .env.example .env        # preencha DATABASE_URL, SUPABASE_URL, CORS_ORIGINS e AI_API_KEY
npm install
npm run dev                 # http://localhost:3333/health deve responder {"status":"ok"}
```

**Site**

```bash
cd web
cp .env.example .env.local  # URL e chave "publishable" (ou "anon") do Supabase + URL da API
npm install
npm run dev                 # http://localhost:3000
```

Abra o site, crie a conta, confirme o e-mail, crie a empresa e pronto.

## 6. Publicar

### API no Render

1. **New → Web Service** e conecte o repositório.
2. **Root Directory**: `api`.
3. **Build Command**: `npm ci && npm run build`.
4. **Start Command**: `npm start`.
5. **Environment**: as mesmas variáveis do `.env`, com `NODE_ENV=production` e `CORS_ORIGINS=https://SEU-SITE.vercel.app`.
6. Depois do deploy, teste `https://SUA-API.onrender.com/health`.

No plano grátis a API "dorme" sem uso e a primeira requisição demora uns 30 s. Para uso diário de uma empresa, o plano pago mais barato do Render ou do Railway resolve.

### Site na Vercel

1. **Add New → Project** e importe o repositório.
2. **Root Directory**: `web`. O framework é detectado como Next.js.
3. Em **Environment Variables**, defina:
   - `NEXT_PUBLIC_SUPABASE_URL`
   - `NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY`
   - `NEXT_PUBLIC_API_URL=https://SUA-API.onrender.com`
4. Faça o deploy e, no Supabase (passo 1.2), troque **Site URL** e **Redirect URLs** para o domínio da Vercel.

Seu link de pedidos para clientes fica em `https://SEU-SITE.vercel.app/solicitar/<slug-da-empresa>`. Ele está no card "Link de pedidos" do menu e em Configurações.

---

## Testes automatizados (opcional)

Os testes de integração precisam de um Postgres local:

```bash
cd api
TEST_DATABASE_URL=postgresql://avocato_api:SENHA@localhost:5432/avocato \
TEST_ADMIN_DATABASE_URL=postgresql://migrator:SENHA@localhost:5432/avocato \
npm test
```

O teste de isolamento entre empresas também pode rodar direto no banco: `supabase/tests/rls_isolation.sql`.

## Problemas comuns

| Sintoma | Causa provável |
|---|---|
| "Não foi possível falar com o servidor" | `NEXT_PUBLIC_API_URL` errado ou API dormindo/fora do ar. |
| Login funciona mas tudo dá erro 401 | `SUPABASE_URL` da API diferente do projeto do site. |
| Erro de CORS no navegador | Domínio do site faltando em `CORS_ORIGINS`. |
| "Confirme seu e-mail" | Normal com confirmação ligada: clique no link enviado pelo Supabase. |
| Assistente pede chave | `AI_API_KEY` vazia na API. Defina e reinicie. |
| `permission denied` na API | `DATABASE_URL` não está usando o usuário `avocato_api` do passo 3. |
