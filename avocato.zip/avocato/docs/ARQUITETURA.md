# Arquitetura

```
 Navegador ──► web/ (Next.js) ──HTTPS + JWT──► api/ (Fastify) ──► Postgres (Supabase)
     │                                            │                   RLS por empresa
     └──── login ────► Supabase Auth              └──► IA (Groq/Gemini, formato OpenAI)
```

## Princípios

- **O site só fala com a API.** O Supabase no navegador serve apenas para login. Toda regra de negócio fica na API, e é isso que permite um app de celular no futuro sem reescrever nada.
- **Isolamento no banco.** Cada requisição abre uma transação com `app.user_id` e `app.org_id`, e as políticas RLS (FORCE) só deixam ver linhas da empresa ativa, validada contra a tabela de vínculos. Chaves estrangeiras compostas `(org_id, id)` impedem misturar registros de empresas diferentes.
- **Permissões por papel**: Proprietário, Administrador, Gerente, Atendente e Profissional, mais módulos que cada empresa liga ou desliga.
- **Auditoria e eventos.** Toda escrita grava `audit_logs` (somente inserção) e um evento em `domain_events` (outbox) para automações futuras.
- **Dinheiro em centavos** (inteiros). A IA conversa em reais e a API converte.

## Fluxos automáticos

| Quando | O que acontece |
|---|---|
| Cliente envia o formulário público | Cliente reaproveitado por telefone/e-mail, OS "solicitada", notificação e evento. |
| OS concluída | Conta a receber criada (uma por OS) e última compra do cliente atualizada. |
| OS cancelada | Recebível em aberto cancelado. |
| Atendimento da agenda concluído | Conta a receber (se não estiver ligado a uma OS). |
| Conta fixa | Próximos lançamentos gerados de forma idempotente a cada consulta. |
| Baixa | Conta "Caixa" criada se não houver; transação registrada; status pago/parcial. |

## IA

- `api/src/ai/llm.ts`: cliente `/chat/completions` (Groq, Gemini ou qualquer endpoint compatível).
- `api/src/ai/assistant.ts`: até 6 rodadas de ferramentas por mensagem, histórico salvo, limite mensal do plano.
- `api/src/ai/tools/`: 16 ferramentas tipadas (Zod) com permissão e risco. As de risco "sensível" (excluir cliente, cancelar OS, dar baixa) viram pedidos de aprovação na tela do assistente.

## Pastas da API

```
api/src/
├── ai/               assistente, cliente de IA, ferramentas e aprovação
├── core/             contexto do tenant, erros, auditoria, eventos, RBAC
├── infra/            pool Postgres, contexto de transação, verificação de JWT
├── plugins/          auth (JWT) e tenant (X-Organization-Id)
└── modules/          customers, services, staff, service-orders, appointments,
                      finance, dashboard, notifications, profile, public,
                      organizations, me, admin
```
