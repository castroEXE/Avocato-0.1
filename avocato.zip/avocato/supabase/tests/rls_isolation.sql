-- =====================================================================
-- Teste de isolamento multi-tenant. Rode num banco descartável:
--   psql "$DATABASE_URL" -v ON_ERROR_STOP=1 -f supabase/tests/rls_isolation.sql
-- Cria duas empresas com donos diferentes e prova que uma não enxerga,
-- não altera e não referencia dados da outra. Tudo é desfeito no final.
-- =====================================================================
begin;

-- Usuários de teste (o trigger cria os profiles)
insert into auth.users (id, email, raw_user_meta_data) values
  ('00000000-0000-0000-0000-00000000000a', 'ana@a.test',   '{"full_name":"Ana"}'),
  ('00000000-0000-0000-0000-00000000000b', 'bruno@b.test', '{"full_name":"Bruno"}');

set local role avocato_app;

-- Ana cria a Empresa A
select set_config('app.user_id', '00000000-0000-0000-0000-00000000000a', true);
select set_config('app.org_a', app.create_organization('Pet Shop A', 'pet-shop-a')::text, true);
select set_config('app.org_id', current_setting('app.org_a'), true);
insert into app.customers (org_id, name, email) values (current_setting('app.org_a')::uuid, 'Cliente da A', 'c@a.test');

-- Bruno cria a Empresa B
select set_config('app.user_id', '00000000-0000-0000-0000-00000000000b', true);
select set_config('app.org_id', '', true);
select set_config('app.org_b', app.create_organization('Oficina B', 'oficina-b')::text, true);
select set_config('app.org_id', current_setting('app.org_b'), true);
insert into app.customers (org_id, name) values (current_setting('app.org_b')::uuid, 'Cliente da B');

do $$
declare
  n int;
  org_a uuid := current_setting('app.org_a')::uuid;
  org_b uuid := current_setting('app.org_b')::uuid;
  a_customer uuid;
begin
  -- 1. Bruno, no contexto da B, só vê o cliente da B
  select count(*) into n from app.customers;
  assert n = 1, format('B deveria ver 1 cliente, viu %s', n);
  select count(*) into n from app.customers where org_id = org_a;
  assert n = 0, 'B enxergou cliente da A';

  -- 2. Bruno tenta se colocar no contexto da A (sem membership) → nada
  perform set_config('app.org_id', org_a::text, true);
  assert app.current_org_id() is null, 'contexto da A aceito sem membership';
  select count(*) into n from app.customers;
  assert n = 0, format('B sem membership viu %s clientes', n);

  -- 3. Bruno tenta inserir na A → bloqueado pelo WITH CHECK
  begin
    insert into app.customers (org_id, name) values (org_a, 'invasor');
    assert false, 'insert cross-tenant passou';
  exception when insufficient_privilege then null;
  end;

  -- 4. Bruno lista empresas: só a dele
  select count(*) into n from app.organizations;
  assert n = 1, format('B deveria ver 1 empresa, viu %s', n);

  -- 5. Referência cruzada: mesmo no contexto da B, um agendamento não
  --    pode apontar para cliente da A (FK composta org_id + id)
  perform set_config('app.org_id', org_b::text, true);
  perform set_config('app.user_id', '00000000-0000-0000-0000-00000000000a', true);
  perform set_config('app.org_id', org_a::text, true);
  select id into a_customer from app.customers limit 1;
  perform set_config('app.user_id', '00000000-0000-0000-0000-00000000000b', true);
  perform set_config('app.org_id', org_b::text, true);
  begin
    insert into app.appointments (org_id, customer_id, starts_at, ends_at)
    values (org_b, a_customer, now(), now() + interval '1 hour');
    assert false, 'FK cruzada passou';
  exception when foreign_key_violation then null;
  end;

  -- 6. Audit log é append-only
  begin
    update app.audit_logs set action = 'x';
    assert false, 'audit_logs aceitou update';
  exception when insufficient_privilege then null;
  end;

  -- 7. Papéis padrão e permissões efetivas do owner
  select count(*) into n from app.roles;
  assert n = 5, format('esperava 5 papéis, achei %s', n);
  assert app.has_permission('finance.authorize_payment'), 'owner sem permissão total';

  -- 8. Pipeline padrão com 7 etapas
  select count(*) into n from app.pipeline_stages;
  assert n = 7, format('esperava 7 etapas, achei %s', n);

  -- 9. Margem calculada no banco: 180 − 50 − 20% de 180 = 94
  insert into app.services (org_id, name, price_cents, cost_cents, commission_rate)
  values (org_b, 'Instalação de tomada', 18000, 5000, 0.20);
  select margin_cents into n from app.services where name = 'Instalação de tomada';
  assert n = 9400, format('margem errada: %s', n);

  -- 10. Numeração de OS por empresa
  assert app.next_number('service_order') = 1, 'contador deveria começar em 1';
  assert app.next_number('service_order') = 2, 'contador deveria ser 2';

  -- 11. Agenda: o mesmo profissional não pode ter horários sobrepostos
  declare
    s uuid; c uuid;
  begin
    insert into app.staff_members (org_id, kind, name) values (org_b, 'employee', 'Carlos') returning id into s;
    select id into c from app.customers limit 1;
    insert into app.appointments (org_id, customer_id, staff_id, starts_at, ends_at)
    values (org_b, c, s, '2026-10-10 14:00-03', '2026-10-10 15:00-03');
    begin
      insert into app.appointments (org_id, customer_id, staff_id, starts_at, ends_at)
      values (org_b, c, s, '2026-10-10 14:30-03', '2026-10-10 15:30-03');
      assert false, 'agenda aceitou conflito';
    exception when exclusion_violation then null;
    end;
  end;

  raise notice 'RLS/isolamento: todos os 11 testes passaram';
end $$;

rollback;
