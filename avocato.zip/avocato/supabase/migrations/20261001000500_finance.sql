-- =====================================================================
-- AVOCATO · 0500 · Financeiro: contas bancárias, categorias,
-- contas a pagar/receber, recorrências, transações e a camada de
-- intenção de pagamento (BANKING INTEGRATION, seção 14).
-- Valores sempre em centavos (bigint). Nunca float para dinheiro.
-- =====================================================================

create table app.bank_accounts (
  id                    uuid primary key default gen_random_uuid(),
  org_id                uuid not null references app.organizations(id) on delete cascade,
  name                  text not null,
  kind                  text not null default 'checking'
                          check (kind in ('checking', 'savings', 'cash', 'payment_account', 'credit_card')),
  bank_name             text,
  currency              text not null default 'BRL',
  opening_balance_cents bigint not null default 0,
  -- Só referências externas. NUNCA senha, token ou credencial bancária.
  integration_id        uuid,
  external_account_ref  text,
  is_active             boolean not null default true,
  created_at            timestamptz not null default now(),
  updated_at            timestamptz not null default now(),
  unique (org_id, id)
);
select app.add_updated_at_trigger('app.bank_accounts');

create table app.financial_categories (
  id          uuid primary key default gen_random_uuid(),
  org_id      uuid not null references app.organizations(id) on delete cascade,
  name        text not null,
  direction   text not null check (direction in ('in', 'out')),
  parent_id   uuid,
  unique (org_id, id),
  unique (org_id, direction, name),
  foreign key (org_id, parent_id) references app.financial_categories(org_id, id) on delete cascade
);

-- Regras de recorrência (internet, aluguel, software, prestador fixo...).
-- O worker gera os lançamentos em financial_entries antes do vencimento.
create table app.recurring_rules (
  id                 uuid primary key default gen_random_uuid(),
  org_id             uuid not null references app.organizations(id) on delete cascade,
  direction          text not null check (direction in ('in', 'out')),
  description        text not null,
  amount_cents       bigint not null check (amount_cents > 0),
  category_id        uuid,
  customer_id        uuid,
  supplier_id        uuid,
  staff_id           uuid,
  frequency          text not null check (frequency in ('weekly', 'monthly', 'yearly')),
  interval_count     smallint not null default 1 check (interval_count between 1 and 12),
  day_of_month       smallint check (day_of_month between 1 and 31),
  next_due_on        date not null,
  ends_on            date,
  generate_days_ahead smallint not null default 10 check (generate_days_ahead between 0 and 60),
  is_active          boolean not null default true,
  source             text not null default 'user' check (source in ('user', 'ai', 'import')),
  created_by         uuid references app.profiles(id),
  created_at         timestamptz not null default now(),
  updated_at         timestamptz not null default now(),
  unique (org_id, id),
  foreign key (org_id, category_id) references app.financial_categories(org_id, id) on delete set null (category_id),
  foreign key (org_id, customer_id) references app.customers(org_id, id) on delete set null (customer_id),
  foreign key (org_id, supplier_id) references app.suppliers(org_id, id) on delete set null (supplier_id),
  foreign key (org_id, staff_id)    references app.staff_members(org_id, id) on delete set null (staff_id)
);
select app.add_updated_at_trigger('app.recurring_rules');

-- Contas a pagar (direction = 'out') e a receber (direction = 'in') numa
-- tabela só: o fluxo de caixa (previsto x realizado) vira uma consulta.
-- As views accounts_payable / accounts_receivable dão os nomes de negócio.
create table app.financial_entries (
  id                   uuid primary key default gen_random_uuid(),
  org_id               uuid not null references app.organizations(id) on delete cascade,
  direction            text not null check (direction in ('in', 'out')),
  description          text not null,
  category_id          uuid,
  customer_id          uuid,
  supplier_id          uuid,
  staff_id             uuid,                 -- salário, comissão, pagamento de prestador
  service_order_id     uuid,
  amount_cents         bigint not null check (amount_cents > 0),
  paid_amount_cents    bigint not null default 0 check (paid_amount_cents >= 0),
  due_on               date not null,
  status               text not null default 'open'
                         check (status in ('open', 'partially_paid', 'paid', 'canceled')),
  paid_at              timestamptz,
  payment_method       text check (payment_method in ('pix', 'boleto', 'credit_card', 'debit_card', 'cash', 'transfer', 'other')),
  bank_account_id      uuid,
  installment_group_id uuid,
  installment_number   smallint check (installment_number > 0),
  installment_count    smallint check (installment_count > 0),
  recurring_rule_id    uuid,
  notes                text,
  created_by           uuid references app.profiles(id),
  created_at           timestamptz not null default now(),
  updated_at           timestamptz not null default now(),
  unique (org_id, id),
  check (paid_amount_cents <= amount_cents),
  check (status <> 'paid' or paid_at is not null),
  foreign key (org_id, category_id)       references app.financial_categories(org_id, id) on delete set null (category_id),
  foreign key (org_id, customer_id)       references app.customers(org_id, id) on delete set null (customer_id),
  foreign key (org_id, supplier_id)       references app.suppliers(org_id, id) on delete set null (supplier_id),
  foreign key (org_id, staff_id)          references app.staff_members(org_id, id) on delete set null (staff_id),
  foreign key (org_id, service_order_id)  references app.service_orders(org_id, id) on delete set null (service_order_id),
  foreign key (org_id, bank_account_id)   references app.bank_accounts(org_id, id) on delete set null (bank_account_id),
  foreign key (org_id, recurring_rule_id) references app.recurring_rules(org_id, id) on delete set null (recurring_rule_id)
);
select app.add_updated_at_trigger('app.financial_entries');
create index financial_entries_org_due_idx on app.financial_entries (org_id, direction, due_on) where status in ('open', 'partially_paid');
-- Impede gerar a mesma ocorrência de uma recorrência duas vezes
create unique index financial_entries_recurring_uidx on app.financial_entries (org_id, recurring_rule_id, due_on) where recurring_rule_id is not null;

create view app.accounts_receivable with (security_invoker = true) as
  select *, (status in ('open', 'partially_paid') and due_on < current_date) as is_overdue
    from app.financial_entries where direction = 'in';

create view app.accounts_payable with (security_invoker = true) as
  select *, (status in ('open', 'partially_paid') and due_on < current_date) as is_overdue
    from app.financial_entries where direction = 'out';

-- Movimentações realizadas (o que de fato entrou/saiu da conta)
create table app.transactions (
  id                  uuid primary key default gen_random_uuid(),
  org_id              uuid not null references app.organizations(id) on delete cascade,
  bank_account_id     uuid not null,
  direction           text not null check (direction in ('in', 'out')),
  amount_cents        bigint not null check (amount_cents > 0),
  occurred_at         timestamptz not null default now(),
  description         text not null,
  financial_entry_id  uuid,
  source              text not null default 'manual' check (source in ('manual', 'import', 'integration', 'system')),
  external_ref        text,
  created_by          uuid references app.profiles(id),
  created_at          timestamptz not null default now(),
  unique (org_id, id),
  foreign key (org_id, bank_account_id)    references app.bank_accounts(org_id, id),
  foreign key (org_id, financial_entry_id) references app.financial_entries(org_id, id) on delete set null (financial_entry_id)
);
create index transactions_org_account_idx on app.transactions (org_id, bank_account_id, occurred_at desc);
create unique index transactions_external_uidx on app.transactions (org_id, bank_account_id, external_ref) where external_ref is not null;

-- ---------------------------------------------------------------------
-- BANKING INTEGRATION — intenção de pagamento.
-- O Avocato NUNCA movimenta dinheiro sozinho: prepara a intenção, um
-- humano com permissão autoriza e só então o adaptador do provedor
-- (Open Finance / gateway) executa. Fluxo de status controlado.
-- ---------------------------------------------------------------------
create table app.payment_intents (
  id                  uuid primary key default gen_random_uuid(),
  org_id              uuid not null references app.organizations(id) on delete cascade,
  financial_entry_id  uuid not null,
  bank_account_id     uuid not null,
  amount_cents        bigint not null check (amount_cents > 0),
  method              text not null check (method in ('pix', 'boleto', 'transfer')),
  status              text not null default 'draft'
                        check (status in ('draft', 'pending_authorization', 'authorized', 'submitted', 'confirmed', 'failed', 'canceled')),
  idempotency_key     text not null,
  provider            text,
  provider_ref        text,
  requested_by_type   text not null default 'user' check (requested_by_type in ('user', 'ai', 'automation')),
  requested_by        uuid references app.profiles(id),
  authorized_by       uuid references app.profiles(id),
  authorized_at       timestamptz,
  failure_reason      text,
  created_at          timestamptz not null default now(),
  updated_at          timestamptz not null default now(),
  unique (org_id, id),
  unique (org_id, idempotency_key),
  -- Daqui pra frente exige autorização humana registrada
  check (status not in ('authorized', 'submitted', 'confirmed') or (authorized_by is not null and authorized_at is not null)),
  foreign key (org_id, financial_entry_id) references app.financial_entries(org_id, id),
  foreign key (org_id, bank_account_id)    references app.bank_accounts(org_id, id)
);
select app.add_updated_at_trigger('app.payment_intents');
