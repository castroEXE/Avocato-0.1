-- =====================================================================
-- AVOCATO · 0900 · Recursos do produto
--   • avatar personalizável por usuário
--   • módulos operacionais ligados por padrão em empresas novas
--   • OS com status "solicitada" e origem (interna, link público, IA)
--   • formulário público de solicitação de serviço por empresa
-- =====================================================================

-- Avatar: {"style":"notionists","seed":"abc","options":{...}}
alter table app.profiles add column avatar jsonb;
grant update (avatar) on app.profiles to avocato_app;

-- Módulos ligados ao criar a empresa (o usuário pode desligar depois)
alter table app.modules add column enabled_by_default boolean not null default false;
update app.modules set enabled_by_default = true
 where key in ('customers', 'crm', 'services', 'appointments', 'service_orders', 'team', 'finance', 'reports', 'ai');

-- Ordens de serviço: solicitação → aberta → agendada → em andamento → concluída
alter table app.service_orders drop constraint service_orders_status_check;
alter table app.service_orders add constraint service_orders_status_check
  check (status in ('requested', 'open', 'scheduled', 'in_progress', 'done', 'canceled'));
alter table app.service_orders
  add column title text,
  add column source text not null default 'internal' check (source in ('internal', 'public_request', 'ai')),
  add column requested_service_id uuid,
  add column preferred_date date,
  add foreign key (org_id, requested_service_id) references app.services(org_id, id) on delete set null (requested_service_id);

-- Recebível gerado ao concluir um atendimento da agenda (salões, clínicas...)
alter table app.financial_entries
  add column appointment_id uuid,
  add foreign key (org_id, appointment_id) references app.appointments(org_id, id) on delete set null (appointment_id);
create unique index financial_entries_appointment_uidx
  on app.financial_entries (org_id, appointment_id) where appointment_id is not null and status <> 'canceled';

-- Um recebível por OS concluída (gerado automaticamente pela API)
create unique index financial_entries_service_order_uidx
  on app.financial_entries (org_id, service_order_id) where service_order_id is not null and direction = 'in' and status <> 'canceled';

-- ---------------------------------------------------------------------
-- Bootstrap de empresa (substitui a versão da 0700): liga os módulos
-- padrão e habilita o link público de solicitações.
-- ---------------------------------------------------------------------
create or replace function app.create_organization(p_name text, p_slug text, p_plan text default 'starter')
returns uuid
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_user     uuid := app.current_user_id();
  v_org      uuid := gen_random_uuid();
  v_role     uuid;
  v_owner    uuid;
  v_pipeline uuid;
  t          record;
begin
  if v_user is null then
    raise exception 'usuário não autenticado' using errcode = '42501';
  end if;
  if not exists (select 1 from app.plans where key = p_plan and is_public) then
    raise exception 'plano inválido: %', p_plan using errcode = '22023';
  end if;

  insert into app.organizations (id, name, slug, created_by)
  values (v_org, trim(p_name), p_slug, v_user);

  for t in select * from app.role_templates order by sort_order loop
    insert into app.roles (org_id, key, name, description, is_system)
    values (v_org, t.key, t.name, t.description, true)
    returning id into v_role;

    insert into app.role_permissions (org_id, role_id, permission_key)
    select v_org, v_role, p.key
      from app.permissions p
     where p.key like any (t.include)
       and not (p.key like any (t.exclude));

    if t.key = 'owner' then
      v_owner := v_role;
    end if;
  end loop;

  insert into app.memberships (org_id, user_id, role_id, status)
  values (v_org, v_user, v_owner, 'active');

  insert into app.organization_settings (org_id, enabled_modules, workflow_configuration)
  select v_org,
         jsonb_object_agg(m.key, m.is_core or m.enabled_by_default),
         '{"publicRequestsEnabled": true}'::jsonb
    from app.modules m;

  insert into app.subscriptions (org_id, plan_key, status, trial_ends_at)
  values (v_org, p_plan, 'trialing', now() + interval '14 days');

  insert into app.pipelines (org_id, name, is_default)
  values (v_org, 'Vendas', true)
  returning id into v_pipeline;

  insert into app.pipeline_stages (org_id, pipeline_id, name, position, kind, probability)
  values (v_org, v_pipeline, 'Novo',         1, 'open', 10),
         (v_org, v_pipeline, 'Contato',      2, 'open', 20),
         (v_org, v_pipeline, 'Qualificação', 3, 'open', 40),
         (v_org, v_pipeline, 'Proposta',     4, 'open', 60),
         (v_org, v_pipeline, 'Negociação',   5, 'open', 80),
         (v_org, v_pipeline, 'Ganho',        6, 'won', 100),
         (v_org, v_pipeline, 'Perdido',      7, 'lost', 0);

  insert into app.financial_categories (org_id, name, direction)
  values (v_org, 'Vendas', 'in'), (v_org, 'Serviços', 'in'), (v_org, 'Outras receitas', 'in'),
         (v_org, 'Aluguel', 'out'), (v_org, 'Energia', 'out'), (v_org, 'Internet e telefone', 'out'),
         (v_org, 'Salários', 'out'), (v_org, 'Prestadores', 'out'), (v_org, 'Fornecedores', 'out'),
         (v_org, 'Impostos', 'out'), (v_org, 'Software', 'out'), (v_org, 'Outras despesas', 'out');

  insert into app.audit_logs (org_id, actor_type, actor_user_id, action, entity_type, entity_id, after)
  values (v_org, 'user', v_user, 'organization.create', 'organization', v_org::text,
          jsonb_build_object('name', trim(p_name), 'slug', p_slug, 'plan', p_plan));

  return v_org;
end $$;

-- ---------------------------------------------------------------------
-- Link público de solicitação: /solicitar/<slug>
-- Funções SECURITY DEFINER com superfície mínima. Expõem só nome da
-- empresa e serviços ativos, e só criam uma OS "solicitada".
-- ---------------------------------------------------------------------
create or replace function app.public_request_form(p_slug text)
returns jsonb
language sql stable
security definer
set search_path = ''
as $$
  select jsonb_build_object(
    'organization', jsonb_build_object(
      'name', o.name,
      'slug', o.slug,
      'description', s.business_profile ->> 'description',
      'phone', s.business_profile ->> 'phone'),
    'services', coalesce((
      select jsonb_agg(jsonb_build_object(
               'id', sv.id, 'name', sv.name, 'description', sv.description,
               'priceCents', sv.price_cents, 'durationMinutes', sv.duration_minutes) order by sv.name)
        from app.services sv
       where sv.org_id = o.id and sv.is_active), '[]'::jsonb))
    from app.organizations o
    join app.organization_settings s on s.org_id = o.id
   where o.slug = p_slug
     and o.status = 'active'
     and coalesce((s.workflow_configuration ->> 'publicRequestsEnabled')::boolean, true)
$$;

create or replace function app.submit_public_request(
  p_slug text,
  p_name text,
  p_phone text,
  p_email text,
  p_service_id uuid,
  p_description text,
  p_preferred_date date
)
returns jsonb
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_org      uuid;
  v_org_name text;
  v_customer uuid;
  v_service  record;
  v_number   bigint;
  v_order    uuid;
  v_digits   text := nullif(regexp_replace(coalesce(p_phone, ''), '\D', '', 'g'), '');
  v_email    text := nullif(lower(trim(coalesce(p_email, ''))), '');
begin
  select o.id, o.name into v_org, v_org_name
    from app.organizations o
    join app.organization_settings s on s.org_id = o.id
   where o.slug = p_slug and o.status = 'active'
     and coalesce((s.workflow_configuration ->> 'publicRequestsEnabled')::boolean, true);
  if v_org is null then
    raise exception 'empresa não encontrada' using errcode = 'P0002';
  end if;

  if length(trim(coalesce(p_name, ''))) < 2 or length(p_name) > 200 then
    raise exception 'nome inválido' using errcode = '22023';
  end if;
  if v_digits is null and v_email is null then
    raise exception 'informe telefone ou e-mail' using errcode = '22023';
  end if;
  if length(coalesce(p_description, '')) > 2000 then
    raise exception 'descrição muito longa' using errcode = '22023';
  end if;

  if p_service_id is not null then
    select id, name, price_cents, cost_cents, commission_rate into v_service
      from app.services where org_id = v_org and id = p_service_id and is_active;
    if v_service.id is null then
      raise exception 'serviço inválido' using errcode = '22023';
    end if;
  end if;

  -- Reaproveita o cliente pelo e-mail ou telefone
  select c.id into v_customer
    from app.customers c
   where c.org_id = v_org and c.deleted_at is null
     and ((v_email is not null and lower(c.email::text) = v_email)
       or (v_digits is not null and regexp_replace(coalesce(c.phone, ''), '\D', '', 'g') = v_digits))
   limit 1;

  if v_customer is null then
    insert into app.customers (org_id, name, email, phone, source)
    values (v_org, trim(p_name), v_email, nullif(trim(coalesce(p_phone, '')), ''), 'Solicitação online')
    returning id into v_customer;
  end if;

  insert into app.org_counters as c (org_id, key, value)
  values (v_org, 'service_order', 1)
  on conflict (org_id, key) do update set value = c.value + 1
  returning value into v_number;

  insert into app.service_orders (org_id, number, customer_id, status, source, title, description,
                                  requested_service_id, preferred_date, total_cents, cost_cents)
  values (v_org, v_number, v_customer, 'requested', 'public_request',
          coalesce(v_service.name, 'Solicitação de serviço'), nullif(trim(coalesce(p_description, '')), ''),
          v_service.id, p_preferred_date, coalesce(v_service.price_cents, 0), coalesce(v_service.cost_cents, 0))
  returning id into v_order;

  if v_service.id is not null then
    insert into app.service_order_items (org_id, service_order_id, service_id, description, quantity,
                                         unit_price_cents, unit_cost_cents, commission_rate)
    values (v_org, v_order, v_service.id, v_service.name, 1,
            v_service.price_cents, v_service.cost_cents, v_service.commission_rate);
  end if;

  insert into app.notifications (org_id, kind, severity, title, body, link, data)
  values (v_org, 'service_order.requested', 'info', 'Nova solicitação de serviço',
          trim(p_name) || coalesce(' pediu ' || v_service.name, ' enviou uma solicitação'),
          '/ordens?id=' || v_order, jsonb_build_object('serviceOrderId', v_order, 'number', v_number));

  insert into app.domain_events (org_id, type, entity_type, entity_id, payload, actor_type)
  values (v_org, 'service_order.requested', 'service_order', v_order,
          jsonb_build_object('number', v_number, 'source', 'public_request'), 'system');

  insert into app.audit_logs (org_id, actor_type, action, entity_type, entity_id, after)
  values (v_org, 'system', 'service_order.request', 'service_order', v_order::text,
          jsonb_build_object('number', v_number, 'customerId', v_customer, 'serviceId', v_service.id));

  return jsonb_build_object('number', v_number, 'organization', v_org_name);
end $$;

revoke execute on function app.public_request_form(text) from public;
revoke execute on function app.submit_public_request(text, text, text, text, uuid, text, date) from public;
grant execute on function app.public_request_form(text) to avocato_app;
grant execute on function app.submit_public_request(text, text, text, text, uuid, text, date) to avocato_app;

-- As funções acima rodam como o dono das tabelas: liberamos o dono
-- (FORCE RLS) só nas tabelas que elas tocam.
do $$
declare
  t text;
begin
  foreach t in array array['services', 'customers', 'service_orders', 'service_order_items', 'notifications', 'domain_events'] loop
    execute format('create policy definer_owner on app.%I for all to %I using (true) with check (true)', t, current_user);
  end loop;
end $$;
