-- =====================================================================
-- AVOCATO · 0700 · Dados de referência (catálogos) e bootstrap de
-- organização. Catálogos são configuração da plataforma, não dados de
-- tenant, por isso ficam numa migration (rodam em todo ambiente).
-- =====================================================================

insert into app.modules (key, name, description, depends_on, is_core) values
  ('core',           'Configuração',       'Empresa, usuários, permissões, plano e auditoria', '{}', true),
  ('customers',      'Clientes',           'Cadastro e perfil completo de clientes', '{}', true),
  ('crm',            'CRM',                'Leads, pipeline, oportunidades e follow-ups', '{customers}', false),
  ('services',       'Serviços',           'Catálogo de serviços com custo, comissão e margem', '{}', false),
  ('appointments',   'Agenda',             'Agendamentos, disponibilidade e bloqueios', '{customers}', false),
  ('service_orders', 'Ordens de serviço',  'OS do pedido à avaliação', '{customers}', false),
  ('team',           'Equipe',             'Funcionários, prestadores e comissões', '{}', false),
  ('inventory',      'Estoque',            'Produtos, saldo e movimentações', '{}', false),
  ('suppliers',      'Fornecedores e compras', 'Fornecedores e sugestões de compra', '{}', false),
  ('finance',        'Financeiro',         'Contas a pagar/receber, recorrências e fluxo de caixa', '{}', false),
  ('banking',        'Banco',              'Contas bancárias e integração bancária', '{finance}', false),
  ('automation',     'Automação',          'Regras QUANDO → CONDIÇÃO → AÇÃO', '{}', false),
  ('reports',        'Relatórios',         'Indicadores e relatórios', '{}', false),
  ('documents',      'Documentos',         'Arquivos ligados a qualquer registro', '{}', false),
  ('ai',             'IA',                 'Assistente operacional', '{}', false),
  ('fleet',          'Frota',              'Veículos, viagens e manutenção (planejado)', '{}', false);

insert into app.permissions (key, module_key, description) values
  ('settings.read',            'core', 'Ver configurações da empresa'),
  ('settings.manage',          'core', 'Alterar configurações, módulos e campos personalizados'),
  ('members.read',             'core', 'Ver usuários da empresa'),
  ('members.manage',           'core', 'Convidar, desativar e trocar papel de usuários'),
  ('roles.manage',             'core', 'Criar e editar papéis e permissões'),
  ('billing.read',             'core', 'Ver plano e assinatura'),
  ('billing.manage',           'core', 'Trocar plano e dados de cobrança'),
  ('audit.read',               'core', 'Ver log de auditoria'),
  ('notifications.read',       'core', 'Ver notificações'),
  ('customers.read',           'customers', 'Ver clientes'),
  ('customers.create',         'customers', 'Cadastrar clientes'),
  ('customers.update',         'customers', 'Editar clientes'),
  ('customers.delete',         'customers', 'Excluir clientes'),
  ('leads.read',               'crm', 'Ver leads'),
  ('leads.create',             'crm', 'Cadastrar leads'),
  ('leads.update',             'crm', 'Editar e converter leads'),
  ('leads.delete',             'crm', 'Excluir leads'),
  ('opportunities.read',       'crm', 'Ver oportunidades'),
  ('opportunities.create',     'crm', 'Criar oportunidades'),
  ('opportunities.update',     'crm', 'Mover e editar oportunidades'),
  ('opportunities.delete',     'crm', 'Excluir oportunidades'),
  ('pipelines.manage',         'crm', 'Configurar pipeline e etapas'),
  ('activities.read',          'crm', 'Ver histórico de interações'),
  ('activities.create',        'crm', 'Registrar notas e interações'),
  ('tasks.read',               'crm', 'Ver tarefas'),
  ('tasks.create',             'crm', 'Criar tarefas'),
  ('tasks.update',             'crm', 'Editar e concluir tarefas'),
  ('tasks.delete',             'crm', 'Excluir tarefas'),
  ('services.read',            'services', 'Ver serviços'),
  ('services.manage',          'services', 'Cadastrar e editar serviços, preços e comissões'),
  ('appointments.read',        'appointments', 'Ver agenda'),
  ('appointments.create',      'appointments', 'Agendar'),
  ('appointments.update',      'appointments', 'Remarcar e mudar status'),
  ('appointments.delete',      'appointments', 'Excluir agendamentos'),
  ('service_orders.read',      'service_orders', 'Ver ordens de serviço'),
  ('service_orders.create',    'service_orders', 'Abrir ordens de serviço'),
  ('service_orders.update',    'service_orders', 'Atualizar e concluir OS'),
  ('service_orders.delete',    'service_orders', 'Excluir OS'),
  ('staff.read',               'team', 'Ver equipe e prestadores'),
  ('staff.manage',             'team', 'Cadastrar equipe, prestadores e comissões'),
  ('products.read',            'inventory', 'Ver produtos'),
  ('products.manage',          'inventory', 'Cadastrar e editar produtos'),
  ('inventory.adjust',         'inventory', 'Lançar movimentações de estoque'),
  ('suppliers.read',           'suppliers', 'Ver fornecedores'),
  ('suppliers.manage',         'suppliers', 'Cadastrar fornecedores'),
  ('finance.read',             'finance', 'Ver financeiro e fluxo de caixa'),
  ('finance.manage',           'finance', 'Lançar e editar contas a pagar/receber'),
  ('finance.authorize_payment','banking', 'Autorizar pagamentos (ação sensível)'),
  ('bank_accounts.manage',     'banking', 'Cadastrar contas bancárias'),
  ('integrations.manage',      'banking', 'Conectar integrações externas'),
  ('automations.read',         'automation', 'Ver automações'),
  ('automations.manage',       'automation', 'Criar e editar automações'),
  ('reports.read',             'reports', 'Ver relatórios e dashboards'),
  ('documents.read',           'documents', 'Ver documentos'),
  ('documents.manage',         'documents', 'Enviar e remover documentos'),
  ('ai.use',                   'ai', 'Usar o assistente de IA'),
  ('ai.approve_actions',       'ai', 'Aprovar ações sensíveis propostas pela IA');

insert into app.plans (key, name, price_cents, limits, features, sort_order) values
  ('starter',    'Starter',    0,
     '{"users":3,"customers":500,"units":1,"storage_mb":1024,"ai_requests_month":200,"automations":5}',
     '{"integrations":false}', 1),
  ('pro',        'Pro',        14900,
     '{"users":10,"customers":5000,"units":1,"storage_mb":10240,"ai_requests_month":2000,"automations":30}',
     '{"integrations":true}', 2),
  ('business',   'Business',   39900,
     '{"users":30,"customers":50000,"units":5,"storage_mb":51200,"ai_requests_month":10000,"automations":200}',
     '{"integrations":true,"audit_export":true}', 3),
  ('enterprise', 'Enterprise', 0,
     '{"users":null,"customers":null,"units":null,"storage_mb":null,"ai_requests_month":null,"automations":null}',
     '{"integrations":true,"audit_export":true,"sso":true}', 4);

-- Papéis padrão criados para toda empresa nova. Padrões LIKE sobre as
-- chaves de permissão: adicionar uma permissão nova ao catálogo já a
-- distribui sem tocar em código.
create table app.role_templates (
  key          text primary key,
  name         text not null,
  description  text not null default '',
  include      text[] not null,
  exclude      text[] not null default '{}',
  sort_order   integer not null default 0
);

insert into app.role_templates (key, name, description, include, exclude, sort_order) values
  ('owner',   'Proprietário', 'Acesso total à empresa', '{%}', '{}', 1),
  ('admin',   'Administrador', 'Tudo, exceto cobrança do plano', '{%}', '{billing.manage}', 2),
  ('manager', 'Gestor', 'Opera o dia a dia, inclusive financeiro',
     '{%.read,customers.%,leads.%,opportunities.%,activities.%,tasks.%,appointments.%,service_orders.%,services.%,products.%,inventory.%,suppliers.%,finance.manage,documents.%,ai.use,automations.manage}',
     '{audit.read,billing.read}', 3),
  ('staff',   'Colaborador', 'Atende clientes, agenda e executa serviços',
     '{customers.read,customers.create,customers.update,activities.%,tasks.read,tasks.create,tasks.update,appointments.read,appointments.create,appointments.update,service_orders.read,service_orders.update,services.read,products.read,staff.read,documents.read,notifications.read,ai.use}',
     '{}', 4),
  ('viewer',  'Leitura', 'Só visualiza', '{%.read}', '{audit.read,billing.read,finance.read}', 5);

-- ---------------------------------------------------------------------
-- Bootstrap de empresa: cria org, papéis, membership de owner,
-- configurações, assinatura em trial, pipeline padrão, categorias
-- financeiras básicas e registra auditoria. Tudo numa transação.
-- ---------------------------------------------------------------------
create or replace function app.create_organization(p_name text, p_slug text, p_plan text default 'starter')
returns uuid
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_user     uuid := app.current_user_id();
  v_org      uuid := gen_random_uuid();
  v_role     uuid;
  v_owner    uuid;
  v_pipeline uuid;
  t          record;
begin
  if v_user is null then
    raise exception 'usuário não autenticado' using errcode = '42501';
  end if;
  if not exists (select 1 from app.plans where key = p_plan and is_public) then
    raise exception 'plano inválido: %', p_plan using errcode = '22023';
  end if;

  insert into app.organizations (id, name, slug, created_by)
  values (v_org, trim(p_name), p_slug, v_user);

  for t in select * from app.role_templates order by sort_order loop
    insert into app.roles (org_id, key, name, description, is_system)
    values (v_org, t.key, t.name, t.description, true)
    returning id into v_role;

    insert into app.role_permissions (org_id, role_id, permission_key)
    select v_org, v_role, p.key
      from app.permissions p
     where p.key like any (t.include)
       and not (p.key like any (t.exclude));

    if t.key = 'owner' then
      v_owner := v_role;
    end if;
  end loop;

  insert into app.memberships (org_id, user_id, role_id, status)
  values (v_org, v_user, v_owner, 'active');

  insert into app.organization_settings (org_id, enabled_modules)
  select v_org, jsonb_object_agg(m.key, m.is_core) from app.modules m;

  insert into app.subscriptions (org_id, plan_key, status, trial_ends_at)
  values (v_org, p_plan, 'trialing', now() + interval '14 days');

  insert into app.pipelines (org_id, name, is_default)
  values (v_org, 'Vendas', true)
  returning id into v_pipeline;

  insert into app.pipeline_stages (org_id, pipeline_id, name, position, kind, probability)
  values (v_org, v_pipeline, 'Novo',         1, 'open', 10),
         (v_org, v_pipeline, 'Contato',      2, 'open', 20),
         (v_org, v_pipeline, 'Qualificação', 3, 'open', 40),
         (v_org, v_pipeline, 'Proposta',     4, 'open', 60),
         (v_org, v_pipeline, 'Negociação',   5, 'open', 80),
         (v_org, v_pipeline, 'Ganho',        6, 'won', 100),
         (v_org, v_pipeline, 'Perdido',      7, 'lost', 0);

  insert into app.financial_categories (org_id, name, direction)
  values (v_org, 'Vendas', 'in'), (v_org, 'Serviços', 'in'), (v_org, 'Outras receitas', 'in'),
         (v_org, 'Aluguel', 'out'), (v_org, 'Energia', 'out'), (v_org, 'Internet e telefone', 'out'),
         (v_org, 'Salários', 'out'), (v_org, 'Prestadores', 'out'), (v_org, 'Fornecedores', 'out'),
         (v_org, 'Impostos', 'out'), (v_org, 'Software', 'out'), (v_org, 'Outras despesas', 'out');

  insert into app.audit_logs (org_id, actor_type, actor_user_id, action, entity_type, entity_id, after)
  values (v_org, 'user', v_user, 'organization.create', 'organization', v_org::text,
          jsonb_build_object('name', trim(p_name), 'slug', p_slug, 'plan', p_plan));

  return v_org;
end $$;

-- Super Admin: o próprio usuário consulta se é admin da plataforma
create or replace function app.am_i_platform_admin()
returns boolean
language sql stable
security definer
set search_path = ''
as $$
  select exists (select 1 from app.platform_admins where user_id = app.current_user_id())
$$;
