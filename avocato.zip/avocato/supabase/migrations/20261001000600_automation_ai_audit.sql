-- =====================================================================
-- AVOCATO · 0600 · Integrações, eventos (outbox), automações,
-- notificações, documentos, IA e auditoria.
-- =====================================================================

-- Conexões com provedores externos. Segredos ficam no Supabase Vault;
-- aqui guardamos só a referência (secret_ref), nunca o valor.
create table app.integrations (
  id               uuid primary key default gen_random_uuid(),
  org_id           uuid not null references app.organizations(id) on delete cascade,
  provider         text not null,          -- 'open_finance:xyz', 'whatsapp', 'email', 'stripe'...
  category         text not null check (category in ('banking', 'payments', 'messaging', 'email', 'calendar', 'other')),
  status           text not null default 'pending' check (status in ('pending', 'connected', 'error', 'revoked')),
  scopes           text[] not null default '{}',
  secret_ref       text,                   -- id do segredo no Vault
  external_ref     text,
  last_sync_at     timestamptz,
  last_error       text,
  connected_by     uuid references app.profiles(id),
  created_at       timestamptz not null default now(),
  updated_at       timestamptz not null default now(),
  unique (org_id, id),
  unique (org_id, provider)
);
select app.add_updated_at_trigger('app.integrations');

alter table app.bank_accounts
  add foreign key (org_id, integration_id) references app.integrations(org_id, id) on delete set null (integration_id);

-- Outbox de eventos de domínio. Os serviços gravam o evento NA MESMA
-- transação da mudança; o worker de automações consome daqui.
create table app.domain_events (
  id            bigint generated always as identity primary key,
  org_id        uuid not null references app.organizations(id) on delete cascade,
  type          text not null check (type ~ '^[a-z_]+\.[a-z_]+$'),   -- 'customer.created'
  entity_type   text not null,
  entity_id     uuid,
  payload       jsonb not null default '{}'::jsonb,
  actor_type    text not null default 'user' check (actor_type in ('user', 'ai', 'automation', 'system', 'platform_admin')),
  actor_user_id uuid,
  occurred_at   timestamptz not null default now(),
  processed_at  timestamptz,
  attempts      smallint not null default 0
);
create index domain_events_pending_idx on app.domain_events (occurred_at) where processed_at is null;

-- QUANDO → CONDIÇÃO → AÇÃO (seção 15)
create table app.automations (
  id              uuid primary key default gen_random_uuid(),
  org_id          uuid not null references app.organizations(id) on delete cascade,
  name            text not null,
  description     text,
  trigger_type    text not null check (trigger_type in ('event', 'schedule')),
  trigger_event   text,                  -- 'service_order.completed'
  schedule_cron   text,                  -- '0 8 * * *'
  conditions      jsonb not null default '[]'::jsonb,
  actions         jsonb not null default '[]'::jsonb,
  risk_level      text not null default 'low' check (risk_level in ('low', 'sensitive')),
  is_active       boolean not null default true,
  source          text not null default 'user' check (source in ('user', 'ai', 'template')),
  last_run_at     timestamptz,
  created_by      uuid references app.profiles(id),
  created_at      timestamptz not null default now(),
  updated_at      timestamptz not null default now(),
  unique (org_id, id),
  check ((trigger_type = 'event' and trigger_event is not null) or (trigger_type = 'schedule' and schedule_cron is not null))
);
select app.add_updated_at_trigger('app.automations');

create table app.automation_runs (
  id              uuid primary key default gen_random_uuid(),
  org_id          uuid not null,
  automation_id   uuid not null,
  event_id        bigint references app.domain_events(id) on delete set null,
  status          text not null default 'running'
                    check (status in ('running', 'succeeded', 'failed', 'skipped', 'awaiting_approval')),
  result          jsonb not null default '{}'::jsonb,
  error           text,
  started_at      timestamptz not null default now(),
  finished_at     timestamptz,
  foreign key (org_id, automation_id) references app.automations(org_id, id) on delete cascade
);
create index automation_runs_org_idx on app.automation_runs (org_id, started_at desc);

create table app.notifications (
  id            uuid primary key default gen_random_uuid(),
  org_id        uuid not null references app.organizations(id) on delete cascade,
  user_id       uuid references app.profiles(id) on delete cascade,  -- null = todos da empresa
  channel       text not null default 'in_app' check (channel in ('in_app', 'email', 'whatsapp', 'push')),
  kind          text not null,              -- 'finance.due_soon', 'service_order.completed'...
  severity      text not null default 'info' check (severity in ('info', 'success', 'warning', 'critical')),
  title         text not null,
  body          text,
  link          text,
  data          jsonb not null default '{}'::jsonb,
  status        text not null default 'pending' check (status in ('pending', 'sent', 'failed')),
  read_at       timestamptz,
  sent_at       timestamptz,
  created_at    timestamptz not null default now()
);
create index notifications_user_idx on app.notifications (org_id, user_id, read_at, created_at desc);

-- Metadados de arquivos; o binário fica no Supabase Storage (bucket privado)
create table app.documents (
  id            uuid primary key default gen_random_uuid(),
  org_id        uuid not null references app.organizations(id) on delete cascade,
  entity_type   text not null,
  entity_id     uuid not null,
  name          text not null,
  storage_path  text not null,
  mime_type     text,
  size_bytes    bigint check (size_bytes >= 0),
  is_sensitive  boolean not null default false,
  uploaded_by   uuid references app.profiles(id),
  created_at    timestamptz not null default now(),
  unique (org_id, id)
);
create index documents_entity_idx on app.documents (org_id, entity_type, entity_id);

-- ---------------------------------------------------------------------
-- IA: conversas, mensagens (com consumo de tokens) e ações.
-- Toda ação da IA vira uma linha em ai_actions — proposta, aprovada,
-- executada ou rejeitada. Ações sensíveis param em awaiting_approval.
-- ---------------------------------------------------------------------
create table app.ai_conversations (
  id          uuid primary key default gen_random_uuid(),
  org_id      uuid not null references app.organizations(id) on delete cascade,
  user_id     uuid not null references app.profiles(id) on delete cascade,
  kind        text not null default 'assistant' check (kind in ('onboarding', 'assistant', 'insights')),
  title       text,
  created_at  timestamptz not null default now(),
  updated_at  timestamptz not null default now(),
  unique (org_id, id)
);
select app.add_updated_at_trigger('app.ai_conversations');

create table app.ai_messages (
  id               uuid primary key default gen_random_uuid(),
  org_id           uuid not null,
  conversation_id  uuid not null,
  role             text not null check (role in ('user', 'assistant', 'tool')),
  content          jsonb not null,
  model            text,
  input_tokens     integer not null default 0,
  output_tokens    integer not null default 0,
  created_at       timestamptz not null default now(),
  foreign key (org_id, conversation_id) references app.ai_conversations(org_id, id) on delete cascade
);
create index ai_messages_conv_idx on app.ai_messages (org_id, conversation_id, created_at);

create table app.ai_actions (
  id               uuid primary key default gen_random_uuid(),
  org_id           uuid not null references app.organizations(id) on delete cascade,
  conversation_id  uuid,
  tool_name        text not null,
  input            jsonb not null,
  output           jsonb,
  risk_level       text not null check (risk_level in ('low', 'sensitive')),
  status           text not null
                     check (status in ('awaiting_approval', 'approved', 'rejected', 'executed', 'failed')),
  requested_by     uuid not null references app.profiles(id),
  decided_by       uuid references app.profiles(id),
  decided_at       timestamptz,
  executed_at      timestamptz,
  error            text,
  created_at       timestamptz not null default now(),
  unique (org_id, id),
  foreign key (org_id, conversation_id) references app.ai_conversations(org_id, id) on delete set null (conversation_id)
);
create index ai_actions_pending_idx on app.ai_actions (org_id, status) where status = 'awaiting_approval';

-- ---------------------------------------------------------------------
-- Auditoria (seção 29). Append-only: nem a API consegue alterar ou
-- apagar registros. org_id nulo = ação de plataforma (Super Admin).
-- ---------------------------------------------------------------------
create table app.audit_logs (
  id             bigint generated always as identity primary key,
  -- Sem FK de propósito: o histórico sobrevive mesmo se a empresa for removida
  org_id         uuid,
  actor_type     text not null check (actor_type in ('user', 'ai', 'automation', 'system', 'platform_admin')),
  actor_user_id  uuid,
  action         text not null,           -- 'customer.update'
  entity_type    text not null,
  entity_id      text,
  before         jsonb,
  after          jsonb,
  metadata       jsonb not null default '{}'::jsonb,   -- ip, user agent, request id, ai_action_id...
  created_at     timestamptz not null default now()
);
create index audit_logs_org_idx on app.audit_logs (org_id, created_at desc);
create index audit_logs_entity_idx on app.audit_logs (org_id, entity_type, entity_id);

create or replace function app.audit_logs_immutable()
returns trigger
language plpgsql
set search_path = ''
as $$
begin
  raise exception 'audit_logs é append-only' using errcode = '42501';
end $$;

create trigger trg_audit_logs_immutable
  before update or delete on app.audit_logs
  for each row execute function app.audit_logs_immutable();
