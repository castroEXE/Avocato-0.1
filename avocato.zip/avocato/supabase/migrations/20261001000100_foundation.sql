-- =====================================================================
-- AVOCATO · 0100 · Fundação
-- Schema privado `app` (NÃO exposto pela Data API do Supabase), papéis
-- de banco usados pela API e funções de contexto de tenant.
-- =====================================================================

-- No Supabase as extensões ficam no schema `extensions` (fora da Data API)
do $$
declare
  target text := case when exists (select 1 from pg_namespace where nspname = 'extensions')
                      then 'extensions' else 'public' end;
begin
  execute format('create extension if not exists btree_gist with schema %I', target); -- conflito de agenda
  execute format('create extension if not exists citext with schema %I', target);     -- e-mail sem diferenciar maiúsculas
end $$;

create schema if not exists app;
revoke all on schema app from public;

-- O Supabase expõe anon/authenticated pela Data API. Garantimos que eles
-- nunca toquem no schema `app`: todo acesso passa pela API própria.
do $$
begin
  if exists (select 1 from pg_roles where rolname = 'anon') then
    execute 'revoke all on schema app from anon';
  end if;
  if exists (select 1 from pg_roles where rolname = 'authenticated') then
    execute 'revoke all on schema app from authenticated';
  end if;
end $$;

-- ---------------------------------------------------------------------
-- Papéis de banco (NOLOGIN). A API conecta com um usuário de login
-- próprio (ver docs/SETUP.md) e, em toda transação, faz
-- `SET LOCAL ROLE avocato_app`. Esses papéis NÃO têm BYPASSRLS.
--   avocato_app       → operações de tenant (sempre isoladas por RLS)
--   avocato_platform  → Super Admin (leitura cross-tenant, auditada)
-- ---------------------------------------------------------------------
do $$
begin
  if not exists (select 1 from pg_roles where rolname = 'avocato_app') then
    create role avocato_app nologin nobypassrls;
  end if;
  if not exists (select 1 from pg_roles where rolname = 'avocato_platform') then
    create role avocato_platform nologin nobypassrls;
  end if;
end $$;

grant usage on schema app to avocato_app, avocato_platform;

-- O papel que roda as migrations precisa poder assumir os papéis acima
-- (útil em dev; em produção a API usa o usuário `avocato_api`).
do $$ begin
  execute format('grant avocato_app, avocato_platform to %I', current_user);
exception when others then null;
end $$;

-- ---------------------------------------------------------------------
-- Contexto da requisição (preenchido pela API com set_config(..., true),
-- ou seja, válido somente dentro da transação corrente).
-- ---------------------------------------------------------------------
create or replace function app.current_user_id()
returns uuid
language sql stable
set search_path = ''
as $$
  select nullif(current_setting('app.user_id', true), '')::uuid
$$;

-- updated_at automático
create or replace function app.touch_updated_at()
returns trigger
language plpgsql
set search_path = ''
as $$
begin
  new.updated_at := now();
  return new;
end $$;

-- Helper para criar o trigger de updated_at nas tabelas
create or replace function app.add_updated_at_trigger(p_table regclass)
returns void
language plpgsql
set search_path = ''
as $$
begin
  execute format(
    'create trigger trg_touch_updated_at before update on %s
       for each row execute function app.touch_updated_at()', p_table);
end $$;
