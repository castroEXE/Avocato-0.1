-- =====================================================================
-- AVOCATO · 0300 · CRM: clientes, leads, pipeline, oportunidades,
-- atividades e tarefas.
-- Convenção: toda tabela de tenant tem org_id + unique(org_id, id) e as
-- FKs entre tabelas de tenant são COMPOSTAS (org_id, x_id). Assim o banco
-- impede, por construção, que um registro aponte para outro tenant.
-- =====================================================================

create table app.customers (
  id               uuid primary key default gen_random_uuid(),
  org_id           uuid not null references app.organizations(id) on delete cascade,
  kind             text not null default 'person' check (kind in ('person', 'company')),
  name             text not null check (length(trim(name)) between 1 and 200),
  email            citext,
  phone            text,
  document         text,                       -- CPF/CNPJ
  address          jsonb not null default '{}'::jsonb,
  status           text not null default 'active' check (status in ('active', 'inactive', 'blocked')),
  source           text,                       -- origem (indicação, instagram, site...)
  tags             text[] not null default '{}',
  owner_user_id    uuid references app.profiles(id),
  notes            text,
  custom_fields    jsonb not null default '{}'::jsonb,
  last_activity_at timestamptz,
  last_purchase_at timestamptz,
  created_by       uuid references app.profiles(id),
  created_at       timestamptz not null default now(),
  updated_at       timestamptz not null default now(),
  deleted_at       timestamptz,
  unique (org_id, id)
);
select app.add_updated_at_trigger('app.customers');
create index customers_org_name_idx on app.customers (org_id, lower(name)) where deleted_at is null;
create index customers_org_last_purchase_idx on app.customers (org_id, last_purchase_at) where deleted_at is null;
create unique index customers_org_email_uidx on app.customers (org_id, email) where email is not null and deleted_at is null;

create table app.leads (
  id                     uuid primary key default gen_random_uuid(),
  org_id                 uuid not null references app.organizations(id) on delete cascade,
  name                   text not null,
  email                  citext,
  phone                  text,
  company                text,
  source                 text,
  status                 text not null default 'open' check (status in ('open', 'converted', 'discarded')),
  owner_user_id          uuid references app.profiles(id),
  converted_customer_id  uuid,
  converted_at           timestamptz,
  custom_fields          jsonb not null default '{}'::jsonb,
  created_by             uuid references app.profiles(id),
  created_at             timestamptz not null default now(),
  updated_at             timestamptz not null default now(),
  unique (org_id, id),
  foreign key (org_id, converted_customer_id) references app.customers(org_id, id)
);
select app.add_updated_at_trigger('app.leads');
create index leads_org_status_idx on app.leads (org_id, status);

-- Pipeline configurável (a IA pode adaptar etapas por negócio)
create table app.pipelines (
  id          uuid primary key default gen_random_uuid(),
  org_id      uuid not null references app.organizations(id) on delete cascade,
  name        text not null,
  is_default  boolean not null default false,
  created_at  timestamptz not null default now(),
  updated_at  timestamptz not null default now(),
  unique (org_id, id)
);
select app.add_updated_at_trigger('app.pipelines');
create unique index pipelines_one_default_uidx on app.pipelines (org_id) where is_default;

create table app.pipeline_stages (
  id           uuid primary key default gen_random_uuid(),
  org_id       uuid not null,
  pipeline_id  uuid not null,
  name         text not null,
  position     integer not null,
  kind         text not null default 'open' check (kind in ('open', 'won', 'lost')),
  probability  numeric(5,2) not null default 0 check (probability between 0 and 100),
  created_at   timestamptz not null default now(),
  unique (org_id, id),
  unique (pipeline_id, position) deferrable initially deferred,
  foreign key (org_id, pipeline_id) references app.pipelines(org_id, id) on delete cascade
);

create table app.opportunities (
  id                  uuid primary key default gen_random_uuid(),
  org_id              uuid not null references app.organizations(id) on delete cascade,
  title               text not null,
  lead_id             uuid,
  customer_id         uuid,
  pipeline_id         uuid not null,
  stage_id            uuid not null,
  value_cents         bigint not null default 0 check (value_cents >= 0),
  expected_close_on   date,
  owner_user_id       uuid references app.profiles(id),
  status              text not null default 'open' check (status in ('open', 'won', 'lost')),
  lost_reason         text,
  closed_at           timestamptz,
  custom_fields       jsonb not null default '{}'::jsonb,
  created_by          uuid references app.profiles(id),
  created_at          timestamptz not null default now(),
  updated_at          timestamptz not null default now(),
  unique (org_id, id),
  check (lead_id is not null or customer_id is not null),
  foreign key (org_id, lead_id)     references app.leads(org_id, id) on delete set null (lead_id),
  foreign key (org_id, customer_id) references app.customers(org_id, id) on delete set null (customer_id),
  foreign key (org_id, pipeline_id) references app.pipelines(org_id, id),
  foreign key (org_id, stage_id)    references app.pipeline_stages(org_id, id)
);
select app.add_updated_at_trigger('app.opportunities');
create index opportunities_org_stage_idx on app.opportunities (org_id, stage_id) where status = 'open';

-- Linha do tempo: notas, ligações, e-mails, eventos do sistema.
-- Polimórfica (subject_type/subject_id) para servir a qualquer entidade.
create table app.activities (
  id            uuid primary key default gen_random_uuid(),
  org_id        uuid not null references app.organizations(id) on delete cascade,
  type          text not null check (type in ('note', 'call', 'email', 'meeting', 'whatsapp', 'visit', 'system')),
  subject_type  text not null check (subject_type in ('customer', 'lead', 'opportunity', 'service_order', 'staff_member', 'supplier')),
  subject_id    uuid not null,
  title         text,
  body          text,
  occurred_at   timestamptz not null default now(),
  actor_type    text not null default 'user' check (actor_type in ('user', 'ai', 'automation', 'system')),
  actor_user_id uuid references app.profiles(id),
  metadata      jsonb not null default '{}'::jsonb,
  created_at    timestamptz not null default now(),
  unique (org_id, id)
);
create index activities_subject_idx on app.activities (org_id, subject_type, subject_id, occurred_at desc);

create table app.tasks (
  id               uuid primary key default gen_random_uuid(),
  org_id           uuid not null references app.organizations(id) on delete cascade,
  title            text not null,
  description      text,
  status           text not null default 'open' check (status in ('open', 'in_progress', 'done', 'canceled')),
  priority         text not null default 'normal' check (priority in ('low', 'normal', 'high', 'urgent')),
  due_at           timestamptz,
  assignee_user_id uuid references app.profiles(id),
  subject_type     text check (subject_type in ('customer', 'lead', 'opportunity', 'service_order', 'financial_entry', 'staff_member')),
  subject_id       uuid,
  source           text not null default 'user' check (source in ('user', 'ai', 'automation', 'system')),
  completed_at     timestamptz,
  created_by       uuid references app.profiles(id),
  created_at       timestamptz not null default now(),
  updated_at       timestamptz not null default now(),
  unique (org_id, id),
  check ((subject_type is null) = (subject_id is null))
);
select app.add_updated_at_trigger('app.tasks');
create index tasks_org_assignee_idx on app.tasks (org_id, assignee_user_id, status, due_at);
