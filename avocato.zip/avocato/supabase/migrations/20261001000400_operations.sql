-- =====================================================================
-- AVOCATO · 0400 · Operação: equipe (funcionários + prestadores),
-- fornecedores, produtos/estoque, serviços, agenda e ordens de serviço.
-- =====================================================================

-- Funcionários e prestadores em UMA tabela (kind). Agenda e OS apontam
-- para um único "profissional", sem FK dupla. "Funcionários" e
-- "Prestadores" na interface são filtros desta tabela.
create table app.staff_members (
  id               uuid primary key default gen_random_uuid(),
  org_id           uuid not null references app.organizations(id) on delete cascade,
  kind             text not null check (kind in ('employee', 'freelancer', 'contractor')),
  user_id          uuid references app.profiles(id),   -- se também acessa o sistema
  name             text not null,
  email            citext,
  phone            text,
  document         text,
  job_title        text,
  specialties      text[] not null default '{}',
  service_regions  text[] not null default '{}',
  commission_rate  numeric(5,4) not null default 0 check (commission_rate between 0 and 1),
  is_external      boolean not null default false,       -- trabalha em campo
  status           text not null default 'active' check (status in ('active', 'inactive')),
  hired_on         date,
  custom_fields    jsonb not null default '{}'::jsonb,
  created_at       timestamptz not null default now(),
  updated_at       timestamptz not null default now(),
  unique (org_id, id)
);
select app.add_updated_at_trigger('app.staff_members');

create table app.staff_availability (
  id          uuid primary key default gen_random_uuid(),
  org_id      uuid not null,
  staff_id    uuid not null,
  weekday     smallint not null check (weekday between 0 and 6),   -- 0 = domingo
  starts_at   time not null,
  ends_at     time not null,
  check (ends_at > starts_at),
  foreign key (org_id, staff_id) references app.staff_members(org_id, id) on delete cascade
);

-- Bloqueios de agenda (férias, feriado, manutenção). staff_id nulo = empresa toda
create table app.schedule_blocks (
  id          uuid primary key default gen_random_uuid(),
  org_id      uuid not null references app.organizations(id) on delete cascade,
  staff_id    uuid,
  starts_at   timestamptz not null,
  ends_at     timestamptz not null,
  reason      text,
  check (ends_at > starts_at),
  foreign key (org_id, staff_id) references app.staff_members(org_id, id) on delete cascade
);

create table app.suppliers (
  id             uuid primary key default gen_random_uuid(),
  org_id         uuid not null references app.organizations(id) on delete cascade,
  name           text not null,
  document       text,
  email          citext,
  phone          text,
  contact_name   text,
  notes          text,
  custom_fields  jsonb not null default '{}'::jsonb,
  created_at     timestamptz not null default now(),
  updated_at     timestamptz not null default now(),
  unique (org_id, id)
);
select app.add_updated_at_trigger('app.suppliers');

create table app.products (
  id             uuid primary key default gen_random_uuid(),
  org_id         uuid not null references app.organizations(id) on delete cascade,
  sku            text,
  name           text not null,
  description    text,
  unit           text not null default 'un',
  price_cents    bigint not null default 0 check (price_cents >= 0),
  cost_cents     bigint not null default 0 check (cost_cents >= 0),
  track_stock    boolean not null default true,
  stock_qty      numeric(14,3) not null default 0,
  min_stock_qty  numeric(14,3) not null default 0,
  supplier_id    uuid,
  is_active      boolean not null default true,
  custom_fields  jsonb not null default '{}'::jsonb,
  created_at     timestamptz not null default now(),
  updated_at     timestamptz not null default now(),
  unique (org_id, id),
  foreign key (org_id, supplier_id) references app.suppliers(org_id, id) on delete set null (supplier_id)
);
select app.add_updated_at_trigger('app.products');
create unique index products_org_sku_uidx on app.products (org_id, sku) where sku is not null;

-- Movimentações de estoque: o saldo em products.stock_qty é mantido por
-- trigger a partir daqui, então todo ajuste fica rastreável.
create table app.stock_movements (
  id              uuid primary key default gen_random_uuid(),
  org_id          uuid not null,
  product_id      uuid not null,
  quantity        numeric(14,3) not null check (quantity <> 0),   -- + entrada / - saída
  reason          text not null check (reason in ('purchase', 'sale', 'service_usage', 'adjustment', 'return', 'loss')),
  reference_type  text,
  reference_id    uuid,
  unit_cost_cents bigint,
  created_by      uuid references app.profiles(id),
  created_at      timestamptz not null default now(),
  foreign key (org_id, product_id) references app.products(org_id, id) on delete cascade
);

create or replace function app.apply_stock_movement()
returns trigger
language plpgsql
set search_path = ''
as $$
begin
  update app.products
     set stock_qty = stock_qty + new.quantity
   where org_id = new.org_id and id = new.product_id;
  return new;
end $$;

create trigger trg_apply_stock_movement
  after insert on app.stock_movements
  for each row execute function app.apply_stock_movement();

create table app.services (
  id                uuid primary key default gen_random_uuid(),
  org_id            uuid not null references app.organizations(id) on delete cascade,
  name              text not null,
  description       text,
  category          text,
  price_cents       bigint not null default 0 check (price_cents >= 0),
  cost_cents        bigint not null default 0 check (cost_cents >= 0),
  commission_rate   numeric(5,4) not null default 0 check (commission_rate between 0 and 1),
  -- Receita − custo − comissão (seção 8), sempre consistente
  margin_cents      bigint generated always as
                      (price_cents - cost_cents - round(price_cents * commission_rate)::bigint) stored,
  duration_minutes  integer check (duration_minutes > 0),
  requires_booking  boolean not null default false,
  is_recurring      boolean not null default false,
  recurrence_days   integer check (recurrence_days > 0),   -- ex.: banho a cada 15 dias
  default_staff_id  uuid,
  is_active         boolean not null default true,
  custom_fields     jsonb not null default '{}'::jsonb,
  created_at        timestamptz not null default now(),
  updated_at        timestamptz not null default now(),
  unique (org_id, id),
  foreign key (org_id, default_staff_id) references app.staff_members(org_id, id) on delete set null (default_staff_id)
);
select app.add_updated_at_trigger('app.services');

-- Materiais usados por serviço (baixa de estoque e custo estimado)
create table app.service_materials (
  org_id      uuid not null,
  service_id  uuid not null,
  product_id  uuid not null,
  quantity    numeric(14,3) not null check (quantity > 0),
  primary key (service_id, product_id),
  foreign key (org_id, service_id) references app.services(org_id, id) on delete cascade,
  foreign key (org_id, product_id) references app.products(org_id, id) on delete cascade
);

create table app.appointments (
  id               uuid primary key default gen_random_uuid(),
  org_id           uuid not null references app.organizations(id) on delete cascade,
  customer_id      uuid not null,
  service_id       uuid,
  staff_id         uuid,
  starts_at        timestamptz not null,
  ends_at          timestamptz not null,
  status           text not null default 'scheduled'
                     check (status in ('scheduled', 'confirmed', 'in_progress', 'done', 'canceled', 'no_show')),
  price_cents      bigint check (price_cents >= 0),
  notes            text,
  recurrence_rule  text,             -- RRULE (RFC 5545), opcional
  series_id        uuid,             -- agrupa ocorrências de uma recorrência
  service_order_id uuid,
  custom_fields    jsonb not null default '{}'::jsonb,
  created_by       uuid references app.profiles(id),
  created_at       timestamptz not null default now(),
  updated_at       timestamptz not null default now(),
  unique (org_id, id),
  check (ends_at > starts_at),
  foreign key (org_id, customer_id) references app.customers(org_id, id),
  foreign key (org_id, service_id)  references app.services(org_id, id) on delete set null (service_id),
  foreign key (org_id, staff_id)    references app.staff_members(org_id, id) on delete set null (staff_id),
  -- O mesmo profissional não pode ter dois horários sobrepostos
  constraint appointments_no_overlap exclude using gist (
    org_id with =,
    staff_id with =,
    tstzrange(starts_at, ends_at, '[)') with &&
  ) where (staff_id is not null and status not in ('canceled', 'no_show'))
);
select app.add_updated_at_trigger('app.appointments');
create index appointments_org_starts_idx on app.appointments (org_id, starts_at);

create table app.service_orders (
  id               uuid primary key default gen_random_uuid(),
  org_id           uuid not null references app.organizations(id) on delete cascade,
  number           bigint not null,
  customer_id      uuid not null,
  staff_id         uuid,
  status           text not null default 'open'
                     check (status in ('open', 'scheduled', 'in_progress', 'done', 'canceled')),
  scheduled_for    timestamptz,
  started_at       timestamptz,
  completed_at     timestamptz,
  address          jsonb not null default '{}'::jsonb,
  description      text,
  total_cents      bigint not null default 0 check (total_cents >= 0),
  cost_cents       bigint not null default 0 check (cost_cents >= 0),
  rating           smallint check (rating between 1 and 5),
  rating_comment   text,
  custom_fields    jsonb not null default '{}'::jsonb,
  created_by       uuid references app.profiles(id),
  created_at       timestamptz not null default now(),
  updated_at       timestamptz not null default now(),
  unique (org_id, id),
  unique (org_id, number),
  foreign key (org_id, customer_id) references app.customers(org_id, id),
  foreign key (org_id, staff_id)    references app.staff_members(org_id, id) on delete set null (staff_id)
);
select app.add_updated_at_trigger('app.service_orders');
create index service_orders_org_status_idx on app.service_orders (org_id, status);

alter table app.appointments
  add foreign key (org_id, service_order_id) references app.service_orders(org_id, id) on delete set null (service_order_id);

create table app.service_order_items (
  id                uuid primary key default gen_random_uuid(),
  org_id            uuid not null,
  service_order_id  uuid not null,
  service_id        uuid,
  product_id        uuid,
  description       text not null,
  quantity          numeric(14,3) not null default 1 check (quantity > 0),
  unit_price_cents  bigint not null check (unit_price_cents >= 0),
  unit_cost_cents   bigint not null default 0 check (unit_cost_cents >= 0),
  commission_rate   numeric(5,4) not null default 0 check (commission_rate between 0 and 1),
  foreign key (org_id, service_order_id) references app.service_orders(org_id, id) on delete cascade,
  foreign key (org_id, service_id) references app.services(org_id, id) on delete set null (service_id),
  foreign key (org_id, product_id) references app.products(org_id, id) on delete set null (product_id)
);
