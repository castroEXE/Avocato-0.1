-- =====================================================================
-- AVOCATO · 0200 · Identidade, multi-tenancy, RBAC, planos e
-- configuração dinâmica do negócio.
-- =====================================================================

-- ---------------------------------------------------------------------
-- Catálogos globais (não pertencem a um tenant)
-- ---------------------------------------------------------------------

-- Módulos do Avocato. A IA liga/desliga por empresa em
-- organization_settings.enabled_modules.
create table app.modules (
  key          text primary key,
  name         text not null,
  description  text not null default '',
  depends_on   text[] not null default '{}',
  is_core      boolean not null default false   -- sempre ativo
);

-- Catálogo de permissões ("modulo.acao"). Fonte da verdade do RBAC.
create table app.permissions (
  key          text primary key check (key ~ '^[a-z_]+\.[a-z_]+$'),
  module_key   text not null references app.modules(key),
  description  text not null default ''
);

-- Planos (limites e recursos em JSON para evoluir sem migration).
create table app.plans (
  key            text primary key,
  name           text not null,
  price_cents    integer not null default 0 check (price_cents >= 0),
  currency       text not null default 'BRL',
  limits         jsonb not null default '{}'::jsonb,   -- {"users":5,"ai_requests_month":500,...}
  features       jsonb not null default '{}'::jsonb,   -- {"modules":["crm",...],"integrations":true}
  is_public      boolean not null default true,
  sort_order     integer not null default 0
);

-- ---------------------------------------------------------------------
-- Usuários (espelho de auth.users) e administradores da plataforma
-- ---------------------------------------------------------------------
create table app.profiles (
  id           uuid primary key references auth.users(id) on delete cascade,
  full_name    text not null default '',
  email        citext,
  avatar_url   text,
  locale       text not null default 'pt-BR',
  created_at   timestamptz not null default now(),
  updated_at   timestamptz not null default now()
);
select app.add_updated_at_trigger('app.profiles');

-- PLATFORM ADMIN ≠ TENANT USER. Quem está aqui é dono/operador da
-- plataforma. Ninguém entra aqui pela API: só via SQL (docs/SETUP.md).
create table app.platform_admins (
  user_id      uuid primary key references app.profiles(id) on delete cascade,
  granted_at   timestamptz not null default now(),
  granted_by   uuid references app.profiles(id),
  note         text
);

-- Cria o profile automaticamente quando alguém se cadastra no Supabase Auth
create or replace function app.handle_new_auth_user()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
begin
  insert into app.profiles (id, email, full_name)
  values (
    new.id,
    new.email,
    coalesce(new.raw_user_meta_data ->> 'full_name', new.raw_user_meta_data ->> 'name', '')
  )
  on conflict (id) do nothing;
  return new;
end $$;

create trigger on_auth_user_created
  after insert on auth.users
  for each row execute function app.handle_new_auth_user();

-- ---------------------------------------------------------------------
-- Organizations (tenants)
-- ---------------------------------------------------------------------
create table app.organizations (
  id            uuid primary key default gen_random_uuid(),
  name          text not null check (length(trim(name)) between 2 and 120),
  slug          text not null unique check (slug ~ '^[a-z0-9]+(-[a-z0-9]+)*$'),
  status        text not null default 'active'
                  check (status in ('active', 'suspended', 'closed')),
  timezone      text not null default 'America/Sao_Paulo',
  currency      text not null default 'BRL',
  country       text not null default 'BR',
  created_by    uuid not null references app.profiles(id),
  created_at    timestamptz not null default now(),
  updated_at    timestamptz not null default now()
);
select app.add_updated_at_trigger('app.organizations');

-- Papéis por organização (owner/admin/manager/staff/viewer + customizados)
create table app.roles (
  id           uuid primary key default gen_random_uuid(),
  org_id       uuid not null references app.organizations(id) on delete cascade,
  key          text not null check (key ~ '^[a-z][a-z0-9_]*$'),
  name         text not null,
  description  text not null default '',
  is_system    boolean not null default false,   -- não pode ser apagado
  created_at   timestamptz not null default now(),
  updated_at   timestamptz not null default now(),
  unique (org_id, key),
  unique (org_id, id)
);
select app.add_updated_at_trigger('app.roles');

create table app.role_permissions (
  org_id          uuid not null,
  role_id         uuid not null,
  permission_key  text not null references app.permissions(key) on delete cascade,
  primary key (role_id, permission_key),
  foreign key (org_id, role_id) references app.roles(org_id, id) on delete cascade
);

create table app.memberships (
  id           uuid primary key default gen_random_uuid(),
  org_id       uuid not null references app.organizations(id) on delete cascade,
  user_id      uuid not null references app.profiles(id) on delete cascade,
  role_id      uuid not null,
  status       text not null default 'active'
                 check (status in ('invited', 'active', 'disabled')),
  invited_by   uuid references app.profiles(id),
  created_at   timestamptz not null default now(),
  updated_at   timestamptz not null default now(),
  unique (org_id, user_id),
  unique (org_id, id),
  foreign key (org_id, role_id) references app.roles(org_id, id)
);
select app.add_updated_at_trigger('app.memberships');
create index memberships_user_idx on app.memberships(user_id) where status = 'active';

-- ---------------------------------------------------------------------
-- Contexto de tenant VALIDADO no banco.
-- Só devolve o org_id se o usuário corrente tiver membership ativa nele.
-- Mesmo que a API erre o header, o banco não entrega dados de outra
-- empresa. Usar nas policies como `(select app.current_org_id())` para o
-- Postgres avaliar uma única vez por consulta.
-- ---------------------------------------------------------------------
create or replace function app.current_org_id()
returns uuid
language plpgsql stable
security definer
set search_path = ''
as $$
declare
  v_org  uuid := nullif(current_setting('app.org_id', true), '')::uuid;
  v_user uuid := app.current_user_id();
begin
  if v_org is null or v_user is null then
    return null;
  end if;
  if exists (
    select 1
      from app.memberships m
      join app.organizations o on o.id = m.org_id
     where m.org_id = v_org
       and m.user_id = v_user
       and m.status = 'active'
       and o.status = 'active'
  ) then
    return v_org;
  end if;
  return null;
end $$;

-- Permissões efetivas do usuário corrente na org corrente
create or replace function app.current_permissions()
returns setof text
language sql stable
security definer
set search_path = ''
as $$
  select rp.permission_key
    from app.memberships m
    join app.role_permissions rp on rp.role_id = m.role_id
   where m.org_id = app.current_org_id()
     and m.user_id = app.current_user_id()
     and m.status = 'active'
$$;

create or replace function app.has_permission(p_key text)
returns boolean
language sql stable
security definer
set search_path = ''
as $$
  select exists (select 1 from app.current_permissions() k where k = p_key)
$$;

create or replace function app.is_platform_admin(p_user uuid)
returns boolean
language sql stable
security definer
set search_path = ''
as $$
  select exists (select 1 from app.platform_admins where user_id = p_user)
$$;

-- ---------------------------------------------------------------------
-- Assinatura (1 por organização)
-- ---------------------------------------------------------------------
create table app.subscriptions (
  org_id              uuid primary key references app.organizations(id) on delete cascade,
  plan_key            text not null references app.plans(key),
  status              text not null default 'trialing'
                        check (status in ('trialing', 'active', 'past_due', 'canceled', 'paused')),
  trial_ends_at       timestamptz,
  current_period_end  timestamptz,
  provider            text,               -- 'stripe' futuramente
  provider_customer_ref     text,
  provider_subscription_ref text,
  created_at          timestamptz not null default now(),
  updated_at          timestamptz not null default now()
);
select app.add_updated_at_trigger('app.subscriptions');

-- ---------------------------------------------------------------------
-- Configuração dinâmica do negócio (seção 24 do documento).
-- Tudo o que a IA decide no onboarding mora aqui, em metadata —
-- nada de `if businessType === 'petshop'` no código.
-- ---------------------------------------------------------------------
create table app.organization_settings (
  org_id                 uuid primary key references app.organizations(id) on delete cascade,
  onboarding_status      text not null default 'pending'
                           check (onboarding_status in ('pending', 'in_progress', 'completed')),
  business_profile       jsonb not null default '{}'::jsonb,  -- segmento, porte, unidades, horários, modelo de atendimento
  enabled_modules        jsonb not null default '{}'::jsonb,  -- {"crm":true,"fleet":false,...}
  terminology            jsonb not null default '{}'::jsonb,  -- {"customer":"Tutor","service_order":"Atendimento"}
  workflow_configuration jsonb not null default '{}'::jsonb,
  dashboard_configuration jsonb not null default '{}'::jsonb, -- KPIs e widgets definidos pela IA
  ai_configuration       jsonb not null default '{}'::jsonb,
  created_at             timestamptz not null default now(),
  updated_at             timestamptz not null default now()
);
select app.add_updated_at_trigger('app.organization_settings');

-- Campos personalizados por entidade (seção 25)
create table app.custom_field_definitions (
  id           uuid primary key default gen_random_uuid(),
  org_id       uuid not null references app.organizations(id) on delete cascade,
  entity       text not null check (entity in (
                 'customer', 'lead', 'opportunity', 'service', 'product',
                 'appointment', 'service_order', 'staff_member', 'supplier')),
  key          text not null check (key ~ '^[a-z][a-z0-9_]{0,48}$'),
  label        text not null,
  field_type   text not null check (field_type in (
                 'text', 'long_text', 'number', 'currency', 'date', 'boolean',
                 'select', 'multi_select', 'phone', 'email', 'url')),
  options      jsonb not null default '[]'::jsonb,   -- para select/multi_select
  is_required  boolean not null default false,
  position     integer not null default 0,
  is_active    boolean not null default true,
  created_at   timestamptz not null default now(),
  updated_at   timestamptz not null default now(),
  unique (org_id, entity, key),
  unique (org_id, id)
);
select app.add_updated_at_trigger('app.custom_field_definitions');

-- Numeração sequencial por empresa (OS #1042, etc.) sem vazar entre tenants
create table app.org_counters (
  org_id   uuid not null references app.organizations(id) on delete cascade,
  key      text not null,
  value    bigint not null default 0,
  primary key (org_id, key)
);

create or replace function app.next_number(p_key text)
returns bigint
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_org uuid := app.current_org_id();
  v_val bigint;
begin
  if v_org is null then
    raise exception 'tenant context ausente' using errcode = '42501';
  end if;
  insert into app.org_counters as c (org_id, key, value)
  values (v_org, p_key, 1)
  on conflict (org_id, key) do update set value = c.value + 1
  returning value into v_val;
  return v_val;
end $$;
