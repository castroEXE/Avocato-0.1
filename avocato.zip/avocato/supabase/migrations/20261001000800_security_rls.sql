-- =====================================================================
-- AVOCATO · 0800 · Grants e Row Level Security.
-- Fica por último para cobrir todas as tabelas. Toda migration nova que
-- criar tabela de tenant deve repetir o bloco do final deste arquivo.
--
-- Modelo:
--   • avocato_app       → só vê linhas onde org_id = app.current_org_id()
--                         (contexto VALIDADO contra memberships)
--   • avocato_platform  → Super Admin: leitura cross-tenant, sem escrita
--                         em dados de negócio
--   • anon/authenticated (Data API do Supabase) → nenhum acesso ao schema
--   • FORCE ROW LEVEL SECURITY em todas as tabelas
-- =====================================================================

-- Funções: ninguém executa por padrão; liberamos só o necessário.
revoke execute on all functions in schema app from public;
grant execute on function
  app.current_user_id(),
  app.current_org_id(),
  app.current_permissions(),
  app.has_permission(text),
  app.next_number(text),
  app.create_organization(text, text, text),
  app.am_i_platform_admin()
to avocato_app;
grant execute on function app.current_user_id(), app.am_i_platform_admin() to avocato_platform;

-- Catálogos globais: só leitura, sem RLS (não são dados de tenant)
grant select on app.modules, app.permissions, app.plans, app.role_templates to avocato_app, avocato_platform;

-- Leitura total para o Super Admin (as policies abaixo liberam as linhas)
grant select on all tables in schema app to avocato_platform;
revoke select on app.platform_admins from avocato_platform;
grant select on app.platform_admins to avocato_platform;
grant update (status) on app.organizations to avocato_platform;
grant update (plan_key, status, trial_ends_at, current_period_end) on app.subscriptions to avocato_platform;
grant insert on app.audit_logs to avocato_platform;

-- ---------------------------------------------------------------------
-- Tabelas de tenant "comuns": CRUD isolado por org_id
-- ---------------------------------------------------------------------
do $$
declare
  t text;
  tenant_tables text[] := array[
    'roles', 'role_permissions', 'custom_field_definitions',
    'customers', 'leads', 'pipelines', 'pipeline_stages', 'opportunities', 'activities', 'tasks',
    'staff_members', 'staff_availability', 'schedule_blocks', 'suppliers', 'products', 'stock_movements',
    'services', 'service_materials', 'appointments', 'service_orders', 'service_order_items',
    'bank_accounts', 'financial_categories', 'recurring_rules', 'financial_entries', 'transactions', 'payment_intents',
    'integrations', 'domain_events', 'automations', 'automation_runs', 'notifications', 'documents',
    'ai_conversations', 'ai_messages', 'ai_actions'
  ];
begin
  foreach t in array tenant_tables loop
    execute format('alter table app.%I enable row level security', t);
    execute format('alter table app.%I force row level security', t);
    execute format('grant select, insert, update, delete on app.%I to avocato_app', t);
    execute format($p$
      create policy tenant_isolation on app.%I
        for all to avocato_app
        using (org_id = (select app.current_org_id()))
        with check (org_id = (select app.current_org_id()))$p$, t);
    execute format('create policy platform_read on app.%I for select to avocato_platform using (true)', t);
  end loop;
end $$;

-- O usuário enxerga o próprio papel em todas as empresas (tela "Minhas empresas")
create policy own_role_read on app.roles for select to avocato_app
  using (id in (select m.role_id from app.memberships m
                 where m.user_id = (select app.current_user_id()) and m.status = 'active'));

-- Movimentações de estoque e eventos são append-only para a API
revoke update, delete on app.stock_movements, app.domain_events from avocato_app;
grant update (processed_at, attempts) on app.domain_events to avocato_app;

-- Ações da IA não são apagadas pela API (histórico de decisões)
revoke delete on app.ai_actions from avocato_app;

-- Views financeiras herdam o RLS da tabela base (security_invoker)
grant select on app.accounts_payable, app.accounts_receivable to avocato_app, avocato_platform;

-- ---------------------------------------------------------------------
-- Tabelas com regras específicas
-- ---------------------------------------------------------------------

-- organizations: o usuário vê as empresas das quais é membro (para
-- escolher em qual entrar) e edita só a empresa do contexto atual.
-- Criação acontece somente via app.create_organization().
alter table app.organizations enable row level security;
alter table app.organizations force row level security;
grant select, update (name, timezone, currency, country) on app.organizations to avocato_app;
create policy org_member_read on app.organizations for select to avocato_app
  using (
    id = (select app.current_org_id())
    or id in (select m.org_id from app.memberships m
               where m.user_id = (select app.current_user_id()) and m.status = 'active')
  );
create policy org_update_current on app.organizations for update to avocato_app
  using (id = (select app.current_org_id()))
  with check (id = (select app.current_org_id()));
create policy platform_read on app.organizations for select to avocato_platform using (true);
create policy platform_update on app.organizations for update to avocato_platform using (true) with check (true);

-- memberships: a pessoa enxerga os próprios vínculos (lista de empresas)
-- e, dentro da empresa atual, os vínculos da equipe.
alter table app.memberships enable row level security;
alter table app.memberships force row level security;
grant select, insert, update, delete on app.memberships to avocato_app;
create policy membership_read on app.memberships for select to avocato_app
  using (org_id = (select app.current_org_id()) or user_id = (select app.current_user_id()));
create policy membership_write on app.memberships for insert to avocato_app
  with check (org_id = (select app.current_org_id()));
create policy membership_update on app.memberships for update to avocato_app
  using (org_id = (select app.current_org_id()))
  with check (org_id = (select app.current_org_id()));
create policy membership_delete on app.memberships for delete to avocato_app
  using (org_id = (select app.current_org_id()));
create policy platform_read on app.memberships for select to avocato_platform using (true);

-- profiles: o próprio perfil e os colegas da empresa atual
alter table app.profiles enable row level security;
alter table app.profiles force row level security;
grant select, update (full_name, avatar_url, locale) on app.profiles to avocato_app;
create policy profile_read on app.profiles for select to avocato_app
  using (
    id = (select app.current_user_id())
    or id in (select m.user_id from app.memberships m where m.org_id = (select app.current_org_id()))
  );
create policy profile_update_self on app.profiles for update to avocato_app
  using (id = (select app.current_user_id()))
  with check (id = (select app.current_user_id()));
create policy platform_read on app.profiles for select to avocato_platform using (true);

-- organization_settings: leitura e edição na empresa atual (sem insert/delete)
alter table app.organization_settings enable row level security;
alter table app.organization_settings force row level security;
grant select, update on app.organization_settings to avocato_app;
create policy tenant_isolation on app.organization_settings for all to avocato_app
  using (org_id = (select app.current_org_id()))
  with check (org_id = (select app.current_org_id()));
create policy platform_read on app.organization_settings for select to avocato_platform using (true);

-- subscriptions: a empresa só lê; quem altera é cobrança/Super Admin
alter table app.subscriptions enable row level security;
alter table app.subscriptions force row level security;
grant select on app.subscriptions to avocato_app;
create policy tenant_read on app.subscriptions for select to avocato_app
  using (org_id = (select app.current_org_id()));
create policy platform_read on app.subscriptions for select to avocato_platform using (true);
create policy platform_update on app.subscriptions for update to avocato_platform using (true) with check (true);

-- audit_logs: append-only. A empresa lê e grava o próprio log; o
-- Super Admin lê tudo e grava ações de plataforma (org_id pode ser nulo).
alter table app.audit_logs enable row level security;
alter table app.audit_logs force row level security;
grant select, insert on app.audit_logs to avocato_app;
create policy tenant_read on app.audit_logs for select to avocato_app
  using (org_id = (select app.current_org_id()));
create policy tenant_insert on app.audit_logs for insert to avocato_app
  with check (org_id = (select app.current_org_id()) and actor_type <> 'platform_admin');
create policy platform_read on app.audit_logs for select to avocato_platform using (true);
create policy platform_insert on app.audit_logs for insert to avocato_platform
  with check (actor_type = 'platform_admin');

-- org_counters: só via app.next_number()
alter table app.org_counters enable row level security;
alter table app.org_counters force row level security;
revoke all on app.org_counters from avocato_app;

-- platform_admins: invisível para tenants; o Super Admin lê
alter table app.platform_admins enable row level security;
alter table app.platform_admins force row level security;
revoke all on app.platform_admins from avocato_app;
create policy platform_read on app.platform_admins for select to avocato_platform using (true);

-- ---------------------------------------------------------------------
-- Funções SECURITY DEFINER rodam como o dono das tabelas. Com FORCE RLS
-- o dono também é filtrado, então liberamos explicitamente o dono
-- (papel que roda as migrations) só nas tabelas que essas funções tocam.
-- ---------------------------------------------------------------------
do $$
declare
  t text;
  definer_tables text[] := array[
    'profiles', 'organizations', 'roles', 'role_permissions', 'memberships',
    'organization_settings', 'subscriptions', 'pipelines', 'pipeline_stages',
    'financial_categories', 'audit_logs', 'org_counters', 'platform_admins'
  ];
begin
  foreach t in array definer_tables loop
    execute format('create policy definer_owner on app.%I for all to %I using (true) with check (true)', t, current_user);
  end loop;
end $$;
