"use client";

import { useEffect, useId, useRef, useState } from "react";
import clsx from "clsx";
import { Search, UserPlus, X } from "lucide-react";
import { api } from "@/lib/api";
import { useSession } from "@/lib/session";
import type { Customer } from "@/lib/types";
import { useClickOutside } from "@/lib/useClickOutside";
import { Spinner } from "@/components/ui/misc";

type Picked = { id: string; name: string; phone?: string | null };

/** Busca de cliente com cadastro rápido ali mesmo. */
export default function CustomerPicker({ value, onChange, label, error, required }: {
  value: Picked | null; onChange: (c: Picked | null) => void; label?: string; error?: string; required?: boolean;
}) {
  const id = useId();
  const { term, can } = useSession();
  const [q, setQ] = useState("");
  const [open, setOpen] = useState(false);
  const [results, setResults] = useState<Customer[]>([]);
  const [loading, setLoading] = useState(false);
  const [creating, setCreating] = useState(false);
  const [phone, setPhone] = useState("");
  const ref = useRef<HTMLDivElement>(null);
  useClickOutside(ref, () => setOpen(false), open);

  useEffect(() => {
    if (!open) return;
    const t = setTimeout(async () => {
      setLoading(true);
      try {
        const r = await api<{ data: Customer[] }>(`/customers?limit=8${q.trim() ? `&q=${encodeURIComponent(q.trim())}` : ""}`);
        setResults(r.data);
      } finally {
        setLoading(false);
      }
    }, 220);
    return () => clearTimeout(t);
  }, [q, open]);

  async function quickCreate() {
    setLoading(true);
    try {
      const c = await api<Customer>("/customers", { method: "POST", body: { name: q.trim(), phone: phone.trim() || null } });
      onChange({ id: c.id, name: c.name, phone: c.phone });
      setOpen(false);
      setCreating(false);
      setQ("");
      setPhone("");
    } finally {
      setLoading(false);
    }
  }

  const name = term("customers", "Clientes").replace(/s$/, "");
  return (
    <div ref={ref} className="relative">
      <label htmlFor={id} className="field-label">
        {label ?? name}{required && <span className="text-rose-500" aria-hidden="true"> *</span>}
      </label>
      {value ? (
        <div className="flex h-11 items-center justify-between rounded-xl border border-primary-200 bg-primary-50 px-3.5 text-sm">
          <span className="font-medium text-primary-dark">{value.name}{value.phone && <span className="ml-2 font-normal text-slate-500">{value.phone}</span>}</span>
          <button type="button" onClick={() => onChange(null)} aria-label="Trocar" className="text-slate-400 hover:text-slate-600"><X className="h-4 w-4" /></button>
        </div>
      ) : (
        <div className="relative">
          <Search className="pointer-events-none absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
          <input id={id} value={q} onChange={(e) => { setQ(e.target.value); setOpen(true); setCreating(false); }} onFocus={() => setOpen(true)}
            placeholder={`Buscar ou cadastrar ${name.toLowerCase()}`} autoComplete="off" role="combobox" aria-expanded={open} aria-controls={`${id}-list`}
            className={clsx("input pl-10", error && "border-rose-300")} />
          {loading && <Spinner className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400" />}
        </div>
      )}
      {error && <p className="field-error">{error}</p>}

      {open && !value && (
        <div id={`${id}-list`} role="listbox" className="absolute left-0 right-0 z-20 mt-1 max-h-72 overflow-y-auto rounded-xl bg-white p-1.5 shadow-card-hover ring-1 ring-slate-100">
          {results.map((c) => (
            <button key={c.id} type="button" role="option" aria-selected="false"
              onClick={() => { onChange({ id: c.id, name: c.name, phone: c.phone }); setOpen(false); setQ(""); }}
              className="flex w-full items-center justify-between rounded-lg px-3 py-2 text-left text-sm hover:bg-primary-50">
              <span className="font-medium text-slate-700">{c.name}</span>
              <span className="text-xs text-slate-400">{c.phone ?? c.email ?? ""}</span>
            </button>
          ))}
          {!loading && results.length === 0 && !q.trim() && <p className="px-3 py-2 text-sm text-slate-400">Digite o nome para buscar.</p>}
          {q.trim().length >= 2 && can("customers.create") && (
            creating ? (
              <div className="space-y-2 rounded-lg bg-slate-50 p-3">
                <p className="text-sm font-medium text-slate-700">Novo: {q.trim()}</p>
                <input className="input h-9" type="tel" placeholder="Telefone / WhatsApp (opcional)" value={phone} onChange={(e) => setPhone(e.target.value)} />
                <button type="button" onClick={quickCreate} disabled={loading} className="btn btn-primary btn-sm w-full">Cadastrar e usar</button>
              </div>
            ) : (
              <button type="button" onClick={() => setCreating(true)} className="flex w-full items-center gap-2 rounded-lg px-3 py-2 text-sm font-medium text-primary hover:bg-primary-50">
                <UserPlus className="h-4 w-4" /> Cadastrar “{q.trim()}”
              </button>
            )
          )}
        </div>
      )}
    </div>
  );
}
