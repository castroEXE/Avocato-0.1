"use client";

import { useEffect, useState } from "react";
import { useSWRConfig } from "swr";
import { Plus, Trash2 } from "lucide-react";
import CustomerPicker from "./CustomerPicker";
import Modal from "@/components/ui/Modal";
import { MoneyField, SelectField, TextArea, TextField } from "@/components/ui/fields";
import { Spinner } from "@/components/ui/misc";
import { useToast } from "@/components/ui/toast";
import { api, ApiError } from "@/lib/api";
import { brl, isoToLocalInput, localInputToISO } from "@/lib/format";
import { invalidate, useApi } from "@/lib/hooks";
import type { Service, ServiceOrder, StaffMember } from "@/lib/types";

type Item = { key: string; serviceId: string; description: string; quantity: string; unitPriceCents: number | null };
const newItem = (): Item => ({ key: Math.random().toString(36).slice(2), serviceId: "", description: "", quantity: "1", unitPriceCents: null });

export default function OrderForm({ open, onClose, order, initialCustomer, onSaved }: {
  open: boolean; onClose: () => void; order: ServiceOrder | null;
  initialCustomer?: { id: string; name: string; phone?: string | null } | null; onSaved?: (o: ServiceOrder) => void;
}) {
  const toast = useToast();
  const { mutate } = useSWRConfig();
  const { data: services } = useApi<{ data: Service[] }>(open ? "/services" : null);
  const { data: staff } = useApi<{ data: StaffMember[] }>(open ? "/staff" : null);
  const [customer, setCustomer] = useState<{ id: string; name: string; phone?: string | null } | null>(null);
  const [staffId, setStaffId] = useState("");
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [when, setWhen] = useState("");
  const [items, setItems] = useState<Item[]>([newItem()]);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!open) return;
    setError(null);
    setCustomer(order ? { id: order.customer.id, name: order.customer.name, phone: order.customer.phone } : initialCustomer ?? null);
    setStaffId(order?.staff?.id ?? "");
    setTitle(order?.title ?? "");
    setDescription(order?.description ?? "");
    setWhen(isoToLocalInput(order?.scheduledFor));
    setItems(order?.items?.length
      ? order.items.map((i) => ({ key: i.id, serviceId: i.serviceId ?? "", description: i.serviceId ? "" : i.description, quantity: String(i.quantity), unitPriceCents: i.unitPriceCents }))
      : [newItem()]);
  }, [open, order, initialCustomer]);

  const priceOf = (i: Item) => i.unitPriceCents ?? services?.data.find((s) => s.id === i.serviceId)?.priceCents ?? 0;
  const total = items.reduce((a, i) => a + Math.round((Number(i.quantity) || 0) * priceOf(i)), 0);
  const update = (key: string, patch: Partial<Item>) => setItems((list) => list.map((i) => (i.key === key ? { ...i, ...patch } : i)));

  async function save(e: React.FormEvent) {
    e.preventDefault();
    if (!customer) { setError("Escolha o cliente."); return; }
    const validItems = items.filter((i) => i.serviceId || i.description.trim());
    setBusy(true);
    setError(null);
    const body = {
      customerId: customer.id, staffId: staffId || null, title: title.trim() || null, description: description.trim() || null,
      scheduledFor: localInputToISO(when),
      items: validItems.map((i) => ({
        serviceId: i.serviceId || null, description: i.serviceId ? null : i.description.trim(),
        quantity: Number(i.quantity) || 1, unitPriceCents: i.unitPriceCents,
      })),
    };
    try {
      const saved = await api<ServiceOrder>(order ? `/service-orders/${order.id}` : "/service-orders", { method: order ? "PATCH" : "POST", body });
      await invalidate(mutate, "/service-orders", "/dashboard", "/customers");
      toast(order ? "OS atualizada." : `OS #${String(saved.number).padStart(4, "0")} criada.`);
      onSaved?.(saved);
      onClose();
    } catch (err) {
      setError(err instanceof ApiError ? err.message : "Não foi possível salvar.");
    } finally {
      setBusy(false);
    }
  }

  const activeServices = services?.data.filter((s) => s.isActive) ?? [];
  return (
    <Modal open={open} onClose={onClose} title={order ? `Editar OS #${String(order.number).padStart(4, "0")}` : "Nova ordem de serviço"} size="xl"
      footer={<>
        <p className="mr-auto self-center text-sm text-slate-500">Total: <strong className="text-lg text-slate-900">{brl(total)}</strong></p>
        <button type="button" className="btn btn-ghost" onClick={onClose}>Cancelar</button>
        <button type="submit" form="order-form" className="btn btn-primary" disabled={busy}>{busy && <Spinner />} {order ? "Salvar alterações" : "Abrir OS"}</button>
      </>}>
      <form id="order-form" onSubmit={save} className="grid gap-4 md:grid-cols-2">
        <CustomerPicker value={customer} onChange={setCustomer} required />
        <SelectField label="Profissional responsável" value={staffId} onChange={(e) => setStaffId(e.target.value)} placeholder="Ninguém por enquanto"
          options={(staff?.data ?? []).map((s) => ({ value: s.id, label: s.jobTitle ? `${s.name} · ${s.jobTitle}` : s.name }))} />
        <TextField label="Título" value={title} onChange={(e) => setTitle(e.target.value)} placeholder="Se vazio, usamos o primeiro serviço" />
        <TextField label="Data e hora (opcional)" type="datetime-local" value={when} onChange={(e) => setWhen(e.target.value)} hint="Com data, a OS já fica como agendada." />

        <fieldset className="md:col-span-2">
          <legend className="field-label">Serviços e itens</legend>
          <div className="space-y-2">
            {items.map((i) => (
              <div key={i.key} className="grid grid-cols-12 items-end gap-2 rounded-xl bg-slate-50 p-2.5">
                <div className="col-span-12 sm:col-span-5">
                  <label className="sr-only" htmlFor={`svc-${i.key}`}>Serviço</label>
                  <select id={`svc-${i.key}`} className="input h-10" value={i.serviceId}
                    onChange={(e) => update(i.key, { serviceId: e.target.value, unitPriceCents: null })}>
                    <option value="">Item avulso (descrever)</option>
                    {activeServices.map((s) => <option key={s.id} value={s.id}>{s.name} · {brl(s.priceCents)}</option>)}
                  </select>
                  {!i.serviceId && (
                    <input className="input mt-2 h-10" placeholder="Descrição do item" value={i.description} aria-label="Descrição do item"
                      onChange={(e) => update(i.key, { description: e.target.value })} />
                  )}
                </div>
                <div className="col-span-3 sm:col-span-2">
                  <label className="text-xs text-slate-500" htmlFor={`qty-${i.key}`}>Qtd.</label>
                  <input id={`qty-${i.key}`} className="input h-10" type="number" min={0.01} step="any" value={i.quantity} onChange={(e) => update(i.key, { quantity: e.target.value })} />
                </div>
                <div className="col-span-6 sm:col-span-3">
                  <MoneyField label="Preço unit." value={priceOf(i)} onChange={(v) => update(i.key, { unitPriceCents: v })} />
                </div>
                <div className="col-span-3 flex items-center justify-end gap-1 sm:col-span-2">
                  <span className="hidden text-sm font-medium text-slate-700 sm:inline">{brl(Math.round((Number(i.quantity) || 0) * priceOf(i)))}</span>
                  <button type="button" aria-label="Remover item" disabled={items.length === 1} onClick={() => setItems((l) => l.filter((x) => x.key !== i.key))}
                    className="icon-btn text-slate-400 hover:bg-rose-50 hover:text-rose-600 disabled:opacity-30"><Trash2 className="h-4 w-4" /></button>
                </div>
              </div>
            ))}
          </div>
          <button type="button" className="btn btn-soft btn-sm mt-2" onClick={() => setItems((l) => [...l, newItem()])}><Plus className="h-4 w-4" /> Adicionar item</button>
        </fieldset>

        <TextArea className="md:col-span-2" label="Descrição / observações" value={description} onChange={(e) => setDescription(e.target.value)} placeholder="O que precisa ser feito, endereço, materiais…" />
        {error && <p role="alert" className="rounded-xl bg-rose-50 px-3 py-2.5 text-sm text-rose-700 md:col-span-2">{error}</p>}
      </form>
    </Modal>
  );
}
