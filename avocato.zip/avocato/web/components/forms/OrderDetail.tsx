"use client";

import { useState } from "react";
import clsx from "clsx";
import { useSWRConfig } from "swr";
import { Bot, CalendarClock, Globe, MessageCircle, Pencil, Star, UserRound, Wallet } from "lucide-react";
import Modal from "@/components/ui/Modal";
import { Badge, ListSkeleton, Spinner } from "@/components/ui/misc";
import { useToast } from "@/components/ui/toast";
import { api, ApiError } from "@/lib/api";
import { brl, dateBR, dateTimeBR, orderNumber, whatsappLink } from "@/lib/format";
import { invalidate, useApi } from "@/lib/hooks";
import { ORDER_ACTIONS, STATUS_META } from "@/lib/orders";
import { useSession } from "@/lib/session";
import type { OrderStatus, ServiceOrder } from "@/lib/types";

export default function OrderDetail({ id, onClose, onEdit }: { id: string | null; onClose: () => void; onEdit: (o: ServiceOrder) => void }) {
  const { can, context } = useSession();
  const toast = useToast();
  const { mutate } = useSWRConfig();
  const { data: o, mutate: reload } = useApi<ServiceOrder>(id ? `/service-orders/${id}` : null);
  const [busy, setBusy] = useState<string | null>(null);
  const [hover, setHover] = useState(0);

  if (!id) return null;

  async function run(key: string, fn: () => Promise<unknown>, okMessage: string) {
    setBusy(key);
    try {
      await fn();
      await Promise.all([reload(), invalidate(mutate, "/service-orders", "/dashboard", "/finance", "/notifications")]);
      toast(okMessage);
    } catch (err) {
      toast(err instanceof ApiError ? err.message : "Algo deu errado.", "error");
    } finally {
      setBusy(null);
    }
  }

  const DONE_MSG: Record<OrderStatus, string> = {
    requested: "OS voltou para solicitação.", open: o?.status === "requested" ? "Solicitação aprovada. Agora é só executar!" : "OS reaberta.",
    scheduled: "OS agendada.", in_progress: o?.status === "done" ? "OS reaberta para ajustes." : "Serviço iniciado.",
    done: o?.totalCents ? "Serviço concluído! A conta a receber já está no financeiro." : "Serviço concluído!", canceled: "OS cancelada.",
  };
  const changeStatus = (to: OrderStatus) =>
    run(to, () => api(`/service-orders/${id}/status`, { method: "POST", body: { status: to } }), DONE_MSG[to]);

  const firstName = o?.customer.name.split(" ")[0] ?? "";
  const wa = o && whatsappLink(o.customer.phone,
    `Olá, ${firstName}! Aqui é da ${context?.organization.name}. Sobre a sua OS ${orderNumber(o.number)} (${o.title ?? "serviço"}): `);

  return (
    <Modal open onClose={onClose} size="lg"
      title={o ? `OS ${orderNumber(o.number)} · ${o.title ?? "Serviço"}` : "Ordem de serviço"}
      description={o ? `Aberta em ${dateTimeBR(o.createdAt)}` : undefined}>
      {!o ? <ListSkeleton rows={4} /> : (
        <div className="space-y-5">
          <div className="flex flex-wrap items-center gap-2">
            <Badge tone={STATUS_META[o.status].tone}>{STATUS_META[o.status].label}</Badge>
            {o.source === "public_request" && <Badge tone="amber"><Globe className="h-3 w-3" /> Pedido pelo link</Badge>}
            {o.source === "ai" && <Badge tone="violet"><Bot className="h-3 w-3" /> Criada pela IA</Badge>}
          </div>

          {can("service_orders.update") && (
            <div className="flex flex-wrap gap-2">
              {ORDER_ACTIONS[o.status].map((a) => (
                <button key={a.to} type="button" disabled={!!busy} onClick={() => changeStatus(a.to)}
                  className={clsx("btn btn-sm", a.primary ? "btn-primary" : a.danger ? "btn-danger-soft" : "btn-outline")}>
                  {busy === a.to && <Spinner />} {a.label}
                </button>
              ))}
              {o.status !== "done" && o.status !== "canceled" && (
                <button type="button" className="btn btn-ghost btn-sm" onClick={() => onEdit(o)}><Pencil className="h-4 w-4" /> Editar</button>
              )}
            </div>
          )}

          <div className="grid gap-3 sm:grid-cols-2">
            <div className="rounded-xl bg-slate-50 p-3">
              <p className="flex items-center gap-1.5 text-xs text-slate-500"><UserRound className="h-3.5 w-3.5" /> Cliente</p>
              <p className="mt-0.5 font-medium text-slate-800">{o.customer.name}</p>
              <p className="text-sm text-slate-500">{[o.customer.phone, o.customer.email].filter(Boolean).join(" · ") || "Sem contato"}</p>
              {wa && <a href={wa} target="_blank" rel="noreferrer" className="mt-2 inline-flex items-center gap-1.5 text-sm font-medium text-primary hover:underline"><MessageCircle className="h-4 w-4" /> Avisar no WhatsApp</a>}
            </div>
            <div className="rounded-xl bg-slate-50 p-3">
              <p className="flex items-center gap-1.5 text-xs text-slate-500"><CalendarClock className="h-3.5 w-3.5" /> Execução</p>
              <p className="mt-0.5 font-medium text-slate-800">{o.staff?.name ?? "Sem responsável"}</p>
              <p className="text-sm text-slate-500">
                {o.scheduledFor ? `Marcada para ${dateTimeBR(o.scheduledFor)}` : o.preferredDate ? `Cliente prefere ${dateBR(o.preferredDate)}` : "Sem data marcada"}
              </p>
              {o.completedAt && <p className="text-sm text-primary">Concluída em {dateTimeBR(o.completedAt)}</p>}
            </div>
          </div>

          {o.description && <p className="whitespace-pre-line rounded-xl bg-amber-50/60 p-3 text-sm text-slate-700">{o.description}</p>}

          <div className="overflow-hidden rounded-xl ring-1 ring-slate-100">
            <table className="w-full">
              <thead className="bg-slate-50"><tr><th className="table-head">Item</th><th className="table-head text-right">Qtd.</th><th className="table-head text-right">Valor</th></tr></thead>
              <tbody className="divide-y divide-slate-100">
                {o.items?.length ? o.items.map((i) => (
                  <tr key={i.id}><td className="table-cell">{i.description}</td><td className="table-cell text-right">{i.quantity}</td><td className="table-cell text-right">{brl(i.totalCents)}</td></tr>
                )) : <tr><td colSpan={3} className="table-cell text-center text-slate-400">Sem itens — edite a OS para adicionar.</td></tr>}
              </tbody>
              <tfoot><tr className="bg-primary-50/60"><td colSpan={2} className="table-cell font-medium">Total</td><td className="table-cell text-right text-base font-semibold text-slate-900">{brl(o.totalCents)}</td></tr></tfoot>
            </table>
          </div>

          {o.receivable && (
            <div className="flex flex-wrap items-center gap-3 rounded-xl bg-secondary-50 p-3">
              <Wallet className="h-5 w-5 text-secondary" />
              <p className="flex-1 text-sm text-slate-700">
                Conta a receber: <strong>{brl(o.receivable.amountCents)}</strong>
                {o.receivable.status === "paid" ? " · recebida ✓" : o.receivable.paidAmountCents > 0 ? ` · ${brl(o.receivable.paidAmountCents)} recebido` : " · aguardando pagamento"}
              </p>
              {o.receivable.status !== "paid" && can("finance.manage") && (
                <button type="button" className="btn btn-primary btn-sm" disabled={!!busy}
                  onClick={() => run("pay", () => api(`/finance/entries/${o.receivable!.id}/pay`, { method: "POST", body: {} }), "Pagamento registrado no caixa.")}>
                  {busy === "pay" && <Spinner />} Registrar pagamento
                </button>
              )}
            </div>
          )}

          {o.status === "done" && (
            <div>
              <p className="mb-1 text-sm font-medium text-slate-700">Avaliação do cliente</p>
              <div className="flex items-center gap-1" onMouseLeave={() => setHover(0)}>
                {[1, 2, 3, 4, 5].map((n) => (
                  <button key={n} type="button" aria-label={`${n} estrela${n > 1 ? "s" : ""}`} disabled={!can("service_orders.update")}
                    onMouseEnter={() => setHover(n)}
                    onClick={() => run("rate", () => api(`/service-orders/${o.id}/rating`, { method: "POST", body: { rating: n } }), "Avaliação registrada.")}>
                    <Star className={clsx("h-6 w-6 transition-colors", (hover || o.rating || 0) >= n ? "fill-amber-400 text-amber-400" : "text-slate-300")} />
                  </button>
                ))}
                {o.rating && <span className="ml-2 text-sm text-slate-500">{o.rating} de 5</span>}
              </div>
            </div>
          )}
        </div>
      )}
    </Modal>
  );
}
