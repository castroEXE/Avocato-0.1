/** O mascote: um abacate cortado, com olhinhos e bochechas. */
export default function AvocadoMark({ size = 32, className }: { size?: number; className?: string }) {
  return (
    <svg width={size} height={size} viewBox="0 0 64 64" aria-hidden="true" className={className}>
      <path d="M32 3c-9.4 0-14.6 9.2-16.2 17.4C13.8 30.9 9 36.2 9 44.3 9 54.8 19.3 62 32 62s23-7.2 23-17.7c0-8.1-4.8-13.4-6.8-23.9C46.6 12.2 41.4 3 32 3z" fill="#355e2b" />
      <path d="M32 8.2c-6.9 0-11 7.7-12.3 14.6-2 10.3-6.4 14.3-6.4 21.6 0 8.3 8.3 13.5 18.7 13.5s18.7-5.2 18.7-13.5c0-7.3-4.4-11.3-6.4-21.6C43 15.9 38.9 8.2 32 8.2z" fill="#b8d96a" />
      <path d="M32 11.5c-5.3 0-8.6 6.4-9.7 12.1-1.7 8.8-5.7 12.3-5.7 18.9 0 6.9 7 11.1 15.4 11.1s15.4-4.2 15.4-11.1c0-6.6-4-10.1-5.7-18.9-1.1-5.7-4.4-12.1-9.7-12.1z" fill="#e3f2a6" />
      <circle cx="32" cy="43.5" r="8.6" fill="#9b6638" />
      <circle cx="29.2" cy="40.6" r="2.4" fill="#c38c58" />
      <ellipse cx="26.6" cy="26.2" rx="2.3" ry="2.9" fill="#1f2a1a" />
      <ellipse cx="37.4" cy="26.2" rx="2.3" ry="2.9" fill="#1f2a1a" />
      <circle cx="27.4" cy="25.1" r=".9" fill="#fff" />
      <circle cx="38.2" cy="25.1" r=".9" fill="#fff" />
      <ellipse cx="22.7" cy="30.4" rx="2.5" ry="1.5" fill="#f19a8f" opacity=".75" />
      <ellipse cx="41.3" cy="30.4" rx="2.5" ry="1.5" fill="#f19a8f" opacity=".75" />
      <path d="M29.6 30.2q2.4 2.3 4.8 0" fill="none" stroke="#1f2a1a" strokeWidth="1.5" strokeLinecap="round" />
    </svg>
  );
}
