"use client";

import { useEffect, useState } from "react";
import clsx from "clsx";
import { defaultAvatar, renderAvatar } from "@/lib/avatar";
import type { AvatarConfig } from "@/lib/types";

const memo = new Map<string, string>();

export default function UserAvatar({ avatar, name, size = 36, className }: {
  avatar?: AvatarConfig | null; name: string; size?: number; className?: string;
}) {
  const config = avatar ?? defaultAvatar(name);
  const key = JSON.stringify(config);
  const [src, setSrc] = useState<string | null>(() => memo.get(key) ?? null);

  useEffect(() => {
    let alive = true;
    const cached = memo.get(key);
    if (cached) { setSrc(cached); return; }
    renderAvatar(config).then((uri) => {
      memo.set(key, uri);
      if (alive) setSrc(uri);
    }).catch(() => undefined);
    return () => { alive = false; };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [key]);

  const initials = name.split(" ").filter(Boolean).slice(0, 2).map((p) => p[0]!.toUpperCase()).join("") || "?";
  return src ? (
    // eslint-disable-next-line @next/next/no-img-element
    <img src={src} alt="" width={size} height={size} className={clsx("shrink-0 rounded-full bg-primary-50", className)} style={{ width: size, height: size }} />
  ) : (
    <span
      aria-hidden="true"
      className={clsx("inline-flex shrink-0 items-center justify-center rounded-full bg-primary-100 font-medium text-primary-dark", className)}
      style={{ width: size, height: size, fontSize: size * 0.36 }}
    >
      {initials}
    </span>
  );
}
