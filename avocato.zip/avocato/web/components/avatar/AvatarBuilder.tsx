"use client";

import { useEffect, useMemo, useState } from "react";
import clsx from "clsx";
import { ChevronLeft, ChevronRight, Dices, FlipHorizontal } from "lucide-react";
import { AVATAR_STYLES, BACKGROUNDS, controlsFor, loadStyle, type ColorControl, type VariantControl } from "@/lib/avatar";
import type { AvatarConfig, AvatarStyle } from "@/lib/types";
import UserAvatar from "./UserAvatar";

const randomSeed = () => Math.random().toString(36).slice(2, 10);

/** Montador de avatar: estilo, variações prontas, fundo e cada detalhe. */
export default function AvatarBuilder({ value, onChange, name }: { value: AvatarConfig; onChange: (v: AvatarConfig) => void; name: string }) {
  const [controls, setControls] = useState<(VariantControl | ColorControl)[]>([]);
  const [variations, setVariations] = useState(() => Array.from({ length: 8 }, randomSeed));

  useEffect(() => {
    let alive = true;
    loadStyle(value.style).then((m) => alive && setControls(controlsFor(m)));
    return () => { alive = false; };
  }, [value.style]);

  const bg = (value.options.backgroundColor as string[] | undefined)?.[0] ?? BACKGROUNDS[0]!;
  const set = (patch: Record<string, unknown>) => onChange({ ...value, options: { ...value.options, ...patch } });

  const setStyle = (style: AvatarStyle) => onChange({ style, seed: value.seed, options: { backgroundColor: [bg] } });

  function stepVariant(c: VariantControl, dir: 1 | -1) {
    const current = (value.options[c.key] as string[] | undefined)?.[0];
    const absent = c.optional && value.options[`${c.key}Probability`] === 0;
    // posições: [-1 = nenhum (se opcional), 0..n-1]
    const positions = c.optional ? [-1, ...c.values.map((_, i) => i)] : c.values.map((_, i) => i);
    const curPos = absent ? -1 : current ? c.values.indexOf(current) : 0;
    const idx = positions.indexOf(curPos);
    const next = positions[(idx + dir + positions.length) % positions.length]!;
    if (next === -1) set({ [`${c.key}Probability`]: 0 });
    else set({ [c.key]: [c.values[next]!], ...(c.optional ? { [`${c.key}Probability`]: 100 } : {}) });
  }

  function variantLabel(c: VariantControl) {
    if (c.optional && value.options[`${c.key}Probability`] === 0) return "Nenhum";
    const current = (value.options[c.key] as string[] | undefined)?.[0];
    if (!current) return "Automático";
    return `${c.values.indexOf(current) + 1} de ${c.values.length}`;
  }

  const variantControls = useMemo(() => controls.filter((c): c is VariantControl => c.kind === "variant"), [controls]);
  const colorControls = useMemo(() => controls.filter((c): c is ColorControl => c.kind === "color"), [controls]);

  return (
    <div className="grid gap-6 lg:grid-cols-[220px_1fr]">
      <div className="flex flex-col items-center gap-3">
        <div className="rounded-full p-1.5 ring-4 ring-primary-50">
          <UserAvatar avatar={value} name={name} size={176} />
        </div>
        <div className="flex gap-2">
          <button type="button" className="btn btn-soft btn-sm" onClick={() => onChange({ ...value, seed: randomSeed(), options: { backgroundColor: [bg] } })}>
            <Dices className="h-4 w-4" /> Surpreenda-me
          </button>
          <button type="button" aria-label="Espelhar" aria-pressed={!!value.options.flip} className={clsx("btn btn-sm", value.options.flip ? "btn-primary" : "btn-outline")}
            onClick={() => set({ flip: !value.options.flip })}>
            <FlipHorizontal className="h-4 w-4" />
          </button>
        </div>
      </div>

      <div className="space-y-6">
        <section>
          <h3 className="mb-2 text-sm font-semibold text-slate-700">Estilo</h3>
          <div className="grid grid-cols-3 gap-2 sm:grid-cols-6">
            {AVATAR_STYLES.map((s) => (
              <button key={s.key} type="button" onClick={() => setStyle(s.key)} aria-pressed={value.style === s.key}
                className={clsx("flex flex-col items-center gap-1 rounded-2xl p-2 text-xs transition-colors",
                  value.style === s.key ? "bg-primary-50 font-medium text-primary-dark ring-2 ring-primary" : "text-slate-500 ring-1 ring-slate-200 hover:bg-slate-50")}>
                <UserAvatar avatar={{ style: s.key, seed: value.seed, options: { backgroundColor: [bg] } }} name={name} size={48} />
                {s.label}
              </button>
            ))}
          </div>
        </section>

        <section>
          <div className="mb-2 flex items-center justify-between">
            <h3 className="text-sm font-semibold text-slate-700">Variações</h3>
            <button type="button" className="text-xs font-medium text-primary hover:underline" onClick={() => setVariations(Array.from({ length: 8 }, randomSeed))}>
              Ver outras
            </button>
          </div>
          <div className="grid grid-cols-4 gap-2 sm:grid-cols-8">
            {variations.map((seed) => (
              <button key={seed} type="button" aria-label="Usar esta variação" aria-pressed={value.seed === seed}
                onClick={() => onChange({ ...value, seed, options: { backgroundColor: [bg], ...(value.options.flip ? { flip: true } : {}) } })}
                className={clsx("flex justify-center rounded-2xl p-1.5 transition-colors", value.seed === seed ? "bg-primary-50 ring-2 ring-primary" : "hover:bg-slate-50")}>
                <UserAvatar avatar={{ style: value.style, seed, options: { backgroundColor: [bg] } }} name={name} size={52} />
              </button>
            ))}
          </div>
        </section>

        <section>
          <h3 className="mb-2 text-sm font-semibold text-slate-700">Fundo</h3>
          <div className="flex flex-wrap gap-2">
            {BACKGROUNDS.map((c) => (
              <button key={c} type="button" aria-label={`Fundo #${c}`} aria-pressed={bg === c} onClick={() => set({ backgroundColor: [c] })}
                className={clsx("h-8 w-8 rounded-full ring-offset-2 transition", bg === c ? "ring-2 ring-primary" : "ring-1 ring-black/5 hover:scale-110")}
                style={{ backgroundColor: `#${c}` }} />
            ))}
          </div>
        </section>

        {(variantControls.length > 0 || colorControls.length > 0) && (
          <section>
            <h3 className="mb-2 text-sm font-semibold text-slate-700">Detalhes</h3>
            <div className="grid gap-2 sm:grid-cols-2">
              {variantControls.map((c) => (
                <div key={c.key} className="flex items-center justify-between rounded-xl bg-slate-50 px-3 py-2">
                  <span className="truncate text-sm text-slate-600">{c.label}</span>
                  <div className="flex items-center gap-1">
                    <button type="button" aria-label={`${c.label}: anterior`} onClick={() => stepVariant(c, -1)} className="icon-btn h-7 w-7 text-slate-500 hover:bg-white">
                      <ChevronLeft className="h-4 w-4" />
                    </button>
                    <span className="w-[4.5rem] text-center text-xs text-slate-500" aria-live="polite">{variantLabel(c)}</span>
                    <button type="button" aria-label={`${c.label}: próximo`} onClick={() => stepVariant(c, 1)} className="icon-btn h-7 w-7 text-slate-500 hover:bg-white">
                      <ChevronRight className="h-4 w-4" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
            <div className="mt-3 space-y-3">
              {colorControls.map((c) => {
                const cur = (value.options[c.key] as string[] | undefined)?.[0];
                return (
                  <div key={c.key}>
                    <p className="mb-1.5 text-xs font-medium text-slate-500">{c.label}</p>
                    <div className="flex flex-wrap gap-1.5">
                      {c.palette.map((col) => (
                        <button key={col} type="button" aria-label={`${c.label} #${col}`} aria-pressed={cur === col} onClick={() => set({ [c.key]: [col] })}
                          className={clsx("h-7 w-7 rounded-full ring-offset-2 transition", cur === col ? "ring-2 ring-primary" : "ring-1 ring-black/10 hover:scale-110")}
                          style={{ backgroundColor: `#${col}` }} />
                      ))}
                    </div>
                  </div>
                );
              })}
            </div>
          </section>
        )}
        <p className="text-xs text-slate-400">Ilustração: {AVATAR_STYLES.find((s) => s.key === value.style)?.credit}. Gerado no seu navegador via DiceBear.</p>
      </div>
    </div>
  );
}
