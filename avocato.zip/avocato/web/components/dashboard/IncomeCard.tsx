import Link from "next/link";
import clsx from "clsx";
import type { LucideIcon } from "lucide-react";

type IncomeCardProps = { icon: LucideIcon; value: string; label: string; detail?: string; tone: "green" | "amber"; href?: string };

const tones = {
  green: { icon: "bg-primary-50 text-primary", decor: "bg-primary-50" },
  amber: { icon: "bg-amber-50 text-amber-600", decor: "bg-amber-50" },
};

export default function IncomeCard({ icon: Icon, value, label, detail, tone, href }: IncomeCardProps) {
  const t = tones[tone];
  const body = (
    <>
      <span aria-hidden="true" className={clsx("absolute -right-10 -top-14 -z-10 h-32 w-32 rounded-full", t.decor)} />
      <span aria-hidden="true" className={clsx("absolute -right-20 top-2 -z-10 h-32 w-32 rounded-full opacity-60", t.decor)} />
      <span className={clsx("inline-flex h-11 w-11 shrink-0 items-center justify-center rounded-xl", t.icon)}>
        <Icon className="h-5 w-5" strokeWidth={1.75} />
      </span>
      <div className="leading-tight">
        <p className="text-lg font-medium text-slate-800">{value}</p>
        <p className="mt-0.5 text-sm text-slate-500">{label}</p>
        {detail && <p className="mt-0.5 text-xs font-medium text-rose-600">{detail}</p>}
      </div>
    </>
  );
  const cls = "card relative isolate flex h-full items-center gap-4 overflow-hidden p-5";
  return href ? <Link href={href} className={clsx(cls, "transition-shadow hover:shadow-card-hover")}>{body}</Link> : <article className={cls}>{body}</article>;
}
