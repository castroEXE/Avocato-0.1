"use client";

import { useRef, useState } from "react";
import Link from "next/link";
import clsx from "clsx";
import { ArrowDownLeft, ArrowUpRight, ClipboardList, MoreHorizontal, PlusCircle, Wallet, WalletCards } from "lucide-react";
import Sparkline from "./Sparkline";
import { brl } from "@/lib/format";
import { useClickOutside } from "@/lib/useClickOutside";

function Decor({ tone }: { tone: "green" | "teal" }) {
  const c = tone === "green" ? "bg-emerald-950" : "bg-teal-950";
  return (
    <>
      <span aria-hidden="true" className={clsx("absolute -right-16 -top-24 -z-10 h-52 w-52 rounded-full opacity-30", c)} />
      <span aria-hidden="true" className={clsx("absolute -right-28 -top-10 -z-10 h-52 w-52 rounded-full opacity-25", c)} />
    </>
  );
}

const shell = "relative isolate flex h-full min-h-[188px] flex-col overflow-hidden rounded-2xl p-5 text-white";

/** Recebido no mês (o "Total Earning" do Berry, agora com dado real). */
export function EarningCard({ valueCents, previousCents }: { valueCents: number; previousCents: number }) {
  const [open, setOpen] = useState(false);
  const ref = useRef<HTMLDivElement>(null);
  useClickOutside(ref, () => setOpen(false), open);
  const up = valueCents >= previousCents;
  const pct = previousCents > 0 ? Math.round(((valueCents - previousCents) / previousCents) * 100) : null;

  return (
    <article className={clsx(shell, "bg-gradient-to-br from-emerald-600 to-emerald-800 shadow-float")}>
      <Decor tone="green" />
      <div className="flex items-start justify-between">
        <span className="inline-flex h-11 w-11 items-center justify-center rounded-xl bg-emerald-900/50">
          <Wallet className="h-5 w-5" strokeWidth={1.75} />
        </span>
        <div ref={ref} className="relative">
          <button type="button" onClick={() => setOpen((v) => !v)} aria-haspopup="menu" aria-expanded={open} aria-label="Opções do card"
            className="inline-flex h-8 w-8 items-center justify-center rounded-lg bg-emerald-900/40 transition-colors hover:bg-emerald-900/70">
            <MoreHorizontal className="h-5 w-5" />
          </button>
          {open && (
            <div role="menu" className="absolute right-0 top-10 z-10 w-48 rounded-xl bg-white p-1.5 text-slate-600 shadow-card-hover ring-1 ring-slate-100">
              <Link role="menuitem" href="/financeiro?novo=in" className="flex w-full items-center gap-2.5 rounded-lg px-3 py-2 text-sm hover:bg-primary-50 hover:text-primary-dark">
                <PlusCircle className="h-4 w-4" /> Lançar receita
              </Link>
              <Link role="menuitem" href="/financeiro" className="flex w-full items-center gap-2.5 rounded-lg px-3 py-2 text-sm hover:bg-primary-50 hover:text-primary-dark">
                <WalletCards className="h-4 w-4" /> Abrir financeiro
              </Link>
            </div>
          )}
        </div>
      </div>
      <div className="mt-auto pt-6">
        <div className="flex items-center gap-2">
          <p className="text-[2rem] font-medium leading-none tracking-tight">{brl(valueCents)}</p>
          <span className="inline-flex h-6 w-6 items-center justify-center rounded-full bg-emerald-200 text-emerald-800">
            {up ? <ArrowUpRight className="h-4 w-4" strokeWidth={2.5} aria-label="Em alta" /> : <ArrowDownLeft className="h-4 w-4" strokeWidth={2.5} aria-label="Em queda" />}
          </span>
        </div>
        <p className="mt-2 font-medium text-emerald-100">
          Recebido no mês{pct !== null && <span className="ml-1 text-emerald-200/80">· {pct > 0 ? "+" : ""}{pct}% vs mês passado</span>}
        </p>
      </div>
    </article>
  );
}

/** Ordens de serviço (o "Total Order" do Berry). */
export function OrderCard({ series, doneThisMonth }: { series: { month: string; created: number; done: number }[]; doneThisMonth: number }) {
  const [range, setRange] = useState<"month" | "year">("month");
  const yearTotal = series.reduce((a, s) => a + s.created, 0);
  const thisMonth = series.at(-1)?.created ?? 0;
  const prevMonth = series.at(-2)?.created ?? 0;
  const value = range === "month" ? thisMonth : yearTotal;
  const up = thisMonth >= prevMonth;

  return (
    <article className={clsx(shell, "bg-gradient-to-br from-teal-500 to-teal-700 shadow-float-teal")}>
      <Decor tone="teal" />
      <div className="flex items-start justify-between">
        <span className="inline-flex h-11 w-11 items-center justify-center rounded-xl bg-teal-900/40">
          <ClipboardList className="h-5 w-5" strokeWidth={1.75} />
        </span>
        <div role="group" aria-label="Período" className="flex gap-1 text-sm">
          {([["month", "Mês"], ["year", "Ano"]] as const).map(([r, label]) => (
            <button key={r} type="button" onClick={() => setRange(r)} aria-pressed={range === r}
              className={clsx("rounded-lg px-3 py-1.5 transition-colors", range === r ? "bg-white/20 font-medium text-white" : "text-teal-50 hover:bg-white/10")}>
              {label}
            </button>
          ))}
        </div>
      </div>
      <div className="mt-auto flex items-end justify-between gap-4 pt-6">
        <div>
          <div className="flex items-center gap-2">
            <p className="text-[2rem] font-medium leading-none tracking-tight">{value}</p>
            <span className="inline-flex h-6 w-6 items-center justify-center rounded-full bg-teal-100 text-teal-800">
              {up ? <ArrowUpRight className="h-4 w-4" strokeWidth={2.5} aria-label="Em alta" /> : <ArrowDownLeft className="h-4 w-4" strokeWidth={2.5} aria-label="Em queda" />}
            </span>
          </div>
          <p className="mt-2 font-medium text-teal-50">
            OS abertas {range === "month" ? "no mês" : "em 12 meses"} · {doneThisMonth} {doneThisMonth === 1 ? "concluída" : "concluídas"} no mês
          </p>
        </div>
        <Sparkline data={series.map((s) => s.created)} className="h-14 w-28 shrink-0 sm:w-36" />
      </div>
    </article>
  );
}
