type SparklineProps = {
  data: number[];
  width?: number;
  height?: number;
  className?: string;
};

/** Converte pontos em uma curva suave (Catmull-Rom → Bézier cúbica). */
function smoothPath(points: [number, number][]) {
  if (points.length < 2) return "";
  let d = `M${points[0][0]},${points[0][1]}`;
  for (let i = 0; i < points.length - 1; i++) {
    const p0 = points[i - 1] ?? points[i];
    const p1 = points[i];
    const p2 = points[i + 1];
    const p3 = points[i + 2] ?? p2;
    const c1x = p1[0] + (p2[0] - p0[0]) / 6;
    const c1y = p1[1] + (p2[1] - p0[1]) / 6;
    const c2x = p2[0] - (p3[0] - p1[0]) / 6;
    const c2y = p2[1] - (p3[1] - p1[1]) / 6;
    d += ` C${c1x},${c1y} ${c2x},${c2y} ${p2[0]},${p2[1]}`;
  }
  return d;
}

/** Mini gráfico de linha em SVG puro, branco translúcido, para fundos coloridos. */
export default function Sparkline({ data: raw, width = 140, height = 56, className }: SparklineProps) {
  const data = raw.length >= 2 ? raw : [0, raw[0] ?? 0];
  const pad = 4;
  const max = Math.max(...data);
  const min = Math.min(...data);
  const range = max - min || 1;
  const step = (width - pad * 2) / (data.length - 1);

  const points = data.map(
    (v, i) => [pad + i * step, pad + (1 - (v - min) / range) * (height - pad * 2)] as [number, number],
  );
  const line = smoothPath(points);
  const area = `${line} L${points[points.length - 1][0]},${height} L${points[0][0]},${height} Z`;

  return (
    <svg
      viewBox={`0 0 ${width} ${height}`}
      className={className}
      preserveAspectRatio="none"
      aria-hidden="true"
    >
      <path d={area} fill="white" fillOpacity={0.12} />
      <path
        d={line}
        fill="none"
        stroke="white"
        strokeOpacity={0.9}
        strokeWidth={2.5}
        strokeLinecap="round"
        vectorEffect="non-scaling-stroke"
      />
    </svg>
  );
}
