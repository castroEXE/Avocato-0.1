"use client";

import { useId, useState } from "react";
import { ChevronDown } from "lucide-react";
import { Bar, BarChart, CartesianGrid, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import { brl, monthShort } from "@/lib/format";
import { useReducedMotion } from "@/lib/useReducedMotion";

type Point = { month: string; incomeCents: number; expenseCents: number };
type TooltipEntry = { dataKey?: string | number; name?: string | number; value?: number | string; color?: string };

function CashTooltip({ active, label, payload }: { active?: boolean; label?: string | number; payload?: readonly TooltipEntry[] }) {
  if (!active || !payload?.length) return null;
  const inc = Number(payload.find((p) => p.dataKey === "income")?.value ?? 0);
  const exp = Number(payload.find((p) => p.dataKey === "expense")?.value ?? 0);
  return (
    <div className="min-w-44 rounded-xl bg-white p-3 text-sm shadow-card-hover ring-1 ring-slate-100">
      <p className="mb-2 font-medium capitalize text-slate-800">{label}</p>
      {payload.map((p) => (
        <p key={String(p.dataKey)} className="flex items-center justify-between gap-4 text-slate-600">
          <span className="flex items-center gap-2"><span className="h-2.5 w-2.5 rounded-full" style={{ background: p.color }} />{p.name}</span>
          <span className="font-medium text-slate-800">{brl(Number(p.value) * 100)}</span>
        </p>
      ))}
      <p className="mt-2 flex justify-between border-t border-slate-100 pt-2 text-slate-500">
        Saldo <span className={inc - exp >= 0 ? "font-medium text-primary" : "font-medium text-rose-600"}>{brl((inc - exp) * 100)}</span>
      </p>
    </div>
  );
}

/** Fluxo de caixa realizado (entradas x saídas), no lugar do "Total Growth". */
export default function CashflowChart({ data }: { data: Point[] }) {
  const [months, setMonths] = useState<6 | 12>(6);
  const reduceMotion = useReducedMotion();
  const selectId = useId();
  const slice = data.slice(-months).map((d) => ({ label: monthShort(d.month), income: d.incomeCents / 100, expense: d.expenseCents / 100 }));
  const balance = data.slice(-months).reduce((a, d) => a + d.incomeCents - d.expenseCents, 0);
  const empty = slice.every((d) => d.income === 0 && d.expense === 0);

  return (
    <section className="card flex h-full flex-col p-5 sm:p-6" aria-labelledby="cash-title">
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div>
          <h2 id="cash-title" className="text-sm text-slate-500">Saldo do período (entradas − saídas)</h2>
          <p className={`mt-1 text-2xl font-medium ${balance >= 0 ? "text-slate-800" : "text-rose-600"}`}>{brl(balance)}</p>
        </div>
        <div className="relative">
          <label htmlFor={selectId} className="sr-only">Período</label>
          <select id={selectId} value={months} onChange={(e) => setMonths(Number(e.target.value) as 6 | 12)}
            className="h-10 appearance-none rounded-xl border border-slate-200 bg-white pl-3.5 pr-9 text-sm text-slate-700 hover:border-primary-200 focus:border-primary focus:outline-none focus:ring-4 focus:ring-primary-50">
            <option value={6}>Últimos 6 meses</option>
            <option value={12}>Últimos 12 meses</option>
          </select>
          <ChevronDown className="pointer-events-none absolute right-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-500" />
        </div>
      </div>

      <div className="relative mt-6 h-[300px] w-full sm:h-[340px]" role="img" aria-label={`Gráfico de barras com entradas e saídas dos últimos ${months} meses`}>
        {empty && (
          <p className="absolute inset-0 z-10 flex items-center justify-center text-center text-sm text-slate-400">
            Quando você registrar recebimentos e pagamentos,<br />o fluxo de caixa aparece aqui.
          </p>
        )}
        <ResponsiveContainer width="100%" height="100%">
          <BarChart data={slice} barCategoryGap="28%" barGap={4} margin={{ top: 8, right: 4, bottom: 0, left: 4 }}>
            <CartesianGrid vertical={false} stroke="#e7ece6" />
            <XAxis dataKey="label" axisLine={false} tickLine={false} tick={{ fill: "#94a3b8", fontSize: 12 }} dy={8} />
            <YAxis axisLine={false} tickLine={false} tick={{ fill: "#94a3b8", fontSize: 12 }} width={56}
              tickFormatter={(v: number) => (v >= 1000 ? `${Math.round(v / 1000)}k` : String(v))} />
            <Tooltip content={<CashTooltip />} cursor={{ fill: "#ecfdf5", radius: 8 }} />
            <Bar dataKey="income" name="Entradas" fill="#047857" maxBarSize={28} radius={[6, 6, 0, 0]} isAnimationActive={!reduceMotion} />
            <Bar dataKey="expense" name="Saídas" fill="#a7d7c5" maxBarSize={28} radius={[6, 6, 0, 0]} isAnimationActive={!reduceMotion} />
          </BarChart>
        </ResponsiveContainer>
      </div>
      <ul className="mt-4 flex flex-wrap justify-center gap-x-6 gap-y-2 text-sm text-slate-500">
        <li className="flex items-center gap-2"><span className="h-3 w-3 rounded bg-[#047857]" aria-hidden="true" />Entradas</li>
        <li className="flex items-center gap-2"><span className="h-3 w-3 rounded bg-[#a7d7c5]" aria-hidden="true" />Saídas</li>
      </ul>
    </section>
  );
}
