"use client";

import { useId } from "react";
import Link from "next/link";
import clsx from "clsx";
import { ChevronDown, ChevronRight, ChevronUp, Minus } from "lucide-react";
import { Area, AreaChart, ResponsiveContainer, Tooltip } from "recharts";
import { brl, monthShort } from "@/lib/format";
import type { Dashboard } from "@/lib/types";
import { useReducedMotion } from "@/lib/useReducedMotion";

function MiniTooltip({ active, payload }: { active?: boolean; payload?: readonly { value?: number | string; payload?: { label?: string } }[] }) {
  if (!active || !payload?.length) return null;
  return (
    <div className="rounded-lg bg-white px-3 py-2 text-xs shadow-card-hover ring-1 ring-slate-100">
      <p className="font-medium text-primary-dark">{payload[0]!.value} concluídas</p>
      <p className="capitalize text-slate-500">{payload[0]!.payload?.label}</p>
    </div>
  );
}

/** Serviços mais vendidos (no lugar do "Popular Stocks"). */
export default function TopServicesWidget({ services, series }: { services: Dashboard["topServices"]; series: Dashboard["orders"]["series"] }) {
  const gradientId = useId();
  const reduceMotion = useReducedMotion();
  const trend = series.slice(-8).map((s) => ({ label: monthShort(s.month), done: s.done }));
  const doneTotal = series.slice(-3).reduce((a, s) => a + s.done, 0);

  return (
    <section className="card flex h-full flex-col p-5 sm:p-6" aria-labelledby="top-title">
      <h2 id="top-title" className="text-lg font-medium text-slate-800">Serviços mais vendidos</h2>
      <div className="mt-4 overflow-hidden rounded-xl bg-primary-50">
        <div className="flex items-start justify-between px-4 pt-4">
          <div>
            <p className="font-medium text-primary-dark">OS concluídas</p>
            <p className="text-sm text-slate-500">últimos 3 meses</p>
          </div>
          <p className="text-lg font-medium text-slate-800">{doneTotal}</p>
        </div>
        <div className="h-[100px]" role="img" aria-label="Tendência de OS concluídas por mês">
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={trend} margin={{ top: 12, right: 0, bottom: 0, left: 0 }}>
              <defs>
                <linearGradient id={gradientId} x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#059669" stopOpacity={0.4} />
                  <stop offset="100%" stopColor="#059669" stopOpacity={0.04} />
                </linearGradient>
              </defs>
              <Tooltip content={<MiniTooltip />} cursor={{ stroke: "#047857", strokeDasharray: "3 3" }} />
              <Area type="monotone" dataKey="done" stroke="#047857" strokeWidth={2.5} fill={`url(#${gradientId})`}
                activeDot={{ r: 4, fill: "#047857", stroke: "#fff", strokeWidth: 2 }} isAnimationActive={!reduceMotion} />
            </AreaChart>
          </ResponsiveContainer>
        </div>
      </div>

      {services.length === 0 ? (
        <p className="py-8 text-center text-sm text-slate-400">Conclua ordens de serviço para ver o ranking aqui.</p>
      ) : (
        <ul className="mt-2 divide-y divide-slate-100">
          {services.map((s) => {
            const change = s.previousRevenueCents > 0 ? Math.round(((s.revenueCents - s.previousRevenueCents) / s.previousRevenueCents) * 100) : null;
            const up = change === null || change >= 0;
            const Icon = change === null ? Minus : up ? ChevronUp : ChevronDown;
            return (
              <li key={s.id} className="flex items-center justify-between gap-3 py-3">
                <div className="min-w-0">
                  <p className="truncate text-sm font-medium text-slate-800">{s.name}</p>
                  <p className={clsx("text-xs", change === null ? "text-slate-400" : up ? "text-emerald-600" : "text-rose-500")}>
                    {s.quantity}× · {change === null ? "novo no período" : `${Math.abs(change)}% ${up ? "a mais" : "a menos"}`}
                  </p>
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-sm font-medium text-slate-800">{brl(s.revenueCents)}</span>
                  <span className={clsx("inline-flex h-5 w-5 items-center justify-center rounded-md",
                    change === null ? "bg-slate-100 text-slate-400" : up ? "bg-emerald-100 text-emerald-600" : "bg-rose-100 text-rose-500")}>
                    <Icon className="h-3.5 w-3.5" strokeWidth={3} />
                  </span>
                </div>
              </li>
            );
          })}
        </ul>
      )}
      <Link href="/servicos" className="mx-auto mt-auto inline-flex items-center gap-1 rounded-lg px-3 pt-3 text-sm font-medium text-primary hover:text-primary-dark">
        Ver catálogo <ChevronRight className="h-4 w-4" aria-hidden="true" />
      </Link>
    </section>
  );
}
