"use client";

import { useState } from "react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import clsx from "clsx";
import { Check, Link2 } from "lucide-react";
import Logo from "./Logo";
import { navigation, type NavItem } from "@/lib/navigation";
import { useSession } from "@/lib/session";
import { useApi } from "@/lib/hooks";

type SidebarProps = { collapsed: boolean; mobileOpen: boolean; onClose: () => void };

const itemBase = "group flex w-full items-center gap-3 rounded-xl px-4 py-2.5 text-sm transition-colors";
const itemIdle = "text-slate-600 hover:bg-primary-50 hover:text-primary-dark";
const itemActive = "bg-primary-light font-medium text-primary-dark";

function NavEntry({ item, pathname, requests }: { item: NavItem; pathname: string; requests: number }) {
  const { term } = useSession();
  const Icon = item.icon;
  const active = item.href === "/" ? pathname === "/" : pathname.startsWith(item.href);
  return (
    <Link href={item.href} aria-current={active ? "page" : undefined} className={clsx(itemBase, active ? itemActive : itemIdle)}>
      <Icon className="h-[18px] w-[18px] shrink-0" strokeWidth={1.75} />
      <span className="flex-1">{item.termKey ? term(item.termKey, item.label) : item.label}</span>
      {item.badge === "requests" && requests > 0 && (
        <span className="rounded-full bg-amber-400 px-1.5 text-[11px] font-semibold text-amber-950" aria-label={`${requests} solicitações novas`}>
          {requests}
        </span>
      )}
    </Link>
  );
}

/** Card do rodapé: link público para clientes pedirem serviços. */
function PublicLinkCard() {
  const { context } = useSession();
  const [copied, setCopied] = useState(false);
  if (!context || context.settings.workflowConfiguration?.publicRequestsEnabled === false) return null;
  const url = typeof window !== "undefined" ? `${window.location.origin}/solicitar/${context.organization.slug}` : "";
  return (
    <div className="m-4 mt-0 rounded-2xl bg-secondary-50 p-4">
      <div className="flex items-center gap-3">
        <span className="inline-flex h-9 w-9 items-center justify-center rounded-xl bg-white text-secondary">
          <Link2 className="h-[18px] w-[18px]" strokeWidth={1.75} />
        </span>
        <div className="leading-tight">
          <p className="text-sm font-medium text-secondary-dark">Link de pedidos</p>
          <p className="text-xs text-slate-500">Seus clientes pedem serviços</p>
        </div>
      </div>
      <button
        type="button"
        onClick={async () => {
          await navigator.clipboard.writeText(url).catch(() => undefined);
          setCopied(true);
          setTimeout(() => setCopied(false), 2000);
        }}
        className="mt-3 flex w-full items-center justify-center gap-1.5 rounded-lg bg-white py-1.5 text-xs font-medium text-secondary-dark transition-colors hover:bg-secondary hover:text-white"
      >
        {copied ? <><Check className="h-3.5 w-3.5" /> Copiado!</> : "Copiar link"}
      </button>
    </div>
  );
}

export default function Sidebar({ collapsed, mobileOpen, onClose }: SidebarProps) {
  const pathname = usePathname();
  const { can, hasModule } = useSession();
  const { data } = useApi<{ counts: Record<string, number> }>(
    can("service_orders.read") && hasModule("service_orders") ? "/service-orders?limit=1" : null,
    { refreshInterval: 60_000 },
  );
  const requests = data?.counts?.requested ?? 0;

  const sections = navigation
    .map((s) => ({ ...s, items: s.items.filter((i) => (!i.module || hasModule(i.module)) && (!i.permission || can(i.permission))) }))
    .filter((s) => s.items.length > 0);

  return (
    <>
      <div aria-hidden="true" onClick={onClose}
        className={clsx("fixed inset-0 z-40 bg-slate-900/40 transition-opacity lg:hidden", mobileOpen ? "opacity-100" : "pointer-events-none opacity-0")} />
      <aside aria-label="Menu principal"
        className={clsx(
          "fixed inset-y-0 left-0 z-50 flex w-sidebar flex-col bg-white transition-transform duration-200",
          mobileOpen ? "translate-x-0 shadow-xl" : "-translate-x-full",
          collapsed ? "lg:-translate-x-full" : "lg:translate-x-0",
        )}>
        <div className="flex h-header shrink-0 items-center px-6"><Logo /></div>
        <nav className="flex-1 overflow-y-auto px-4 pb-4">
          {sections.map((section, i) => (
            <div key={i} className={clsx("py-3", i > 0 && "border-t border-slate-100")}>
              {section.title && <p className="mb-2 px-4 text-xs font-semibold uppercase tracking-wider text-slate-400">{section.title}</p>}
              <ul className="space-y-1">
                {section.items.map((item) => (
                  <li key={item.href}><NavEntry item={item} pathname={pathname} requests={requests} /></li>
                ))}
              </ul>
            </div>
          ))}
        </nav>
        <PublicLinkCard />
      </aside>
    </>
  );
}
