"use client";

import { useCallback, useEffect, useState } from "react";
import { usePathname, useRouter } from "next/navigation";
import clsx from "clsx";
import Sidebar from "./Sidebar";
import Header from "./Header";
import AvocadoMark from "@/components/brand/AvocadoMark";
import { useSession } from "@/lib/session";

const DESKTOP_QUERY = "(min-width: 1024px)";

export function Splash({ message = "Carregando…" }: { message?: string }) {
  return (
    <div className="flex min-h-screen flex-col items-center justify-center gap-3 bg-surface-page" role="status">
      <AvocadoMark size={56} className="animate-bounce" />
      <p className="text-sm text-slate-500">{message}</p>
    </div>
  );
}

/** Layout autenticado: protege as rotas e monta Sidebar + Header. */
export default function AppShell({ children }: { children: React.ReactNode }) {
  const [collapsed, setCollapsed] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);
  const [isDesktop, setIsDesktop] = useState(false);
  const pathname = usePathname();
  const router = useRouter();
  const { status, error, refresh } = useSession();

  useEffect(() => setMobileOpen(false), [pathname]);
  useEffect(() => {
    const mq = window.matchMedia(DESKTOP_QUERY);
    const update = () => setIsDesktop(mq.matches);
    update();
    mq.addEventListener("change", update);
    return () => mq.removeEventListener("change", update);
  }, []);
  useEffect(() => {
    document.body.style.overflow = mobileOpen ? "hidden" : "";
    return () => { document.body.style.overflow = ""; };
  }, [mobileOpen]);
  useEffect(() => {
    if (status === "signed_out") router.replace(`/entrar?voltar=${encodeURIComponent(pathname)}`);
    if (status === "no_org") router.replace("/criar-empresa");
  }, [status, router, pathname]);

  const toggleMenu = useCallback(() => {
    if (window.matchMedia(DESKTOP_QUERY).matches) setCollapsed((v) => !v);
    else setMobileOpen((v) => !v);
  }, []);

  if (status === "error") {
    return (
      <div className="flex min-h-screen flex-col items-center justify-center gap-4 p-6 text-center">
        <AvocadoMark size={56} />
        <p className="max-w-sm text-sm text-slate-600">{error}</p>
        <button type="button" className="btn btn-primary" onClick={refresh}>Tentar de novo</button>
      </div>
    );
  }
  if (status !== "ready") return <Splash />;

  return (
    <div className="min-h-screen bg-white">
      <a href="#conteudo" className="sr-only focus:not-sr-only focus:fixed focus:left-4 focus:top-4 focus:z-[90] focus:rounded-lg focus:bg-white focus:px-4 focus:py-2">
        Pular para o conteúdo
      </a>
      <Sidebar collapsed={collapsed} mobileOpen={mobileOpen} onClose={() => setMobileOpen(false)} />
      <div className={clsx("transition-[padding] duration-200", collapsed ? "lg:pl-0" : "lg:pl-sidebar")}>
        <Header onToggleMenu={toggleMenu} menuOpen={isDesktop ? !collapsed : mobileOpen} />
        <main id="conteudo" className="min-h-[calc(100vh-theme(spacing.header))] rounded-t-3xl bg-surface-page p-4 sm:p-6 lg:mr-5">
          {children}
        </main>
      </div>
    </div>
  );
}
