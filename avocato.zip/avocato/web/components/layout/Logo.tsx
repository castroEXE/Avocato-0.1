import Link from "next/link";
import AvocadoMark from "@/components/brand/AvocadoMark";

export function Wordmark({ className = "text-xl" }: { className?: string }) {
  return (
    <span className={`font-bold tracking-tight text-slate-900 ${className}`}>
      avo<span className="text-primary">cato</span>
    </span>
  );
}

export default function Logo({ href = "/" }: { href?: string }) {
  return (
    <Link href={href} className="inline-flex items-center gap-2 rounded-lg" aria-label="Avocato, ir para o painel">
      <AvocadoMark size={32} />
      <Wordmark />
    </Link>
  );
}
