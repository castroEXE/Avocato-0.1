import { CalendarCheck2, ClipboardCheck, Sparkles, Wallet } from "lucide-react";
import AvocadoMark from "@/components/brand/AvocadoMark";
import { Wordmark } from "./Logo";

const points = [
  { icon: ClipboardCheck, text: "Pedidos de serviço e ordens de serviço num só lugar" },
  { icon: CalendarCheck2, text: "Agenda da equipe sem conflito de horário" },
  { icon: Wallet, text: "Financeiro que se lança sozinho quando o serviço termina" },
  { icon: Sparkles, text: "Assistente com IA que trabalha junto com você" },
];

export default function AuthLayout({ children }: { children: React.ReactNode }) {
  return (
    <div className="grid min-h-screen lg:grid-cols-[1.05fr_1fr]">
      <aside className="relative isolate hidden overflow-hidden bg-gradient-to-br from-primary to-primary-darker p-12 text-white lg:flex lg:flex-col">
        <span aria-hidden="true" className="absolute -right-24 -top-24 -z-10 h-80 w-80 rounded-full bg-emerald-950 opacity-30" />
        <span aria-hidden="true" className="absolute -bottom-32 -left-20 -z-10 h-96 w-96 rounded-full bg-teal-400 opacity-15" />
        <div className="flex items-center gap-2">
          <AvocadoMark size={36} />
          <span className="text-2xl font-bold tracking-tight">avo<span className="text-avocado-flesh">cato</span></span>
        </div>
        <div className="my-auto max-w-md">
          <h2 className="text-4xl font-semibold leading-tight tracking-tight">Sua empresa de serviços, organizadinha.</h2>
          <p className="mt-4 text-emerald-100">Do pedido do cliente até o dinheiro no caixa, sem planilha e sem papel.</p>
          <ul className="mt-10 space-y-4">
            {points.map(({ icon: Icon, text }) => (
              <li key={text} className="flex items-center gap-3 text-emerald-50">
                <span className="inline-flex h-9 w-9 items-center justify-center rounded-xl bg-white/10"><Icon className="h-[18px] w-[18px]" /></span>
                {text}
              </li>
            ))}
          </ul>
        </div>
        <p className="text-xs text-emerald-200/80">© {new Date().getFullYear()} Avocato</p>
      </aside>
      <main className="flex items-center justify-center bg-surface-page p-6">
        <div className="w-full max-w-md">
          <div className="mb-8 flex items-center gap-2 lg:hidden">
            <AvocadoMark size={34} />
            <Wordmark className="text-2xl" />
          </div>
          {children}
        </div>
      </main>
    </div>
  );
}
