"use client";

import { useId, useRef, useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import clsx from "clsx";
import { useSWRConfig } from "swr";
import { Bell, Building2, Check, LogOut, Menu, Search, Settings, UserRound } from "lucide-react";
import Logo from "./Logo";
import UserAvatar from "@/components/avatar/UserAvatar";
import { api } from "@/lib/api";
import { greeting, relative } from "@/lib/format";
import { invalidate, useApi } from "@/lib/hooks";
import { useSession } from "@/lib/session";
import { useClickOutside } from "@/lib/useClickOutside";

type HeaderProps = { onToggleMenu: () => void; menuOpen: boolean };
type Notification = { id: string; title: string; body: string | null; link: string | null; read: boolean; createdAt: string; severity: string };

function SearchField({ className }: { className?: string }) {
  const id = useId();
  const router = useRouter();
  const { hasModule } = useSession();
  const [q, setQ] = useState("");
  return (
    <form role="search" className={clsx("relative", className)}
      onSubmit={(e) => {
        e.preventDefault();
        if (!q.trim()) return;
        const target = /^#?\d+$/.test(q.trim()) && hasModule("service_orders") ? "/ordens" : "/clientes";
        router.push(`${target}?q=${encodeURIComponent(q.trim().replace(/^#/, ""))}`);
      }}>
      <label htmlFor={id} className="sr-only">Buscar clientes ou número de OS</label>
      <Search className="pointer-events-none absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" aria-hidden="true" />
      <input id={id} type="search" value={q} onChange={(e) => setQ(e.target.value)} placeholder="Buscar cliente ou nº da OS"
        className="h-11 w-full rounded-xl border border-transparent bg-slate-100 pl-10 pr-4 text-sm text-slate-700 placeholder:text-slate-400 focus:border-primary-200 focus:bg-white focus:outline-none focus:ring-4 focus:ring-primary-50" />
    </form>
  );
}

function Notifications() {
  const [open, setOpen] = useState(false);
  const ref = useRef<HTMLDivElement>(null);
  const { can } = useSession();
  const { mutate } = useSWRConfig();
  useClickOutside(ref, () => setOpen(false), open);
  const { data } = useApi<{ data: Notification[]; unread: number }>(can("notifications.read") ? "/notifications" : null, { refreshInterval: 45_000 });
  const unread = data?.unread ?? 0;

  return (
    <div ref={ref} className="relative">
      <button type="button" onClick={() => setOpen((v) => !v)} aria-haspopup="true" aria-expanded={open}
        aria-label={unread ? `Notificações, ${unread} não lidas` : "Notificações"}
        className="icon-btn relative bg-primary-50 text-primary hover:bg-primary hover:text-white">
        <Bell className="h-[18px] w-[18px]" />
        {unread > 0 && <span className="absolute right-2 top-2 h-2 w-2 rounded-full bg-amber-400 ring-2 ring-primary-50" />}
      </button>
      {open && (
        <div className="absolute right-0 top-[calc(100%+0.5rem)] w-[min(92vw,360px)] animate-pop-in rounded-2xl bg-white shadow-card-hover ring-1 ring-slate-100">
          <div className="flex items-center justify-between px-4 py-3">
            <p className="text-sm font-semibold text-slate-800">Notificações</p>
            {unread > 0 && (
              <button type="button" className="text-xs font-medium text-primary hover:underline"
                onClick={async () => { await api("/notifications/read-all", { method: "POST" }); invalidate(mutate, "/notifications"); }}>
                Marcar todas como lidas
              </button>
            )}
          </div>
          <ul className="max-h-96 overflow-y-auto border-t border-slate-100">
            {!data?.data.length && <li className="px-4 py-8 text-center text-sm text-slate-500">Nada por aqui ainda 🥑</li>}
            {data?.data.map((n) => (
              <li key={n.id}>
                <Link href={n.link ?? "#"} onClick={() => setOpen(false)}
                  className={clsx("flex gap-3 px-4 py-3 text-sm hover:bg-slate-50", !n.read && "bg-primary-50/50")}>
                  <span className={clsx("mt-1.5 h-2 w-2 shrink-0 rounded-full", n.read ? "bg-slate-200" : "bg-primary")} />
                  <span className="flex-1">
                    <span className="block font-medium text-slate-800">{n.title}</span>
                    {n.body && <span className="block text-slate-500">{n.body}</span>}
                    <span className="mt-0.5 block text-xs text-slate-400">{relative(n.createdAt)}</span>
                  </span>
                </Link>
              </li>
            ))}
          </ul>
        </div>
      )}
    </div>
  );
}

export default function Header({ onToggleMenu, menuOpen }: HeaderProps) {
  const [profileOpen, setProfileOpen] = useState(false);
  const [mobileSearch, setMobileSearch] = useState(false);
  const profileRef = useRef<HTMLDivElement>(null);
  useClickOutside(profileRef, () => setProfileOpen(false), profileOpen);
  const { me, context, signOut, selectOrg } = useSession();
  const router = useRouter();
  const name = me?.user.fullName || me?.user.email || "";
  const otherOrgs = me?.organizations.filter((o) => o.id !== context?.organization.id && o.status === "active") ?? [];

  return (
    <header className="sticky top-0 z-30 bg-white/90 backdrop-blur">
      <div className="flex h-header items-center gap-3 px-4 sm:px-6 lg:pl-2 lg:pr-5">
        <div className="lg:hidden"><Logo /></div>
        <button type="button" onClick={onToggleMenu} aria-label={menuOpen ? "Esconder menu" : "Mostrar menu"}
          className="icon-btn ml-auto bg-primary-50 text-primary hover:bg-primary hover:text-white lg:ml-0">
          <Menu className="h-[18px] w-[18px]" />
        </button>
        <SearchField className="hidden w-full max-w-md md:block" />

        <div className="flex items-center gap-2 md:ml-auto">
          <button type="button" onClick={() => setMobileSearch((v) => !v)} aria-label="Buscar" aria-expanded={mobileSearch}
            className="icon-btn bg-primary-50 text-primary hover:bg-primary hover:text-white md:hidden">
            <Search className="h-[18px] w-[18px]" />
          </button>
          <Notifications />

          <div ref={profileRef} className="relative">
            <button type="button" onClick={() => setProfileOpen((v) => !v)} aria-haspopup="menu" aria-expanded={profileOpen} aria-label="Conta e configurações"
              className={clsx("flex h-11 items-center gap-2 rounded-full py-1 pl-1 pr-3 transition-colors",
                profileOpen ? "bg-secondary text-white" : "bg-secondary-50 text-secondary hover:bg-secondary hover:text-white")}>
              <UserAvatar avatar={me?.user.avatar} name={name} size={36} />
              <Settings className="h-[18px] w-[18px]" />
            </button>

            {profileOpen && (
              <div role="menu" className="absolute right-0 top-[calc(100%+0.5rem)] w-64 animate-pop-in rounded-2xl bg-white p-2 shadow-card-hover ring-1 ring-slate-100">
                <div className="flex items-center gap-3 px-3 py-2">
                  <UserAvatar avatar={me?.user.avatar} name={name} size={40} />
                  <div className="min-w-0">
                    <p className="truncate text-sm font-medium text-slate-800">{greeting(me?.user.fullName ?? "")}</p>
                    <p className="truncate text-xs text-slate-500">{context?.role.name} · {context?.organization.name}</p>
                  </div>
                </div>
                <div className="my-1 border-t border-slate-100" />
                <button role="menuitem" type="button" onClick={() => { setProfileOpen(false); router.push("/perfil"); }}
                  className="flex w-full items-center gap-3 rounded-xl px-3 py-2 text-sm text-slate-600 hover:bg-primary-50 hover:text-primary-dark">
                  <UserRound className="h-4 w-4" /> Meu perfil e avatar
                </button>
                <button role="menuitem" type="button" onClick={() => { setProfileOpen(false); router.push("/configuracoes"); }}
                  className="flex w-full items-center gap-3 rounded-xl px-3 py-2 text-sm text-slate-600 hover:bg-primary-50 hover:text-primary-dark">
                  <Settings className="h-4 w-4" /> Configurações da empresa
                </button>
                {otherOrgs.map((o) => (
                  <button key={o.id} role="menuitem" type="button" onClick={() => { setProfileOpen(false); selectOrg(o.id); router.push("/"); }}
                    className="flex w-full items-center gap-3 rounded-xl px-3 py-2 text-sm text-slate-600 hover:bg-primary-50 hover:text-primary-dark">
                    <Building2 className="h-4 w-4" /> Trocar para {o.name}
                  </button>
                ))}
                <button role="menuitem" type="button" onClick={() => { setProfileOpen(false); router.push("/criar-empresa"); }}
                  className="flex w-full items-center gap-3 rounded-xl px-3 py-2 text-sm text-slate-600 hover:bg-primary-50 hover:text-primary-dark">
                  <Check className="h-4 w-4 opacity-0" /> Criar outra empresa
                </button>
                <button role="menuitem" type="button" onClick={async () => { await signOut(); router.replace("/entrar"); }}
                  className="flex w-full items-center gap-3 rounded-xl px-3 py-2 text-sm text-slate-600 hover:bg-rose-50 hover:text-rose-600">
                  <LogOut className="h-4 w-4" /> Sair
                </button>
              </div>
            )}
          </div>
        </div>
      </div>
      {mobileSearch && <div className="px-4 pb-3 md:hidden"><SearchField /></div>}
    </header>
  );
}
