"use client";

import { forwardRef, useId, useState } from "react";
import clsx from "clsx";
import { centsToInput, parseMoney } from "@/lib/format";

type BaseProps = { label: string; hint?: string; error?: string; className?: string; required?: boolean };

function Wrapper({ id, label, hint, error, className, required, children }: BaseProps & { id: string; children: React.ReactNode }) {
  return (
    <div className={className}>
      <label htmlFor={id} className="field-label">
        {label}
        {required && <span className="text-rose-500" aria-hidden="true"> *</span>}
      </label>
      {children}
      {error ? <p id={`${id}-err`} className="field-error">{error}</p> : hint ? <p className="field-hint">{hint}</p> : null}
    </div>
  );
}

type InputProps = BaseProps & Omit<React.InputHTMLAttributes<HTMLInputElement>, "className">;
export const TextField = forwardRef<HTMLInputElement, InputProps>(function TextField(
  { label, hint, error, className, required, ...props }, ref) {
  const id = useId();
  return (
    <Wrapper id={id} label={label} hint={hint} error={error} className={className} required={required}>
      <input ref={ref} id={id} required={required} aria-invalid={!!error} aria-describedby={error ? `${id}-err` : undefined}
        className={clsx("input", error && "border-rose-300 focus:border-rose-400 focus:ring-rose-50")} {...props} />
    </Wrapper>
  );
});

type AreaProps = BaseProps & Omit<React.TextareaHTMLAttributes<HTMLTextAreaElement>, "className">;
export function TextArea({ label, hint, error, className, required, ...props }: AreaProps) {
  const id = useId();
  return (
    <Wrapper id={id} label={label} hint={hint} error={error} className={className} required={required}>
      <textarea id={id} required={required} aria-invalid={!!error} className={clsx("input", error && "border-rose-300")} {...props} />
    </Wrapper>
  );
}

type SelectProps = BaseProps & Omit<React.SelectHTMLAttributes<HTMLSelectElement>, "className"> & {
  options: { value: string; label: string }[];
  placeholder?: string;
};
export function SelectField({ label, hint, error, className, required, options, placeholder, ...props }: SelectProps) {
  const id = useId();
  return (
    <Wrapper id={id} label={label} hint={hint} error={error} className={className} required={required}>
      <select id={id} required={required} aria-invalid={!!error} className={clsx("input pr-8", error && "border-rose-300")} {...props}>
        {placeholder !== undefined && <option value="">{placeholder}</option>}
        {options.map((o) => <option key={o.value} value={o.value}>{o.label}</option>)}
      </select>
    </Wrapper>
  );
}

/** Campo de dinheiro em reais que entrega centavos. */
export function MoneyField({ label, hint, error, className, required, value, onChange, placeholder = "0,00" }:
  BaseProps & { value: number | null; onChange: (cents: number | null) => void; placeholder?: string }) {
  const id = useId();
  const [text, setText] = useState(() => centsToInput(value));
  const [focused, setFocused] = useState(false);
  const shown = focused ? text : centsToInput(value);
  return (
    <Wrapper id={id} label={label} hint={hint} error={error} className={className} required={required}>
      <div className="relative">
        <span className="pointer-events-none absolute left-3.5 top-1/2 -translate-y-1/2 text-sm text-slate-400">R$</span>
        <input
          id={id} inputMode="decimal" required={required} placeholder={placeholder} value={shown} aria-invalid={!!error}
          onFocus={() => { setFocused(true); setText(centsToInput(value)); }}
          onBlur={() => setFocused(false)}
          onChange={(e) => { setText(e.target.value); onChange(parseMoney(e.target.value)); }}
          className={clsx("input pl-10", error && "border-rose-300")}
        />
      </div>
    </Wrapper>
  );
}

export function Toggle({ checked, onChange, label, description }: { checked: boolean; onChange: (v: boolean) => void; label: string; description?: string }) {
  const id = useId();
  return (
    <div className="flex items-start justify-between gap-4">
      <div>
        <label htmlFor={id} className="text-sm font-medium text-slate-700">{label}</label>
        {description && <p className="text-xs text-slate-500">{description}</p>}
      </div>
      <button
        id={id} type="button" role="switch" aria-checked={checked} onClick={() => onChange(!checked)}
        className={clsx("relative inline-flex h-6 w-11 shrink-0 items-center rounded-full transition-colors", checked ? "bg-primary" : "bg-slate-300")}
      >
        <span className={clsx("inline-block h-5 w-5 rounded-full bg-white shadow transition-transform", checked ? "translate-x-5" : "translate-x-0.5")} />
      </button>
    </div>
  );
}
