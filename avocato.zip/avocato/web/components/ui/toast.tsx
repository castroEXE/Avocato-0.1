"use client";

import { createContext, useCallback, useContext, useState } from "react";
import clsx from "clsx";
import { CheckCircle2, Info, TriangleAlert, X } from "lucide-react";

type Tone = "success" | "error" | "info";
type Toast = { id: number; tone: Tone; message: string };

const Ctx = createContext<(message: string, tone?: Tone) => void>(() => undefined);

export function ToastProvider({ children }: { children: React.ReactNode }) {
  const [toasts, setToasts] = useState<Toast[]>([]);
  const push = useCallback((message: string, tone: Tone = "success") => {
    const id = Date.now() + Math.random();
    setToasts((t) => [...t.slice(-3), { id, tone, message }]);
    setTimeout(() => setToasts((t) => t.filter((x) => x.id !== id)), tone === "error" ? 6000 : 3500);
  }, []);

  const icons = { success: CheckCircle2, error: TriangleAlert, info: Info };
  return (
    <Ctx.Provider value={push}>
      {children}
      <div aria-live="polite" className="pointer-events-none fixed bottom-4 right-4 z-[100] flex w-[min(92vw,380px)] flex-col gap-2">
        {toasts.map((t) => {
          const Icon = icons[t.tone];
          return (
            <div
              key={t.id}
              role={t.tone === "error" ? "alert" : "status"}
              className={clsx(
                "pointer-events-auto flex animate-pop-in items-start gap-3 rounded-xl px-4 py-3 text-sm shadow-card-hover ring-1",
                t.tone === "success" && "bg-white text-slate-700 ring-primary-100",
                t.tone === "error" && "bg-white text-slate-700 ring-rose-100",
                t.tone === "info" && "bg-white text-slate-700 ring-slate-100",
              )}
            >
              <Icon className={clsx("mt-0.5 h-4 w-4 shrink-0", t.tone === "success" ? "text-primary" : t.tone === "error" ? "text-rose-600" : "text-secondary")} />
              <p className="flex-1">{t.message}</p>
              <button type="button" aria-label="Fechar aviso" onClick={() => setToasts((x) => x.filter((y) => y.id !== t.id))} className="text-slate-400 hover:text-slate-600">
                <X className="h-4 w-4" />
              </button>
            </div>
          );
        })}
      </div>
    </Ctx.Provider>
  );
}

export const useToast = () => useContext(Ctx);
