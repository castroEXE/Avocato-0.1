"use client";

import useSWR, { type SWRConfiguration } from "swr";
import { api } from "./api";
import { useSession } from "./session";

/** Busca dados da API com cache por empresa; null pausa a busca. */
export function useApi<T>(path: string | null, config?: SWRConfiguration<T>) {
  const { orgId } = useSession();
  return useSWR<T>(path && orgId ? [path, orgId] : null, ([p]: [string]) => api<T>(p), {
    revalidateOnFocus: true,
    keepPreviousData: true,
    ...config,
  });
}

/** Revalida todas as listas que começam com um prefixo (ex.: "/service-orders"). */
export function invalidate(mutate: (matcher: (key: unknown) => boolean) => unknown, ...prefixes: string[]) {
  return mutate((key) => Array.isArray(key) && typeof key[0] === "string" && prefixes.some((p) => (key[0] as string).startsWith(p)));
}
