import {
  Bot, CalendarDays, ClipboardList, LayoutDashboard, Settings, Sparkles, UserRound, Users, UsersRound, Wallet, Wrench,
  type LucideIcon,
} from "lucide-react";

export type NavItem = {
  label: string;
  /** chave de terminologia (a empresa pode renomear, ex.: Clientes → Tutores) */
  termKey?: string;
  href: string;
  icon: LucideIcon;
  module?: string;
  permission?: string;
  badge?: "requests";
};

export type NavSection = { title?: string; items: NavItem[] };

export const navigation: NavSection[] = [
  {
    items: [{ label: "Painel", href: "/", icon: LayoutDashboard }],
  },
  {
    title: "Operação",
    items: [
      { label: "Ordens de serviço", href: "/ordens", icon: ClipboardList, module: "service_orders", permission: "service_orders.read", badge: "requests" },
      { label: "Agenda", href: "/agenda", icon: CalendarDays, module: "appointments", permission: "appointments.read" },
      { label: "Clientes", termKey: "customers", href: "/clientes", icon: Users, module: "customers", permission: "customers.read" },
      { label: "Serviços", href: "/servicos", icon: Wrench, module: "services", permission: "services.read" },
      { label: "Equipe", href: "/equipe", icon: UsersRound, module: "team", permission: "staff.read" },
    ],
  },
  {
    title: "Gestão",
    items: [
      { label: "Financeiro", href: "/financeiro", icon: Wallet, module: "finance", permission: "finance.read" },
      { label: "Assistente IA", href: "/assistente", icon: Bot, module: "ai", permission: "ai.use" },
    ],
  },
  {
    title: "Conta",
    items: [
      { label: "Meu perfil", href: "/perfil", icon: UserRound },
      { label: "Configurações", href: "/configuracoes", icon: Settings, permission: "settings.read" },
    ],
  },
];

export const SparkIcon = Sparkles;
