"use client";

import type { AvatarConfig, AvatarStyle } from "./types";

/**
 * Avatares ilustrados (DiceBear), gerados no próprio navegador: sem
 * upload de foto, sem chamada externa. Cada estilo é carregado sob demanda.
 */
type StyleModule = { create: unknown; meta: unknown; schema: { properties: Record<string, SchemaProp> } };
type SchemaProp = { type?: string; items?: { enum?: string[]; pattern?: string }; default?: unknown };

export const AVATAR_STYLES: { key: AvatarStyle; label: string; credit: string }[] = [
  { key: "notionists", label: "Traço", credit: "Notionists, por Zoish (CC0)" },
  { key: "lorelei", label: "Delicado", credit: "Lorelei, por Lisa Wischofsky (CC0)" },
  { key: "adventurer", label: "Aventura", credit: "Adventurer, por Lisa Wischofsky (CC BY 4.0)" },
  { key: "big-smile", label: "Sorriso", credit: "Big Smile, por Ashley Seo (CC BY 4.0)" },
  { key: "micah", label: "Moderno", credit: "Micah, por Micah Lanier (CC BY 4.0)" },
  { key: "avataaars", label: "Clássico", credit: "Avataaars, por Pablo Stanley (uso livre)" },
];

const loaders: Record<AvatarStyle, () => Promise<StyleModule>> = {
  notionists: () => import("@dicebear/notionists") as Promise<StyleModule>,
  lorelei: () => import("@dicebear/lorelei") as Promise<StyleModule>,
  adventurer: () => import("@dicebear/adventurer") as Promise<StyleModule>,
  "big-smile": () => import("@dicebear/big-smile") as Promise<StyleModule>,
  micah: () => import("@dicebear/micah") as Promise<StyleModule>,
  avataaars: () => import("@dicebear/avataaars") as Promise<StyleModule>,
};

const cache = new Map<AvatarStyle, Promise<StyleModule>>();
export function loadStyle(style: AvatarStyle) {
  if (!cache.has(style)) cache.set(style, loaders[style]());
  return cache.get(style)!;
}

export const BACKGROUNDS = ["d9ee95", "c8e6c9", "b2dfdb", "bae6fd", "ddd6fe", "fecdd3", "fde68a", "e7e5e4"];

const SKIN = ["fde0c8", "f5cba7", "e8b08a", "d08b5b", "ae5d29", "7a4423", "5c3a21"];
const HAIR = ["2c1b18", "4a312c", "724133", "a55728", "b58143", "d6b370", "e8e1e1", "c93305", "5b8c3a", "6a4e9c"];
const CLOTHES = ["355e2b", "047857", "0d9488", "0369a1", "4338ca", "be123c", "ea580c", "eab308", "1f2937", "f5f5f4"];

const VARIANT_LABELS: Record<string, string> = {
  top: "Cabelo", hair: "Cabelo", head: "Rosto", face: "Rosto", eyes: "Olhos", eyebrows: "Sobrancelhas", brows: "Sobrancelhas",
  mouth: "Boca", lips: "Boca", nose: "Nariz", glasses: "Óculos", accessories: "Acessórios", beard: "Barba", facialHair: "Barba",
  earrings: "Brincos", clothing: "Roupa", body: "Roupa", shirt: "Camisa", gesture: "Gesto", features: "Detalhes", freckles: "Sardas",
};
const COLOR_LABELS: Record<string, { label: string; palette: string[] }> = {
  skinColor: { label: "Tom de pele", palette: SKIN },
  baseColor: { label: "Tom de pele", palette: SKIN },
  hairColor: { label: "Cor do cabelo", palette: HAIR },
  facialHairColor: { label: "Cor da barba", palette: HAIR },
  clothesColor: { label: "Cor da roupa", palette: CLOTHES },
  shirtColor: { label: "Cor da camisa", palette: CLOTHES },
};

export type VariantControl = { kind: "variant"; key: string; label: string; values: string[]; optional: boolean };
export type ColorControl = { kind: "color"; key: string; label: string; palette: string[] };

/** Monta os controles de personalização a partir do schema do estilo. */
export function controlsFor(mod: StyleModule): (VariantControl | ColorControl)[] {
  const props = mod.schema.properties;
  const out: (VariantControl | ColorControl)[] = [];
  for (const [key, prop] of Object.entries(props)) {
    const values = prop.items?.enum;
    if (values && values.length > 1 && VARIANT_LABELS[key]) {
      out.push({ kind: "variant", key, label: VARIANT_LABELS[key], values: [...values].sort(), optional: `${key}Probability` in props });
    }
  }
  for (const [key, prop] of Object.entries(props)) {
    if (prop.items?.pattern && COLOR_LABELS[key]) {
      const defaults = Array.isArray(prop.default) ? (prop.default as string[]) : [];
      const meta = COLOR_LABELS[key];
      out.push({ kind: "color", key, label: meta.label, palette: defaults.length >= 4 ? defaults : meta.palette });
    }
  }
  const order = ["top", "hair", "head", "face", "eyes", "eyebrows", "brows", "mouth", "lips", "nose", "glasses", "beard", "facialHair", "earrings", "accessories", "freckles", "features", "clothing", "body", "shirt", "gesture"];
  return out.sort((a, b) => (a.kind === b.kind ? order.indexOf(a.key) - order.indexOf(b.key) : a.kind === "variant" ? -1 : 1));
}

export async function renderAvatar(config: AvatarConfig): Promise<string> {
  const [{ createAvatar }, mod] = await Promise.all([import("@dicebear/core"), loadStyle(config.style)]);
  const opts = { backgroundColor: [BACKGROUNDS[0]!], ...config.options, seed: config.seed, radius: 50 } as Record<string, unknown>;
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  return createAvatar(mod as any, opts).toDataUri();
}

export function defaultAvatar(seed: string): AvatarConfig {
  let h = 0;
  for (const ch of seed) h = (h * 31 + ch.charCodeAt(0)) >>> 0;
  return { style: "notionists", seed: seed || "avocato", options: { backgroundColor: [BACKGROUNDS[h % BACKGROUNDS.length]!] } };
}
