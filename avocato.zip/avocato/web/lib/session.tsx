"use client";

import { createContext, useCallback, useContext, useEffect, useMemo, useState } from "react";
import type { Session } from "@supabase/supabase-js";
import { useSWRConfig } from "swr";
import { api, ApiError, orgStore } from "./api";
import { supabase } from "./supabase";
import type { Me, OrgContext } from "./types";

type Status = "loading" | "signed_out" | "no_org" | "ready" | "error";

type SessionValue = {
  status: Status;
  error: string | null;
  session: Session | null;
  me: Me | null;
  context: OrgContext | null;
  orgId: string | null;
  recovery: boolean;
  refresh: () => Promise<void>;
  selectOrg: (id: string) => Promise<void>;
  signOut: () => Promise<void>;
  can: (permission: string) => boolean;
  hasModule: (module: string) => boolean;
  term: (key: string, fallback: string) => string;
};

const Ctx = createContext<SessionValue | null>(null);

export function SessionProvider({ children }: { children: React.ReactNode }) {
  const [status, setStatus] = useState<Status>("loading");
  const [error, setError] = useState<string | null>(null);
  const [session, setSession] = useState<Session | null>(null);
  const [me, setMe] = useState<Me | null>(null);
  const [context, setContext] = useState<OrgContext | null>(null);
  const [recovery, setRecovery] = useState(false);
  const { mutate } = useSWRConfig();

  const load = useCallback(async (s: Session | null) => {
    setSession(s);
    if (!s) {
      setMe(null);
      setContext(null);
      setStatus("signed_out");
      return;
    }
    try {
      const meRes = await api<Me>("/me");
      setMe(meRes);
      const stored = orgStore.get();
      const org = meRes.organizations.find((o) => o.id === stored && o.status === "active")
        ?? meRes.organizations.find((o) => o.status === "active");
      if (!org) {
        orgStore.set(null);
        setContext(null);
        setStatus("no_org");
        return;
      }
      orgStore.set(org.id);
      setContext(await api<OrgContext>("/organization/context"));
      setStatus("ready");
      setError(null);
    } catch (e) {
      if (e instanceof ApiError && e.status === 401) {
        await supabase().auth.signOut();
        setStatus("signed_out");
        return;
      }
      if (e instanceof ApiError && e.code === "tenant_forbidden") {
        orgStore.set(null);
        setStatus("no_org");
        return;
      }
      setError(e instanceof Error ? e.message : "Erro ao carregar sua conta.");
      setStatus("error");
    }
  }, []);

  useEffect(() => {
    const sb = supabase();
    sb.auth.getSession().then(({ data }) => load(data.session));
    const { data: sub } = sb.auth.onAuthStateChange((event, s) => {
      if (event === "PASSWORD_RECOVERY") setRecovery(true);
      if (event === "SIGNED_IN" || event === "SIGNED_OUT" || event === "USER_UPDATED") load(s);
      if (event === "TOKEN_REFRESHED") setSession(s);
    });
    return () => sub.subscription.unsubscribe();
  }, [load]);

  const value = useMemo<SessionValue>(() => ({
    status, error, session, me, context, recovery,
    orgId: context?.organization.id ?? null,
    refresh: async () => {
      const { data } = await supabase().auth.getSession();
      await load(data.session);
    },
    selectOrg: async (id: string) => {
      orgStore.set(id);
      await mutate(() => true, undefined, { revalidate: false });
      const { data } = await supabase().auth.getSession();
      await load(data.session);
    },
    signOut: async () => {
      orgStore.set(null);
      await supabase().auth.signOut();
      await mutate(() => true, undefined, { revalidate: false });
      setRecovery(false);
    },
    can: (p) => !!context?.permissions.includes(p),
    hasModule: (m) => !!context?.enabledModules.includes(m),
    term: (k, fallback) => context?.settings.terminology?.[k] || fallback,
  }), [status, error, session, me, context, recovery, load, mutate]);

  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}

export function useSession() {
  const v = useContext(Ctx);
  if (!v) throw new Error("useSession fora do SessionProvider");
  return v;
}
