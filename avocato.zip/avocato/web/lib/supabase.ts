import { createClient, type SupabaseClient } from "@supabase/supabase-js";

const url = process.env.NEXT_PUBLIC_SUPABASE_URL;
const key = process.env.NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY ?? process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY;

export const supabaseConfigured = Boolean(url && key);

let client: SupabaseClient | null = null;

/**
 * O Supabase é usado SÓ para autenticação (login, cadastro, sessão).
 * Todos os dados passam pela API do Avocato.
 */
export function supabase(): SupabaseClient {
  if (!client) {
    client = createClient(url ?? "http://localhost:54321", key ?? "public-anon-key", {
      auth: { persistSession: true, autoRefreshToken: true, detectSessionInUrl: true, storageKey: "avocato.auth" },
    });
  }
  return client;
}
