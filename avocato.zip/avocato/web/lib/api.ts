import { supabase } from "./supabase";

export const API_URL = (process.env.NEXT_PUBLIC_API_URL ?? "http://localhost:3333").replace(/\/$/, "");
const ORG_KEY = "avocato.org";

export class ApiError extends Error {
  constructor(
    readonly status: number,
    readonly code: string,
    message: string,
    readonly details?: unknown,
  ) {
    super(message);
  }

  /** Erros de campo vindos da validação da API: { campo: mensagem } */
  fieldErrors(): Record<string, string> {
    if (!Array.isArray(this.details)) return {};
    const out: Record<string, string> = {};
    for (const d of this.details as { field?: string; message?: string }[]) {
      if (d.field) out[d.field] = d.message ?? "Valor inválido";
    }
    return out;
  }
}

export const orgStore = {
  get: () => (typeof window === "undefined" ? null : window.localStorage.getItem(ORG_KEY)),
  set: (id: string | null) => {
    if (typeof window === "undefined") return;
    if (id) window.localStorage.setItem(ORG_KEY, id);
    else window.localStorage.removeItem(ORG_KEY);
  },
};

type Options = { method?: "GET" | "POST" | "PATCH" | "DELETE"; body?: unknown; anonymous?: boolean };

/** Cliente HTTP único: injeta o token do Supabase e a empresa ativa. */
export async function api<T>(path: string, opts: Options = {}): Promise<T> {
  const headers: Record<string, string> = {};
  if (opts.body !== undefined) headers["content-type"] = "application/json";
  if (!opts.anonymous) {
    const { data } = await supabase().auth.getSession();
    if (data.session) headers.authorization = `Bearer ${data.session.access_token}`;
    const org = orgStore.get();
    if (org) headers["x-organization-id"] = org;
  }

  let res: Response;
  try {
    res = await fetch(`${API_URL}/v1${path}`, {
      method: opts.method ?? "GET",
      headers,
      body: opts.body !== undefined ? JSON.stringify(opts.body) : undefined,
    });
  } catch {
    throw new ApiError(0, "network_error", "Não foi possível falar com o servidor. Verifique sua conexão.");
  }

  if (res.status === 204) return undefined as T;
  const text = await res.text();
  const json = text ? JSON.parse(text) : null;
  if (!res.ok) {
    const e = json?.error ?? {};
    throw new ApiError(res.status, e.code ?? "error", e.message ?? "Algo deu errado.", e.details);
  }
  return json as T;
}
