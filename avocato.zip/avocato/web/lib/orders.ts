import type { BadgeTone } from "@/components/ui/misc";
import type { AppointmentStatus, OrderStatus } from "./types";

export const STATUS_META: Record<OrderStatus, { label: string; tone: BadgeTone }> = {
  requested: { label: "Solicitada", tone: "amber" },
  open: { label: "Aberta", tone: "sky" },
  scheduled: { label: "Agendada", tone: "violet" },
  in_progress: { label: "Em andamento", tone: "teal" },
  done: { label: "Concluída", tone: "green" },
  canceled: { label: "Cancelada", tone: "slate" },
};

/** Espelha as transições aceitas pela API, com o rótulo do botão. */
export const ORDER_ACTIONS: Record<OrderStatus, { to: OrderStatus; label: string; primary?: boolean; danger?: boolean }[]> = {
  requested: [{ to: "open", label: "Aprovar solicitação", primary: true }, { to: "canceled", label: "Recusar", danger: true }],
  open: [{ to: "in_progress", label: "Iniciar serviço", primary: true }, { to: "done", label: "Concluir" }, { to: "canceled", label: "Cancelar", danger: true }],
  scheduled: [{ to: "in_progress", label: "Iniciar serviço", primary: true }, { to: "done", label: "Concluir" }, { to: "canceled", label: "Cancelar", danger: true }],
  in_progress: [{ to: "done", label: "Concluir serviço", primary: true }, { to: "canceled", label: "Cancelar", danger: true }],
  done: [{ to: "in_progress", label: "Reabrir" }],
  canceled: [{ to: "open", label: "Reabrir" }],
};

export const APPOINTMENT_META: Record<AppointmentStatus, { label: string; tone: BadgeTone; dot: string }> = {
  scheduled: { label: "Agendado", tone: "sky", dot: "bg-sky-500" },
  confirmed: { label: "Confirmado", tone: "teal", dot: "bg-teal-500" },
  in_progress: { label: "Atendendo", tone: "violet", dot: "bg-violet-500" },
  done: { label: "Concluído", tone: "green", dot: "bg-primary" },
  canceled: { label: "Cancelado", tone: "slate", dot: "bg-slate-400" },
  no_show: { label: "Faltou", tone: "rose", dot: "bg-rose-500" },
};
