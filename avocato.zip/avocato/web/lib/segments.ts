/** Segmentos de negócio: ajustam termos e sugerem um catálogo inicial. */
export type Segment = {
  key: string;
  label: string;
  emoji: string;
  terminology?: Record<string, string>;
  services: { name: string; priceCents: number; durationMinutes: number }[];
};

export const SEGMENTS: Segment[] = [
  { key: "manutencao", label: "Elétrica, hidráulica e reparos", emoji: "🔧", services: [
    { name: "Visita técnica", priceCents: 9000, durationMinutes: 45 },
    { name: "Instalação de tomada", priceCents: 12000, durationMinutes: 60 },
    { name: "Troca de disjuntor", priceCents: 18000, durationMinutes: 60 },
  ] },
  { key: "beleza", label: "Salão, barbearia e estética", emoji: "💇", services: [
    { name: "Corte masculino", priceCents: 4500, durationMinutes: 30 },
    { name: "Corte feminino", priceCents: 8000, durationMinutes: 60 },
    { name: "Escova", priceCents: 6000, durationMinutes: 45 },
    { name: "Manicure", priceCents: 3500, durationMinutes: 40 },
  ] },
  { key: "pet", label: "Pet shop e banho e tosa", emoji: "🐶", terminology: { customers: "Tutores" }, services: [
    { name: "Banho porte P", priceCents: 5000, durationMinutes: 60 },
    { name: "Banho e tosa", priceCents: 9000, durationMinutes: 90 },
    { name: "Tosa higiênica", priceCents: 4000, durationMinutes: 30 },
  ] },
  { key: "saude", label: "Clínica e consultório", emoji: "🩺", terminology: { customers: "Pacientes" }, services: [
    { name: "Consulta", priceCents: 20000, durationMinutes: 50 },
    { name: "Retorno", priceCents: 10000, durationMinutes: 30 },
  ] },
  { key: "oficina", label: "Oficina mecânica", emoji: "🚗", services: [
    { name: "Troca de óleo", priceCents: 15000, durationMinutes: 60 },
    { name: "Alinhamento e balanceamento", priceCents: 9000, durationMinutes: 60 },
    { name: "Revisão completa", priceCents: 35000, durationMinutes: 180 },
  ] },
  { key: "limpeza", label: "Limpeza e conservação", emoji: "🧽", services: [
    { name: "Faxina residencial", priceCents: 18000, durationMinutes: 240 },
    { name: "Limpeza pós-obra", priceCents: 45000, durationMinutes: 480 },
  ] },
  { key: "tecnologia", label: "Assistência técnica e TI", emoji: "💻", services: [
    { name: "Diagnóstico", priceCents: 6000, durationMinutes: 30 },
    { name: "Formatação", priceCents: 15000, durationMinutes: 120 },
    { name: "Manutenção preventiva", priceCents: 12000, durationMinutes: 90 },
  ] },
  { key: "outro", label: "Outro tipo de serviço", emoji: "✨", services: [] },
];
