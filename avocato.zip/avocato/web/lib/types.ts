export type AvatarConfig = { style: AvatarStyle; seed: string; options: Record<string, unknown> };
export type AvatarStyle = "notionists" | "lorelei" | "adventurer" | "big-smile" | "micah" | "avataaars";

export type Me = {
  user: { id: string; email: string | null; fullName: string; avatarUrl: string | null; avatar: AvatarConfig | null };
  organizations: { id: string; name: string; slug: string; status: string; roleKey: string; roleName: string }[];
  isPlatformAdmin: boolean;
};

export type OrgContext = {
  organization: { id: string; name: string; slug: string; status: string; timezone: string; currency: string };
  role: { key: string; name: string };
  permissions: string[];
  enabledModules: string[];
  settings: {
    onboardingStatus: string;
    businessProfile: { segment?: string; phone?: string; description?: string; [k: string]: unknown };
    enabledModules: Record<string, boolean>;
    terminology: Record<string, string>;
    workflowConfiguration: { publicRequestsEnabled?: boolean; [k: string]: unknown };
    dashboardConfiguration: Record<string, unknown>;
    aiConfiguration: Record<string, unknown>;
  };
  subscription: { planKey: string; planName: string; status: string; trialEndsAt: string | null; limits: Record<string, number | null> };
};

export type Customer = {
  id: string; kind: "person" | "company"; name: string; email: string | null; phone: string | null; document: string | null;
  address: Record<string, string>; status: "active" | "inactive" | "blocked"; source: string | null; tags: string[];
  notes: string | null; customFields: Record<string, unknown>; lastPurchaseAt: string | null; createdAt: string;
};

export type Service = {
  id: string; name: string; description: string | null; category: string | null; priceCents: number; costCents: number;
  commissionRate: number; marginCents: number; durationMinutes: number | null; isActive: boolean; ordersCount?: number;
};

export type StaffMember = {
  id: string; kind: "employee" | "freelancer" | "contractor"; name: string; email: string | null; phone: string | null;
  jobTitle: string | null; specialties: string[]; commissionRate: number; isExternal: boolean; status: "active" | "inactive"; openOrders?: number;
};

export type OrderStatus = "requested" | "open" | "scheduled" | "in_progress" | "done" | "canceled";

export type ServiceOrder = {
  id: string; number: number; title: string | null; status: OrderStatus; source: "internal" | "public_request" | "ai";
  customer: { id: string; name: string; phone: string | null; email: string | null };
  staff: { id: string; name: string } | null; description: string | null;
  scheduledFor: string | null; preferredDate: string | null; startedAt: string | null; completedAt: string | null;
  totalCents: number; costCents: number; rating: number | null; ratingComment: string | null; createdAt: string;
  items?: { id: string; serviceId: string | null; description: string; quantity: number; unitPriceCents: number; totalCents: number }[];
  receivable?: { id: string; status: string; amountCents: number; paidAmountCents: number } | null;
};

export type AppointmentStatus = "scheduled" | "confirmed" | "in_progress" | "done" | "canceled" | "no_show";
export type Appointment = {
  id: string; startsAt: string; endsAt: string; status: AppointmentStatus;
  customer: { id: string; name: string; phone: string | null };
  service: { id: string; name: string } | null; staff: { id: string; name: string } | null;
  priceCents: number | null; notes: string | null;
};

export type FinancialEntry = {
  id: string; direction: "in" | "out"; description: string; amountCents: number; paidAmountCents: number; dueOn: string;
  status: "open" | "partially_paid" | "paid" | "canceled"; isOverdue: boolean; paidAt: string | null; paymentMethod: string | null;
  category: { id: string; name: string } | null; customer: { id: string; name: string } | null; serviceOrderId: string | null;
  recurringRuleId: string | null;
};

export type FinanceTotals = {
  receivableOpenCents: number; receivableOverdueCents: number; receivedMonthCents: number;
  payableOpenCents: number; payableOverdueCents: number; paidMonthCents: number;
};

export type Dashboard = {
  finance: {
    receivedMonthCents: number; receivedPrevMonthCents: number; paidMonthCents: number; receivableOpenCents: number;
    receivableOverdueCents: number; payableOpenCents: number; payableOverdueCents: number;
  } | null;
  cashflow: { month: string; incomeCents: number; expenseCents: number }[];
  orders: { requested: number; active: number; doneThisMonth: number; series: { month: string; created: number; done: number }[] };
  customers: { total: number; newThisMonth: number };
  todayAppointments: number;
  averageRating: number | null;
  topServices: { id: string; name: string; quantity: number; revenueCents: number; previousRevenueCents: number }[];
  upcoming: { id: string; startsAt: string; customer: string; service: string | null; staff: string | null }[];
};

export type Paged<T> = { data: T[]; total: number };
