import type { Config } from "tailwindcss";
import colors from "tailwindcss/colors";

const config: Config = {
  content: ["./app/**/*.{ts,tsx}", "./components/**/*.{ts,tsx}", "./lib/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        // Primária: verde abacate profundo (emerald)
        primary: {
          50: colors.emerald[50],
          100: colors.emerald[100],
          200: colors.emerald[200],
          300: colors.emerald[300],
          light: colors.emerald[100],
          DEFAULT: colors.emerald[700],
          dark: colors.emerald[800],
          darker: colors.emerald[900],
        },
        // Secundária: verde-água (teal), conversa com o verde sem competir
        secondary: {
          50: colors.teal[50],
          100: colors.teal[100],
          200: colors.teal[200],
          light: colors.teal[100],
          DEFAULT: colors.teal[600],
          dark: colors.teal[700],
          darker: colors.teal[800],
        },
        // Cores da marca, tiradas do próprio abacate
        avocado: {
          skin: "#355e2b",
          leaf: "#4d7c35",
          flesh: "#d9ee95",
          cream: "#f3f9dc",
          pit: "#9b6638",
        },
        surface: {
          page: "#f6f8f4",
          muted: colors.stone[100],
        },
        ink: {
          DEFAULT: colors.slate[800],
          muted: colors.slate[500],
          subtle: colors.slate[400],
        },
      },
      fontFamily: {
        sans: ["var(--font-roboto, Roboto)", "ui-sans-serif", "system-ui", "sans-serif"],
      },
      boxShadow: {
        card: "0 2px 14px 0 rgb(32 45 36 / 0.06)",
        "card-hover": "0 4px 24px 0 rgb(32 45 36 / 0.10)",
        float: "0 12px 32px -8px rgb(4 120 87 / 0.38)",
        "float-teal": "0 12px 32px -8px rgb(13 148 136 / 0.35)",
      },
      borderRadius: { "4xl": "2rem" },
      width: { sidebar: "16.25rem" },
      spacing: { sidebar: "16.25rem", header: "5rem" },
      keyframes: {
        "fade-in": { from: { opacity: "0" }, to: { opacity: "1" } },
        "pop-in": { from: { opacity: "0", transform: "translateY(8px) scale(.98)" }, to: { opacity: "1", transform: "none" } },
      },
      animation: {
        "fade-in": "fade-in .15s ease-out",
        "pop-in": "pop-in .18s ease-out",
      },
    },
  },
  plugins: [],
};

export default config;
