"use client";

import { SWRConfig } from "swr";
import { ToastProvider } from "@/components/ui/toast";
import { SessionProvider } from "@/lib/session";

export default function Providers({ children }: { children: React.ReactNode }) {
  return (
    <SWRConfig value={{ shouldRetryOnError: false }}>
      <SessionProvider>
        <ToastProvider>{children}</ToastProvider>
      </SessionProvider>
    </SWRConfig>
  );
}
