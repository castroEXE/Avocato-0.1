"use client";

import { Suspense, useEffect, useState } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import { TriangleAlert } from "lucide-react";
import AuthLayout from "@/components/layout/AuthLayout";
import { TextField } from "@/components/ui/fields";
import { Segmented, Spinner } from "@/components/ui/misc";
import { useToast } from "@/components/ui/toast";
import { useSession } from "@/lib/session";
import { supabase, supabaseConfigured } from "@/lib/supabase";

type Mode = "login" | "signup" | "forgot";

const authMessage = (msg: string) => {
  if (/invalid login/i.test(msg)) return "E-mail ou senha incorretos.";
  if (/email not confirmed/i.test(msg)) return "Confirme seu e-mail antes de entrar (veja sua caixa de entrada).";
  if (/already registered|already been registered/i.test(msg)) return "Este e-mail já tem conta. Use a aba Entrar.";
  if (/password should be/i.test(msg)) return "A senha precisa ter pelo menos 6 caracteres.";
  if (/rate limit/i.test(msg)) return "Muitas tentativas. Aguarde um pouco e tente de novo.";
  return msg;
};

function LoginForm() {
  const router = useRouter();
  const params = useSearchParams();
  const toast = useToast();
  const { status, recovery } = useSession();
  const [mode, setMode] = useState<Mode>("login");
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);

  const next = params.get("voltar") || "/";

  useEffect(() => {
    if (recovery) return;
    if (status === "ready") router.replace(next.startsWith("/") ? next : "/");
    if (status === "no_org") router.replace("/criar-empresa");
  }, [status, recovery, router, next]);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true);
    setError(null);
    setNotice(null);
    const sb = supabase();
    try {
      if (recovery) {
        const { error } = await sb.auth.updateUser({ password });
        if (error) throw error;
        toast("Senha alterada! Você já está conectado.");
        router.replace("/");
      } else if (mode === "login") {
        const { error } = await sb.auth.signInWithPassword({ email, password });
        if (error) throw error;
      } else if (mode === "signup") {
        const { data, error } = await sb.auth.signUp({
          email, password, options: { data: { full_name: name.trim() }, emailRedirectTo: `${window.location.origin}/entrar` },
        });
        if (error) throw error;
        if (!data.session) setNotice("Conta criada! Enviamos um link de confirmação para o seu e-mail. Depois é só entrar.");
      } else {
        const { error } = await sb.auth.resetPasswordForEmail(email, { redirectTo: `${window.location.origin}/entrar` });
        if (error) throw error;
        setNotice("Se o e-mail tiver conta, você vai receber um link para criar uma nova senha.");
      }
    } catch (err) {
      setError(authMessage(err instanceof Error ? err.message : "Não foi possível continuar."));
    } finally {
      setBusy(false);
    }
  }

  const titles = {
    login: ["Que bom te ver de novo", "Entre para cuidar do seu negócio."],
    signup: ["Crie sua conta grátis", "Em 2 minutos sua empresa está no ar."],
    forgot: ["Esqueceu a senha?", "A gente te manda um link para criar outra."],
  } as const;
  const [title, subtitle] = recovery ? ["Crie uma nova senha", "Escolha uma senha com pelo menos 6 caracteres."] : titles[mode];

  return (
    <AuthLayout>
      <h1 className="text-2xl font-semibold tracking-tight text-slate-900">{title}</h1>
      <p className="mt-1 text-sm text-slate-500">{subtitle}</p>

      {!supabaseConfigured && (
        <div role="alert" className="mt-5 flex gap-2 rounded-xl bg-amber-50 p-3 text-sm text-amber-800">
          <TriangleAlert className="mt-0.5 h-4 w-4 shrink-0" />
          Configure NEXT_PUBLIC_SUPABASE_URL e NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY no arquivo .env.local (veja o README).
        </div>
      )}

      {!recovery && mode !== "forgot" && (
        <div className="mt-6">
          <Segmented label="Entrar ou criar conta" value={mode} onChange={(m) => { setMode(m); setError(null); setNotice(null); }}
            options={[{ value: "login", label: "Entrar" }, { value: "signup", label: "Criar conta" }]} />
        </div>
      )}

      <form onSubmit={submit} className="mt-6 space-y-4" noValidate={false}>
        {!recovery && mode === "signup" && (
          <TextField label="Seu nome" required autoComplete="name" value={name} onChange={(e) => setName(e.target.value)} placeholder="Como você quer ser chamado" />
        )}
        {!recovery && (
          <TextField label="E-mail" type="email" required autoComplete="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="voce@empresa.com" />
        )}
        {(recovery || mode !== "forgot") && (
          <TextField label={recovery ? "Nova senha" : "Senha"} type="password" required minLength={6}
            autoComplete={mode === "login" && !recovery ? "current-password" : "new-password"}
            value={password} onChange={(e) => setPassword(e.target.value)} placeholder="Mínimo de 6 caracteres" />
        )}

        {error && <p role="alert" className="rounded-xl bg-rose-50 px-3 py-2.5 text-sm text-rose-700">{error}</p>}
        {notice && <p role="status" className="rounded-xl bg-primary-50 px-3 py-2.5 text-sm text-primary-dark">{notice}</p>}

        <button type="submit" disabled={busy} className="btn btn-primary h-11 w-full">
          {busy && <Spinner />}
          {recovery ? "Salvar nova senha" : mode === "login" ? "Entrar" : mode === "signup" ? "Criar minha conta" : "Enviar link"}
        </button>
      </form>

      {!recovery && (
        <p className="mt-5 text-center text-sm text-slate-500">
          {mode === "forgot" ? (
            <button type="button" className="font-medium text-primary hover:underline" onClick={() => { setMode("login"); setNotice(null); }}>Voltar para o login</button>
          ) : mode === "login" ? (
            <button type="button" className="font-medium text-primary hover:underline" onClick={() => { setMode("forgot"); setError(null); }}>Esqueci minha senha</button>
          ) : (
            <>Ao criar a conta você ganha 14 dias de teste do plano Starter.</>
          )}
        </p>
      )}
    </AuthLayout>
  );
}

export default function EntrarPage() {
  return <Suspense><LoginForm /></Suspense>;
}
