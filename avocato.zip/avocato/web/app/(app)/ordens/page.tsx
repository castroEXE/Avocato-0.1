"use client";

import { Suspense, useEffect, useState } from "react";
import { usePathname, useRouter, useSearchParams } from "next/navigation";
import { Bot, ClipboardList, Copy, Globe, Plus, Search } from "lucide-react";
import OrderDetail from "@/components/forms/OrderDetail";
import OrderForm from "@/components/forms/OrderForm";
import { Badge, EmptyState, ErrorBox, ListSkeleton, PageHeader, Segmented } from "@/components/ui/misc";
import { useToast } from "@/components/ui/toast";
import { api } from "@/lib/api";
import { brl, dateBR, dateTimeBR, orderNumber } from "@/lib/format";
import { useApi } from "@/lib/hooks";
import { STATUS_META } from "@/lib/orders";
import { useSession } from "@/lib/session";
import type { Customer, OrderStatus, ServiceOrder } from "@/lib/types";

type Tab = "requested" | "active" | "done" | "canceled" | "all";

function OrdensView() {
  const params = useSearchParams();
  const router = useRouter();
  const pathname = usePathname();
  const toast = useToast();
  const { can, context } = useSession();
  const [tab, setTab] = useState<Tab>((params.get("status") as Tab) || "active");
  const [q, setQ] = useState(params.get("q") ?? "");
  const [debounced, setDebounced] = useState(q);
  const [formOpen, setFormOpen] = useState(false);
  const [editing, setEditing] = useState<ServiceOrder | null>(null);
  const [initialCustomer, setInitialCustomer] = useState<{ id: string; name: string; phone?: string | null } | null>(null);
  const detailId = params.get("id");

  useEffect(() => { const t = setTimeout(() => setDebounced(q), 250); return () => clearTimeout(t); }, [q]);
  useEffect(() => {
    const st = params.get("status") as Tab | null;
    if (st) setTab(st);
    if (params.get("q")) { setQ(params.get("q")!); setTab("all"); }
    if (params.get("nova")) {
      const cid = params.get("cliente");
      setEditing(null);
      if (cid) api<Customer>(`/customers/${cid}`).then((c) => setInitialCustomer({ id: c.id, name: c.name, phone: c.phone })).catch(() => undefined);
      else setInitialCustomer(null);
      setFormOpen(true);
      router.replace(pathname);
    }
  }, [params, router, pathname]);

  const qs = new URLSearchParams({ limit: "100" });
  if (tab !== "all") qs.set("status", tab);
  if (debounced.trim()) qs.set("q", debounced.trim());
  const { data, error, isLoading, mutate } = useApi<{ data: ServiceOrder[]; total: number; counts: Record<OrderStatus, number> }>(`/service-orders?${qs}`);
  const counts = data?.counts;
  const openDetail = (id: string | null) => router.replace(id ? `${pathname}?id=${id}` : pathname, { scroll: false });

  const publicUrl = context ? `${typeof window !== "undefined" ? window.location.origin : ""}/solicitar/${context.organization.slug}` : "";

  return (
    <>
      <PageHeader title="Ordens de serviço" description="Pedidos dos clientes e serviços em execução, do início ao pagamento."
        actions={<>
          {context?.settings.workflowConfiguration?.publicRequestsEnabled !== false && (
            <button type="button" className="btn btn-outline" onClick={async () => { await navigator.clipboard.writeText(publicUrl).catch(() => undefined); toast("Link de pedidos copiado. Mande para seus clientes!"); }}>
              <Copy className="h-4 w-4" /> Link de pedidos
            </button>
          )}
          {can("service_orders.create") && (
            <button type="button" className="btn btn-primary" onClick={() => { setEditing(null); setInitialCustomer(null); setFormOpen(true); }}><Plus className="h-4 w-4" /> Nova OS</button>
          )}
        </>} />

      <div className="card">
        <div className="flex flex-wrap items-center gap-3 border-b border-slate-100 p-4">
          <Segmented label="Status" value={tab} onChange={setTab} options={[
            { value: "requested", label: "Solicitações", count: counts?.requested },
            { value: "active", label: "Em aberto", count: counts ? counts.open + counts.scheduled + counts.in_progress : undefined },
            { value: "done", label: "Concluídas" },
            { value: "canceled", label: "Canceladas" },
            { value: "all", label: "Todas" },
          ]} />
          <div className="relative min-w-[200px] flex-1">
            <Search className="pointer-events-none absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
            <input className="input pl-10" type="search" value={q} onChange={(e) => setQ(e.target.value)} placeholder="Buscar por cliente, título ou número" aria-label="Buscar OS" />
          </div>
        </div>

        {error && <ErrorBox message={error.message} onRetry={() => mutate()} />}
        {isLoading && !data && <ListSkeleton />}
        {data && data.data.length === 0 && (
          <EmptyState icon={ClipboardList}
            title={tab === "requested" ? "Nenhuma solicitação pendente" : debounced ? "Nada encontrado" : "Nenhuma OS por aqui"}
            description={tab === "requested" ? "Compartilhe seu link de pedidos: as solicitações dos clientes chegam aqui." : "Abra uma OS para registrar um serviço."}
            action={tab !== "requested" && can("service_orders.create") && <button type="button" className="btn btn-primary" onClick={() => { setEditing(null); setFormOpen(true); }}><Plus className="h-4 w-4" /> Nova OS</button>} />
        )}

        {data && data.data.length > 0 && (
          <ul className="divide-y divide-slate-100">
            {data.data.map((o) => (
              <li key={o.id}>
                <button type="button" onClick={() => openDetail(o.id)} className="flex w-full items-center gap-4 px-4 py-3.5 text-left hover:bg-slate-50/70">
                  <span className="hidden w-16 shrink-0 text-sm font-semibold text-slate-400 sm:block">{orderNumber(o.number)}</span>
                  <span className="min-w-0 flex-1">
                    <span className="flex items-center gap-2">
                      <span className="truncate text-sm font-medium text-slate-800">{o.title ?? "Serviço"}</span>
                      {o.source === "public_request" && <Globe className="h-3.5 w-3.5 shrink-0 text-amber-500" aria-label="Pedido pelo link" />}
                      {o.source === "ai" && <Bot className="h-3.5 w-3.5 shrink-0 text-violet-500" aria-label="Criada pela IA" />}
                    </span>
                    <span className="block truncate text-xs text-slate-500">
                      <span className="sm:hidden">{orderNumber(o.number)} · </span>{o.customer.name}{o.staff && ` · ${o.staff.name}`}
                    </span>
                  </span>
                  <span className="hidden w-36 text-right text-xs text-slate-500 md:block">
                    {o.scheduledFor ? dateTimeBR(o.scheduledFor) : o.preferredDate ? `Prefere ${dateBR(o.preferredDate)}` : dateBR(o.createdAt)}
                  </span>
                  <span className="w-24 text-right text-sm font-medium text-slate-800">{brl(o.totalCents)}</span>
                  <Badge tone={STATUS_META[o.status].tone} className="hidden w-28 justify-center sm:inline-flex">{STATUS_META[o.status].label}</Badge>
                </button>
              </li>
            ))}
          </ul>
        )}
      </div>

      <OrderForm open={formOpen} onClose={() => setFormOpen(false)} order={editing} initialCustomer={initialCustomer} onSaved={(o) => !editing && openDetail(o.id)} />
      <OrderDetail id={detailId} onClose={() => openDetail(null)} onEdit={(o) => { setEditing(o); setFormOpen(true); }} />
    </>
  );
}

export default function OrdensPage() {
  return <Suspense><OrdensView /></Suspense>;
}
