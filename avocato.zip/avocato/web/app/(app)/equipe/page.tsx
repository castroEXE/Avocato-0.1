"use client";

import { useEffect, useState } from "react";
import clsx from "clsx";
import { useSWRConfig } from "swr";
import { MessageCircle, Pencil, Plus, UsersRound } from "lucide-react";
import UserAvatar from "@/components/avatar/UserAvatar";
import Modal from "@/components/ui/Modal";
import { SelectField, TextField, Toggle } from "@/components/ui/fields";
import { Badge, EmptyState, ErrorBox, ListSkeleton, PageHeader, Segmented, Spinner } from "@/components/ui/misc";
import { useToast } from "@/components/ui/toast";
import { api, ApiError } from "@/lib/api";
import { whatsappLink } from "@/lib/format";
import { invalidate, useApi } from "@/lib/hooks";
import { useSession } from "@/lib/session";
import type { StaffMember } from "@/lib/types";

const KIND = { employee: "Funcionário", freelancer: "Freelancer", contractor: "Prestador PJ" } as const;

function StaffForm({ open, onClose, member }: { open: boolean; onClose: () => void; member: StaffMember | null }) {
  const toast = useToast();
  const { mutate } = useSWRConfig();
  const [f, setF] = useState({ name: "", kind: "employee", jobTitle: "", phone: "", email: "", specialties: "", commission: "0", active: true });
  const [busy, setBusy] = useState(false);
  const [errors, setErrors] = useState<Record<string, string>>({});

  useEffect(() => {
    if (!open) return;
    setErrors({});
    setF({
      name: member?.name ?? "", kind: member?.kind ?? "employee", jobTitle: member?.jobTitle ?? "", phone: member?.phone ?? "", email: member?.email ?? "",
      specialties: member?.specialties.join(", ") ?? "", commission: String(Math.round((member?.commissionRate ?? 0) * 100)), active: (member?.status ?? "active") === "active",
    });
  }, [open, member]);

  async function save(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true);
    const body = {
      name: f.name.trim(), kind: f.kind, jobTitle: f.jobTitle.trim() || null, phone: f.phone.trim() || null, email: f.email.trim() || null,
      specialties: f.specialties.split(",").map((s) => s.trim()).filter(Boolean), commissionRate: Math.min(Math.max(Number(f.commission) || 0, 0), 100) / 100,
      isExternal: f.kind !== "employee", status: f.active ? "active" : "inactive",
    };
    try {
      await api(member ? `/staff/${member.id}` : "/staff", { method: member ? "PATCH" : "POST", body });
      await invalidate(mutate, "/staff");
      toast(member ? "Cadastro atualizado." : "Profissional cadastrado.");
      onClose();
    } catch (err) {
      if (err instanceof ApiError) { setErrors(err.fieldErrors()); toast(err.message, "error"); }
    } finally {
      setBusy(false);
    }
  }

  return (
    <Modal open={open} onClose={onClose} title={member ? "Editar profissional" : "Novo profissional"} size="lg"
      footer={<><button type="button" className="btn btn-ghost" onClick={onClose}>Cancelar</button>
        <button type="submit" form="staff-form" className="btn btn-primary" disabled={busy}>{busy && <Spinner />} Salvar</button></>}>
      <form id="staff-form" onSubmit={save} className="grid gap-4 sm:grid-cols-2">
        <TextField className="sm:col-span-2" label="Nome" required value={f.name} onChange={(e) => setF({ ...f, name: e.target.value })} error={errors.name} />
        <SelectField label="Vínculo" value={f.kind} onChange={(e) => setF({ ...f, kind: e.target.value })} options={Object.entries(KIND).map(([value, label]) => ({ value, label }))} />
        <TextField label="Cargo / função" value={f.jobTitle} onChange={(e) => setF({ ...f, jobTitle: e.target.value })} placeholder="Ex.: Eletricista" />
        <TextField label="Telefone / WhatsApp" type="tel" value={f.phone} onChange={(e) => setF({ ...f, phone: e.target.value })} />
        <TextField label="E-mail" type="email" value={f.email} onChange={(e) => setF({ ...f, email: e.target.value })} error={errors.email} />
        <TextField label="Especialidades" value={f.specialties} onChange={(e) => setF({ ...f, specialties: e.target.value })} hint="Separe por vírgula" />
        <TextField label="Comissão padrão (%)" type="number" min={0} max={100} value={f.commission} onChange={(e) => setF({ ...f, commission: e.target.value })} />
        <div className="sm:col-span-2"><Toggle checked={f.active} onChange={(v) => setF({ ...f, active: v })} label="Ativo" description="Profissionais inativos não aparecem para novas OS e agendamentos." /></div>
      </form>
    </Modal>
  );
}

export default function EquipePage() {
  const { can } = useSession();
  const [status, setStatus] = useState<"active" | "all">("active");
  const [editing, setEditing] = useState<StaffMember | null>(null);
  const [open, setOpen] = useState(false);
  const { data, error, mutate } = useApi<{ data: StaffMember[] }>(`/staff?status=${status}`);
  const canManage = can("staff.manage");

  return (
    <>
      <PageHeader title="Equipe" description="Funcionários e prestadores que executam os serviços."
        actions={canManage && <button type="button" className="btn btn-primary" onClick={() => { setEditing(null); setOpen(true); }}><Plus className="h-4 w-4" /> Novo profissional</button>} />
      <div className="mb-4"><Segmented label="Mostrar" value={status} onChange={setStatus} options={[{ value: "active", label: "Ativos" }, { value: "all", label: "Todos" }]} /></div>
      {error && <ErrorBox message={error.message} onRetry={() => mutate()} />}
      {!data && !error && <div className="card"><ListSkeleton rows={3} /></div>}
      {data && data.data.length === 0 && (
        <div className="card"><EmptyState icon={UsersRound} title="Ninguém na equipe ainda" description="Cadastre quem faz os serviços para distribuir OS e montar a agenda."
          action={canManage && <button type="button" className="btn btn-primary" onClick={() => { setEditing(null); setOpen(true); }}><Plus className="h-4 w-4" /> Novo profissional</button>} /></div>
      )}
      {data && data.data.length > 0 && (
        <ul className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3">
          {data.data.map((m) => {
            const wa = whatsappLink(m.phone);
            return (
              <li key={m.id} className={clsx("card flex items-center gap-4 p-5", m.status === "inactive" && "opacity-60")}>
                <UserAvatar name={m.name} size={56} />
                <div className="min-w-0 flex-1">
                  <p className="truncate font-medium text-slate-800">{m.name}</p>
                  <p className="truncate text-sm text-slate-500">{m.jobTitle ?? KIND[m.kind]}</p>
                  <div className="mt-1.5 flex flex-wrap gap-1.5">
                    <Badge tone={m.kind === "employee" ? "green" : "teal"}>{KIND[m.kind]}</Badge>
                    {(m.openOrders ?? 0) > 0 && <Badge tone="sky">{m.openOrders} OS em aberto</Badge>}
                    {m.commissionRate > 0 && <Badge tone="slate">{Math.round(m.commissionRate * 100)}% comissão</Badge>}
                  </div>
                </div>
                <div className="flex flex-col gap-1">
                  {wa && <a href={wa} target="_blank" rel="noreferrer" aria-label={`WhatsApp de ${m.name}`} className="icon-btn text-primary hover:bg-primary-50"><MessageCircle className="h-4 w-4" /></a>}
                  {canManage && <button type="button" aria-label={`Editar ${m.name}`} className="icon-btn text-slate-400 hover:bg-primary-50 hover:text-primary" onClick={() => { setEditing(m); setOpen(true); }}><Pencil className="h-4 w-4" /></button>}
                </div>
              </li>
            );
          })}
        </ul>
      )}
      <StaffForm open={open} onClose={() => setOpen(false)} member={editing} />
    </>
  );
}
