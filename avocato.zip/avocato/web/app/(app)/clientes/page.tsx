"use client";

import { Suspense, useEffect, useState } from "react";
import Link from "next/link";
import { useSearchParams } from "next/navigation";
import { useSWRConfig } from "swr";
import { CalendarPlus, ClipboardPlus, MessageCircle, Pencil, Plus, Search, Trash2, Users } from "lucide-react";
import UserAvatar from "@/components/avatar/UserAvatar";
import Modal from "@/components/ui/Modal";
import { SelectField, TextArea, TextField } from "@/components/ui/fields";
import { Badge, EmptyState, ErrorBox, ListSkeleton, PageHeader, Segmented, Spinner } from "@/components/ui/misc";
import { useToast } from "@/components/ui/toast";
import { api, ApiError } from "@/lib/api";
import { brl, dateBR, orderNumber, relative, whatsappLink } from "@/lib/format";
import { invalidate, useApi } from "@/lib/hooks";
import { useSession } from "@/lib/session";
import type { Customer, ServiceOrder } from "@/lib/types";
import { STATUS_META } from "@/lib/orders";

type Filter = "all" | "active" | "gone";

function CustomerForm({ open, onClose, customer }: { open: boolean; onClose: () => void; customer: Customer | null }) {
  const toast = useToast();
  const { mutate } = useSWRConfig();
  const [form, setForm] = useState({ name: "", phone: "", email: "", document: "", kind: "person", tags: "", notes: "", city: "", district: "", street: "" });
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    if (!open) return;
    setErrors({});
    setForm({
      name: customer?.name ?? "", phone: customer?.phone ?? "", email: customer?.email ?? "", document: customer?.document ?? "",
      kind: customer?.kind ?? "person", tags: customer?.tags.join(", ") ?? "", notes: customer?.notes ?? "",
      city: customer?.address.city ?? "", district: customer?.address.district ?? "", street: customer?.address.street ?? "",
    });
  }, [open, customer]);

  const set = (k: keyof typeof form) => (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => setForm((f) => ({ ...f, [k]: e.target.value }));

  async function save(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true);
    const address = Object.fromEntries(Object.entries({ city: form.city, district: form.district, street: form.street }).filter(([, v]) => v.trim()));
    const body = {
      name: form.name.trim(), phone: form.phone.trim() || null, email: form.email.trim() || null, document: form.document.trim() || null,
      kind: form.kind, notes: form.notes.trim() || null, address,
      tags: form.tags.split(",").map((t) => t.trim()).filter(Boolean),
    };
    try {
      await api(customer ? `/customers/${customer.id}` : "/customers", { method: customer ? "PATCH" : "POST", body });
      await invalidate(mutate, "/customers", "/dashboard");
      toast(customer ? "Cadastro atualizado." : "Cadastrado com sucesso.");
      onClose();
    } catch (err) {
      if (err instanceof ApiError) {
        setErrors(err.fieldErrors());
        if (!Object.keys(err.fieldErrors()).length) toast(err.message, "error");
      }
    } finally {
      setBusy(false);
    }
  }

  return (
    <Modal open={open} onClose={onClose} title={customer ? "Editar cadastro" : "Novo cadastro"} size="lg"
      footer={<><button type="button" className="btn btn-ghost" onClick={onClose}>Cancelar</button>
        <button type="submit" form="customer-form" className="btn btn-primary" disabled={busy}>{busy && <Spinner />} Salvar</button></>}>
      <form id="customer-form" onSubmit={save} className="grid gap-4 sm:grid-cols-2">
        <TextField className="sm:col-span-2" label="Nome" required value={form.name} onChange={set("name")} error={errors.name} />
        <TextField label="Telefone / WhatsApp" type="tel" value={form.phone} onChange={set("phone")} error={errors.phone} placeholder="(21) 99999-0000" />
        <TextField label="E-mail" type="email" value={form.email} onChange={set("email")} error={errors.email} />
        <SelectField label="Tipo" value={form.kind} onChange={set("kind")} options={[{ value: "person", label: "Pessoa física" }, { value: "company", label: "Empresa" }]} />
        <TextField label={form.kind === "company" ? "CNPJ" : "CPF"} value={form.document} onChange={set("document")} error={errors.document} />
        <TextField label="Rua e número" value={form.street} onChange={set("street")} />
        <TextField label="Bairro" value={form.district} onChange={set("district")} />
        <TextField label="Cidade" value={form.city} onChange={set("city")} />
        <TextField label="Etiquetas" value={form.tags} onChange={set("tags")} hint="Separe por vírgula: vip, indicação" />
        <TextArea className="sm:col-span-2" label="Observações" value={form.notes} onChange={set("notes")} />
      </form>
    </Modal>
  );
}

function CustomerDetail({ customer, onClose, onEdit }: { customer: Customer | null; onClose: () => void; onEdit: (c: Customer) => void }) {
  const { can, hasModule } = useSession();
  const toast = useToast();
  const { mutate } = useSWRConfig();
  const { data: orders } = useApi<{ data: ServiceOrder[] }>(customer && hasModule("service_orders") ? `/service-orders?customerId=${customer.id}&limit=20` : null);
  const [confirm, setConfirm] = useState(false);
  if (!customer) return null;
  const wa = whatsappLink(customer.phone, `Olá, ${customer.name.split(" ")[0]}!`);
  const spent = orders?.data.filter((o) => o.status === "done").reduce((a, o) => a + o.totalCents, 0) ?? 0;

  async function remove() {
    try {
      await api(`/customers/${customer!.id}`, { method: "DELETE" });
      await invalidate(mutate, "/customers", "/dashboard");
      toast("Cadastro removido.");
      onClose();
    } catch (err) {
      toast(err instanceof ApiError ? err.message : "Não foi possível remover.", "error");
    }
  }

  return (
    <Modal open onClose={onClose} title={customer.name} description={[customer.phone, customer.email].filter(Boolean).join(" · ") || undefined} size="lg">
      <div className="flex flex-wrap gap-2">
        {wa && <a href={wa} target="_blank" rel="noreferrer" className="btn btn-soft btn-sm"><MessageCircle className="h-4 w-4" /> WhatsApp</a>}
        {hasModule("service_orders") && can("service_orders.create") && (
          <Link href={`/ordens?nova=1&cliente=${customer.id}`} className="btn btn-outline btn-sm"><ClipboardPlus className="h-4 w-4" /> Nova OS</Link>
        )}
        {hasModule("appointments") && can("appointments.create") && (
          <Link href={`/agenda?novo=1&cliente=${customer.id}`} className="btn btn-outline btn-sm"><CalendarPlus className="h-4 w-4" /> Agendar</Link>
        )}
        {can("customers.update") && <button type="button" className="btn btn-outline btn-sm" onClick={() => onEdit(customer)}><Pencil className="h-4 w-4" /> Editar</button>}
      </div>

      <dl className="mt-5 grid grid-cols-2 gap-3 sm:grid-cols-4">
        {[
          ["Cliente desde", dateBR(customer.createdAt)],
          ["Última compra", customer.lastPurchaseAt ? relative(customer.lastPurchaseAt) : "—"],
          ["Total em serviços", brl(spent)],
          ["Origem", customer.source ?? "Cadastro manual"],
        ].map(([k, v]) => (
          <div key={k} className="rounded-xl bg-slate-50 p-3">
            <dt className="text-xs text-slate-500">{k}</dt>
            <dd className="mt-0.5 text-sm font-medium text-slate-800">{v}</dd>
          </div>
        ))}
      </dl>

      {customer.tags.length > 0 && <div className="mt-4 flex flex-wrap gap-1.5">{customer.tags.map((t) => <Badge key={t} tone="teal">{t}</Badge>)}</div>}
      {customer.notes && <p className="mt-4 whitespace-pre-line rounded-xl bg-amber-50/60 p-3 text-sm text-slate-700">{customer.notes}</p>}

      {hasModule("service_orders") && (
        <>
          <h3 className="mb-2 mt-6 text-sm font-semibold text-slate-700">Histórico de serviços</h3>
          {!orders ? <ListSkeleton rows={2} /> : orders.data.length === 0 ? (
            <p className="rounded-xl bg-slate-50 p-4 text-sm text-slate-500">Nenhuma OS ainda.</p>
          ) : (
            <ul className="divide-y divide-slate-100 rounded-xl ring-1 ring-slate-100">
              {orders.data.map((o) => (
                <li key={o.id}>
                  <Link href={`/ordens?id=${o.id}`} className="flex items-center justify-between gap-3 px-4 py-3 text-sm hover:bg-slate-50">
                    <span className="min-w-0">
                      <span className="font-medium text-slate-800">{orderNumber(o.number)}</span>{" "}
                      <span className="text-slate-600">{o.title}</span>
                      <span className="block text-xs text-slate-400">{dateBR(o.createdAt)}</span>
                    </span>
                    <span className="flex items-center gap-2">
                      <span className="font-medium text-slate-700">{brl(o.totalCents)}</span>
                      <Badge tone={STATUS_META[o.status].tone}>{STATUS_META[o.status].label}</Badge>
                    </span>
                  </Link>
                </li>
              ))}
            </ul>
          )}
        </>
      )}

      {can("customers.delete") && (
        <div className="mt-6 border-t border-slate-100 pt-4">
          {confirm ? (
            <div className="flex flex-wrap items-center gap-2 rounded-xl bg-rose-50 p-3 text-sm text-rose-700">
              Remover {customer.name}? O histórico continua guardado.
              <button type="button" className="btn btn-danger btn-sm ml-auto" onClick={remove}>Remover {customer.name.split(" ")[0]}</button>
              <button type="button" className="btn btn-ghost btn-sm" onClick={() => setConfirm(false)}>Manter</button>
            </div>
          ) : (
            <button type="button" className="btn btn-danger-soft btn-sm" onClick={() => setConfirm(true)}><Trash2 className="h-4 w-4" /> Remover cadastro</button>
          )}
        </div>
      )}
    </Modal>
  );
}

function ClientesView() {
  const params = useSearchParams();
  const { term, can } = useSession();
  const [q, setQ] = useState(params.get("q") ?? "");
  const [debounced, setDebounced] = useState(q);
  const [filter, setFilter] = useState<Filter>("all");
  const [limit, setLimit] = useState(25);
  const [editing, setEditing] = useState<Customer | null>(null);
  const [formOpen, setFormOpen] = useState(false);
  const [detail, setDetail] = useState<Customer | null>(null);

  useEffect(() => { const t = setTimeout(() => setDebounced(q), 250); return () => clearTimeout(t); }, [q]);
  useEffect(() => { setQ(params.get("q") ?? ""); }, [params]);

  const qs = new URLSearchParams({ limit: String(limit) });
  if (debounced.trim()) qs.set("q", debounced.trim());
  if (filter === "active") qs.set("status", "active");
  if (filter === "gone") qs.set("inactiveDays", "60");
  const { data, error, isLoading, mutate } = useApi<{ data: Customer[]; total: number }>(`/customers?${qs}`);
  const label = term("customers", "Clientes");

  return (
    <>
      <PageHeader title={label} description="Quem compra de você, com histórico e contato a um clique."
        actions={can("customers.create") && (
          <button type="button" className="btn btn-primary" onClick={() => { setEditing(null); setFormOpen(true); }}><Plus className="h-4 w-4" /> Novo cadastro</button>
        )} />

      <div className="card">
        <div className="flex flex-wrap items-center gap-3 border-b border-slate-100 p-4">
          <div className="relative min-w-[220px] flex-1">
            <Search className="pointer-events-none absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
            <input className="input pl-10" type="search" value={q} onChange={(e) => setQ(e.target.value)} placeholder="Buscar por nome, telefone, e-mail ou documento" aria-label="Buscar" />
          </div>
          <Segmented label="Filtro" value={filter} onChange={setFilter}
            options={[{ value: "all", label: "Todos" }, { value: "active", label: "Ativos" }, { value: "gone", label: "Sumidos há 60 dias" }]} />
        </div>

        {error && <ErrorBox message={error.message} onRetry={() => mutate()} />}
        {isLoading && !data && <ListSkeleton />}
        {data && data.data.length === 0 && (
          <EmptyState icon={Users} title={debounced || filter !== "all" ? "Ninguém encontrado" : `Nenhum cadastro em ${label.toLowerCase()} ainda`}
            description={filter === "gone" ? "Ótimo sinal: todo mundo comprou nos últimos 60 dias." : "Cadastre manualmente ou receba pedidos pelo seu link público."}
            action={can("customers.create") && !debounced && filter === "all" && (
              <button type="button" className="btn btn-primary" onClick={() => { setEditing(null); setFormOpen(true); }}><Plus className="h-4 w-4" /> Novo cadastro</button>
            )} />
        )}

        {data && data.data.length > 0 && (
          <>
            <ul className="divide-y divide-slate-100">
              {data.data.map((c) => {
                const wa = whatsappLink(c.phone);
                return (
                  <li key={c.id} className="flex items-center gap-3 px-4 py-3 hover:bg-slate-50/70">
                    <button type="button" onClick={() => setDetail(c)} className="flex min-w-0 flex-1 items-center gap-3 text-left">
                      <UserAvatar name={c.name} size={40} />
                      <span className="min-w-0">
                        <span className="block truncate text-sm font-medium text-slate-800">{c.name}</span>
                        <span className="block truncate text-xs text-slate-500">{[c.phone, c.email].filter(Boolean).join(" · ") || "Sem contato"}</span>
                      </span>
                    </button>
                    <div className="hidden flex-wrap gap-1 md:flex">{c.tags.slice(0, 3).map((t) => <Badge key={t} tone="teal">{t}</Badge>)}</div>
                    <span className="hidden w-32 text-right text-xs text-slate-500 sm:block">
                      {c.lastPurchaseAt ? `Comprou ${relative(c.lastPurchaseAt)}` : "Sem compras"}
                    </span>
                    {c.status !== "active" && <Badge tone={c.status === "blocked" ? "rose" : "slate"}>{c.status === "blocked" ? "Bloqueado" : "Inativo"}</Badge>}
                    {wa && (
                      <a href={wa} target="_blank" rel="noreferrer" aria-label={`WhatsApp de ${c.name}`} className="icon-btn text-primary hover:bg-primary-50">
                        <MessageCircle className="h-[18px] w-[18px]" />
                      </a>
                    )}
                  </li>
                );
              })}
            </ul>
            <div className="flex items-center justify-between border-t border-slate-100 px-4 py-3 text-sm text-slate-500">
              <span>{data.data.length} de {data.total}</span>
              {data.total > data.data.length && <button type="button" className="btn btn-outline btn-sm" onClick={() => setLimit((l) => Math.min(l + 25, 100))}>Carregar mais</button>}
            </div>
          </>
        )}
      </div>

      <CustomerForm open={formOpen} onClose={() => setFormOpen(false)} customer={editing} />
      <CustomerDetail customer={detail} onClose={() => setDetail(null)} onEdit={(c) => { setDetail(null); setEditing(c); setFormOpen(true); }} />
    </>
  );
}

export default function ClientesPage() {
  return <Suspense><ClientesView /></Suspense>;
}
