"use client";

import { Suspense, useEffect, useMemo, useState } from "react";
import { usePathname, useRouter, useSearchParams } from "next/navigation";
import clsx from "clsx";
import { useSWRConfig } from "swr";
import { CalendarDays, ChevronLeft, ChevronRight, MessageCircle, Plus } from "lucide-react";
import CustomerPicker from "@/components/forms/CustomerPicker";
import Modal from "@/components/ui/Modal";
import { MoneyField, SelectField, TextArea, TextField } from "@/components/ui/fields";
import { Badge, ErrorBox, PageHeader, Spinner } from "@/components/ui/misc";
import { useToast } from "@/components/ui/toast";
import { api, ApiError } from "@/lib/api";
import { brl, timeBR, whatsappLink } from "@/lib/format";
import { invalidate, useApi } from "@/lib/hooks";
import { APPOINTMENT_META } from "@/lib/orders";
import { useSession } from "@/lib/session";
import type { Appointment, AppointmentStatus, Customer, Service, StaffMember } from "@/lib/types";

const DAY = 864e5;
const startOfWeek = (d: Date) => { const x = new Date(d); x.setHours(0, 0, 0, 0); x.setDate(x.getDate() - ((x.getDay() + 6) % 7)); return x; };
const ymd = (d: Date) => `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
const sameDay = (a: Date, b: Date) => ymd(a) === ymd(b);

function AppointmentForm({ open, onClose, appointment, initialCustomer, initialDate }: {
  open: boolean; onClose: () => void; appointment: Appointment | null;
  initialCustomer: { id: string; name: string; phone?: string | null } | null; initialDate: string;
}) {
  const toast = useToast();
  const { mutate } = useSWRConfig();
  const { data: services } = useApi<{ data: Service[] }>(open ? "/services" : null);
  const { data: staff } = useApi<{ data: StaffMember[] }>(open ? "/staff" : null);
  const [customer, setCustomer] = useState<{ id: string; name: string; phone?: string | null } | null>(null);
  const [serviceId, setServiceId] = useState("");
  const [staffId, setStaffId] = useState("");
  const [date, setDate] = useState("");
  const [time, setTime] = useState("09:00");
  const [duration, setDuration] = useState("60");
  const [price, setPrice] = useState<number | null>(null);
  const [notes, setNotes] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!open) return;
    setError(null);
    if (appointment) {
      const s = new Date(appointment.startsAt);
      setCustomer({ id: appointment.customer.id, name: appointment.customer.name, phone: appointment.customer.phone });
      setServiceId(appointment.service?.id ?? ""); setStaffId(appointment.staff?.id ?? "");
      setDate(ymd(s)); setTime(timeBR(appointment.startsAt));
      setDuration(String(Math.round((new Date(appointment.endsAt).getTime() - s.getTime()) / 60000)));
      setPrice(appointment.priceCents); setNotes(appointment.notes ?? "");
    } else {
      setCustomer(initialCustomer); setServiceId(""); setStaffId(""); setDate(initialDate); setTime("09:00"); setDuration("60"); setPrice(null); setNotes("");
    }
  }, [open, appointment, initialCustomer, initialDate]);

  function pickService(id: string) {
    setServiceId(id);
    const s = services?.data.find((x) => x.id === id);
    if (s?.durationMinutes) setDuration(String(s.durationMinutes));
    if (s) setPrice(s.priceCents);
  }

  async function save(e: React.FormEvent) {
    e.preventDefault();
    if (!customer) { setError("Escolha quem vai ser atendido."); return; }
    setBusy(true);
    setError(null);
    const startsAt = new Date(`${date}T${time}:00`).toISOString();
    const body = { customerId: customer.id, serviceId: serviceId || null, staffId: staffId || null, startsAt, durationMinutes: Number(duration) || 60, priceCents: price, notes: notes.trim() || null };
    try {
      await api(appointment ? `/appointments/${appointment.id}` : "/appointments", { method: appointment ? "PATCH" : "POST", body });
      await invalidate(mutate, "/appointments", "/dashboard");
      toast(appointment ? "Agendamento atualizado." : "Agendado!");
      onClose();
    } catch (err) {
      setError(err instanceof ApiError ? (err.code === "schedule_conflict" ? "Esse profissional já tem um atendimento nesse horário. Escolha outro horário ou outra pessoa." : err.message) : "Não foi possível salvar.");
    } finally {
      setBusy(false);
    }
  }

  return (
    <Modal open={open} onClose={onClose} title={appointment ? "Reagendar" : "Novo agendamento"} size="lg"
      footer={<><button type="button" className="btn btn-ghost" onClick={onClose}>Cancelar</button>
        <button type="submit" form="appt-form" className="btn btn-primary" disabled={busy}>{busy && <Spinner />} Salvar</button></>}>
      <form id="appt-form" onSubmit={save} className="grid gap-4 sm:grid-cols-2">
        <div className="sm:col-span-2"><CustomerPicker value={customer} onChange={setCustomer} required /></div>
        <SelectField label="Serviço" value={serviceId} onChange={(e) => pickService(e.target.value)} placeholder="Sem serviço específico"
          options={(services?.data ?? []).filter((s) => s.isActive).map((s) => ({ value: s.id, label: `${s.name}${s.durationMinutes ? ` · ${s.durationMinutes} min` : ""}` }))} />
        <SelectField label="Profissional" value={staffId} onChange={(e) => setStaffId(e.target.value)} placeholder="Qualquer um"
          options={(staff?.data ?? []).map((s) => ({ value: s.id, label: s.name }))} />
        <TextField label="Dia" type="date" required value={date} onChange={(e) => setDate(e.target.value)} />
        <div className="grid grid-cols-2 gap-3">
          <TextField label="Hora" type="time" required value={time} onChange={(e) => setTime(e.target.value)} />
          <TextField label="Duração (min)" type="number" min={5} step={5} value={duration} onChange={(e) => setDuration(e.target.value)} />
        </div>
        <MoneyField label="Valor" value={price} onChange={setPrice} hint="Ao concluir, vira conta a receber." />
        <TextArea className="sm:col-span-2" label="Observações" value={notes} onChange={(e) => setNotes(e.target.value)} />
        {error && <p role="alert" className="rounded-xl bg-rose-50 px-3 py-2.5 text-sm text-rose-700 sm:col-span-2">{error}</p>}
      </form>
    </Modal>
  );
}

function AppointmentDetail({ a, onClose, onReschedule }: { a: Appointment | null; onClose: () => void; onReschedule: (a: Appointment) => void }) {
  const { can, context } = useSession();
  const toast = useToast();
  const { mutate } = useSWRConfig();
  const [busy, setBusy] = useState<string | null>(null);
  if (!a) return null;

  const setStatus = async (status: AppointmentStatus, msg: string) => {
    setBusy(status);
    try {
      await api(`/appointments/${a.id}`, { method: "PATCH", body: { status } });
      await invalidate(mutate, "/appointments", "/dashboard", "/finance");
      toast(msg);
      onClose();
    } catch (err) {
      toast(err instanceof ApiError ? err.message : "Algo deu errado.", "error");
    } finally {
      setBusy(null);
    }
  };

  const when = new Date(a.startsAt).toLocaleString("pt-BR", { weekday: "long", day: "numeric", month: "long", hour: "2-digit", minute: "2-digit" });
  const wa = whatsappLink(a.customer.phone, `Olá, ${a.customer.name.split(" ")[0]}! Passando para lembrar do seu horário na ${context?.organization.name}: ${when}. Podemos confirmar?`);
  const open = a.status === "scheduled" || a.status === "confirmed" || a.status === "in_progress";

  return (
    <Modal open onClose={onClose} title={a.customer.name} description={when}>
      <div className="space-y-4">
        <div className="flex flex-wrap gap-2">
          <Badge tone={APPOINTMENT_META[a.status].tone}>{APPOINTMENT_META[a.status].label}</Badge>
          {a.service && <Badge tone="slate">{a.service.name}</Badge>}
          {a.staff && <Badge tone="teal">{a.staff.name}</Badge>}
          {a.priceCents != null && <Badge tone="green">{brl(a.priceCents)}</Badge>}
        </div>
        <p className="text-sm text-slate-600">{timeBR(a.startsAt)} – {timeBR(a.endsAt)}</p>
        {a.notes && <p className="whitespace-pre-line rounded-xl bg-amber-50/60 p-3 text-sm text-slate-700">{a.notes}</p>}
        {wa && open && <a href={wa} target="_blank" rel="noreferrer" className="btn btn-soft btn-sm"><MessageCircle className="h-4 w-4" /> Lembrar pelo WhatsApp</a>}
        {can("appointments.update") && open && (
          <div className="flex flex-wrap gap-2 border-t border-slate-100 pt-4">
            {a.status === "scheduled" && <button type="button" className="btn btn-outline btn-sm" disabled={!!busy} onClick={() => setStatus("confirmed", "Confirmado.")}>{busy === "confirmed" && <Spinner />} Confirmar</button>}
            <button type="button" className="btn btn-primary btn-sm" disabled={!!busy} onClick={() => setStatus("done", a.priceCents ? "Concluído! Valor lançado em contas a receber." : "Concluído.")}>{busy === "done" && <Spinner />} Concluir atendimento</button>
            <button type="button" className="btn btn-outline btn-sm" onClick={() => onReschedule(a)}>Reagendar</button>
            <button type="button" className="btn btn-ghost btn-sm" disabled={!!busy} onClick={() => setStatus("no_show", "Marcado como falta.")}>Faltou</button>
            <button type="button" className="btn btn-danger-soft btn-sm" disabled={!!busy} onClick={() => setStatus("canceled", "Agendamento cancelado.")}>Cancelar</button>
          </div>
        )}
      </div>
    </Modal>
  );
}

function AgendaView() {
  const params = useSearchParams();
  const router = useRouter();
  const pathname = usePathname();
  const { can } = useSession();
  const [week, setWeek] = useState(() => startOfWeek(new Date()));
  const [staffFilter, setStaffFilter] = useState("");
  const [formOpen, setFormOpen] = useState(false);
  const [editing, setEditing] = useState<Appointment | null>(null);
  const [detail, setDetail] = useState<Appointment | null>(null);
  const [initialCustomer, setInitialCustomer] = useState<{ id: string; name: string; phone?: string | null } | null>(null);
  const [initialDate, setInitialDate] = useState(ymd(new Date()));

  useEffect(() => {
    if (!params.get("novo")) return;
    const cid = params.get("cliente");
    if (cid) api<Customer>(`/customers/${cid}`).then((c) => setInitialCustomer({ id: c.id, name: c.name, phone: c.phone })).catch(() => undefined);
    setEditing(null); setInitialDate(ymd(new Date())); setFormOpen(true);
    router.replace(pathname);
  }, [params, router, pathname]);

  const from = week.toISOString();
  const to = new Date(week.getTime() + 7 * DAY).toISOString();
  const { data, error, mutate } = useApi<{ data: Appointment[] }>(`/appointments?from=${encodeURIComponent(from)}&to=${encodeURIComponent(to)}${staffFilter ? `&staffId=${staffFilter}` : ""}`);
  const { data: staff } = useApi<{ data: StaffMember[] }>("/staff");
  const days = useMemo(() => Array.from({ length: 7 }, (_, i) => new Date(week.getTime() + i * DAY)), [week]);
  const today = new Date();
  const label = `${days[0]!.toLocaleDateString("pt-BR", { day: "numeric", month: "short" })} – ${days[6]!.toLocaleDateString("pt-BR", { day: "numeric", month: "short", year: "numeric" })}`;
  const newAt = (d: Date) => { setEditing(null); setInitialCustomer(null); setInitialDate(ymd(d)); setFormOpen(true); };

  return (
    <>
      <PageHeader title="Agenda" description="Horários da equipe, sem conflito e com lembrete no WhatsApp."
        actions={can("appointments.create") && <button type="button" className="btn btn-primary" onClick={() => newAt(today)}><Plus className="h-4 w-4" /> Agendar</button>} />

      <div className="mb-4 flex flex-wrap items-center gap-2">
        <div className="flex items-center gap-1 rounded-xl bg-white p-1 shadow-card">
          <button type="button" aria-label="Semana anterior" className="icon-btn text-slate-500 hover:bg-slate-100" onClick={() => setWeek(new Date(week.getTime() - 7 * DAY))}><ChevronLeft className="h-4 w-4" /></button>
          <button type="button" className="btn btn-ghost btn-sm" onClick={() => setWeek(startOfWeek(new Date()))}>Hoje</button>
          <button type="button" aria-label="Próxima semana" className="icon-btn text-slate-500 hover:bg-slate-100" onClick={() => setWeek(new Date(week.getTime() + 7 * DAY))}><ChevronRight className="h-4 w-4" /></button>
        </div>
        <p className="px-2 text-sm font-medium text-slate-700" aria-live="polite">{label}</p>
        <select aria-label="Filtrar por profissional" className="input ml-auto h-10 w-auto min-w-[180px]" value={staffFilter} onChange={(e) => setStaffFilter(e.target.value)}>
          <option value="">Toda a equipe</option>
          {staff?.data.map((s) => <option key={s.id} value={s.id}>{s.name}</option>)}
        </select>
      </div>

      {error && <ErrorBox message={error.message} onRetry={() => mutate()} />}
      <div className="grid gap-3 md:grid-cols-7">
        {days.map((d) => {
          const list = (data?.data ?? []).filter((a) => sameDay(new Date(a.startsAt), d));
          const isToday = sameDay(d, today);
          return (
            <section key={d.toISOString()} aria-label={d.toLocaleDateString("pt-BR", { weekday: "long", day: "numeric" })}
              className={clsx("card flex min-h-[140px] flex-col p-2.5 md:min-h-[420px]", isToday && "ring-2 ring-primary")}>
              <header className="mb-2 flex items-center justify-between px-1">
                <div>
                  <p className="text-[11px] uppercase tracking-wide text-slate-400">{d.toLocaleDateString("pt-BR", { weekday: "short" }).replace(".", "")}</p>
                  <p className={clsx("text-lg font-semibold leading-tight", isToday ? "text-primary" : "text-slate-700")}>{d.getDate()}</p>
                </div>
                {can("appointments.create") && (
                  <button type="button" aria-label={`Agendar em ${d.toLocaleDateString("pt-BR")}`} onClick={() => newAt(d)} className="icon-btn h-7 w-7 text-slate-400 hover:bg-primary-50 hover:text-primary">
                    <Plus className="h-4 w-4" />
                  </button>
                )}
              </header>
              <ul className="flex-1 space-y-1.5">
                {!data && <li className="h-10 animate-pulse rounded-lg bg-slate-100" />}
                {list.map((a) => (
                  <li key={a.id}>
                    <button type="button" onClick={() => setDetail(a)}
                      className={clsx("w-full rounded-lg border-l-[3px] bg-slate-50 px-2 py-1.5 text-left transition-colors hover:bg-primary-50",
                        a.status === "done" ? "border-primary" : a.status === "canceled" || a.status === "no_show" ? "border-slate-300 opacity-60" : a.status === "confirmed" ? "border-teal-500" : "border-sky-400")}>
                      <span className="block text-xs font-semibold text-slate-700">{timeBR(a.startsAt)}</span>
                      <span className="block truncate text-xs text-slate-700">{a.customer.name}</span>
                      {(a.service || a.staff) && <span className="block truncate text-[11px] text-slate-500">{[a.service?.name, a.staff?.name].filter(Boolean).join(" · ")}</span>}
                    </button>
                  </li>
                ))}
                {data && list.length === 0 && <li className="hidden px-1 pt-2 text-xs text-slate-300 md:block">Livre</li>}
              </ul>
            </section>
          );
        })}
      </div>
      {data && data.data.length === 0 && (
        <p className="mt-4 flex items-center justify-center gap-2 text-sm text-slate-500"><CalendarDays className="h-4 w-4" /> Semana livre. Clique em + num dia para agendar.</p>
      )}

      <AppointmentForm open={formOpen} onClose={() => setFormOpen(false)} appointment={editing} initialCustomer={initialCustomer} initialDate={initialDate} />
      <AppointmentDetail a={detail} onClose={() => setDetail(null)} onReschedule={(a) => { setDetail(null); setEditing(a); setFormOpen(true); }} />
    </>
  );
}

export default function AgendaPage() {
  return <Suspense><AgendaView /></Suspense>;
}
