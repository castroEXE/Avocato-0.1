"use client";

import { useEffect, useRef, useState } from "react";
import clsx from "clsx";
import { useSWRConfig } from "swr";
import { Bot, Check, CheckCircle2, Clock3, KeyRound, MessageSquarePlus, Send, ShieldAlert, X, XCircle } from "lucide-react";
import AvocadoMark from "@/components/brand/AvocadoMark";
import UserAvatar from "@/components/avatar/UserAvatar";
import { PageHeader, Spinner } from "@/components/ui/misc";
import { useToast } from "@/components/ui/toast";
import { api, ApiError } from "@/lib/api";
import { relative } from "@/lib/format";
import { invalidate, useApi } from "@/lib/hooks";
import { useSession } from "@/lib/session";

type Action = { tool: string; status: "executed" | "awaiting_approval" | "failed" | "denied"; actionId?: string; summary?: string; error?: string };
type Msg = { id: string; role: "user" | "assistant"; text: string; actions?: Action[]; pending?: boolean };
type PendingAction = { id: string; toolName: string; summary: string; status: string; createdAt: string };

const TOOL_LABEL: Record<string, string> = {
  search_customers: "Buscou clientes", create_customer: "Cadastrou cliente", delete_customer: "Remover cliente",
  list_services: "Consultou serviços", create_service: "Cadastrou serviço", list_staff: "Consultou equipe",
  create_service_order: "Abriu OS", list_service_orders: "Consultou OS", update_service_order_status: "Mudou status da OS",
  cancel_service_order: "Cancelar OS", create_appointment: "Agendou", list_appointments: "Consultou agenda",
  create_financial_entry: "Lançou no financeiro", list_financial_entries: "Consultou financeiro", mark_entry_paid: "Dar baixa",
  business_summary: "Gerou resumo",
};

const SUGGESTIONS = [
  "Como está meu mês? Faça um resumo do negócio.",
  "Quais contas estão vencidas?",
  "O que tenho agendado para amanhã?",
  "Cadastre o cliente João Silva, telefone 21 99999-1234",
  "Lance o aluguel de R$ 1.500 todo dia 5, como conta fixa",
];

function ActionChip({ a, onDecide }: { a: Action; onDecide: (id: string, approve: boolean) => Promise<void> }) {
  const [busy, setBusy] = useState(false);
  const [done, setDone] = useState<null | "approved" | "rejected">(null);
  const label = TOOL_LABEL[a.tool] ?? a.tool;
  if (a.status === "awaiting_approval" && a.actionId) {
    return (
      <div className="rounded-xl bg-amber-50 p-3 text-sm ring-1 ring-amber-100">
        <p className="flex items-center gap-1.5 font-medium text-amber-900"><ShieldAlert className="h-4 w-4" /> Precisa da sua aprovação</p>
        <p className="mt-0.5 text-amber-800">{a.summary ?? label}</p>
        {done ? (
          <p className="mt-2 text-xs font-medium text-slate-600">{done === "approved" ? "Aprovado e executado ✓" : "Recusado"}</p>
        ) : (
          <div className="mt-2 flex gap-2">
            <button type="button" disabled={busy} className="btn btn-primary btn-sm"
              onClick={async () => { setBusy(true); await onDecide(a.actionId!, true).then(() => setDone("approved")).finally(() => setBusy(false)); }}>
              {busy ? <Spinner /> : <Check className="h-4 w-4" />} Aprovar
            </button>
            <button type="button" disabled={busy} className="btn btn-outline btn-sm"
              onClick={async () => { setBusy(true); await onDecide(a.actionId!, false).then(() => setDone("rejected")).finally(() => setBusy(false)); }}>
              <X className="h-4 w-4" /> Recusar
            </button>
          </div>
        )}
      </div>
    );
  }
  const ok = a.status === "executed";
  return (
    <span className={clsx("inline-flex items-center gap-1 rounded-full px-2.5 py-1 text-xs", ok ? "bg-primary-50 text-primary-dark" : "bg-rose-50 text-rose-700")}
      title={a.error}>
      {ok ? <CheckCircle2 className="h-3.5 w-3.5" /> : <XCircle className="h-3.5 w-3.5" />} {label}{!ok && a.error ? `: ${a.error}` : ""}
    </span>
  );
}

export default function AssistentePage() {
  const { me } = useSession();
  const toast = useToast();
  const { mutate } = useSWRConfig();
  const { data: status } = useApi<{ configured: boolean; provider: string | null; model: string | null }>("/ai/status");
  const { data: convs, mutate: reloadConvs } = useApi<{ data: { id: string; title: string; updatedAt: string }[] }>("/ai/conversations");
  const { data: pending, mutate: reloadPending } = useApi<{ data: PendingAction[] }>("/ai/actions?status=awaiting_approval");
  const [conversationId, setConversationId] = useState<string | null>(null);
  const [messages, setMessages] = useState<Msg[]>([]);
  const [input, setInput] = useState("");
  const [sending, setSending] = useState(false);
  const endRef = useRef<HTMLDivElement>(null);
  const name = me?.user.fullName || "Você";

  useEffect(() => { endRef.current?.scrollIntoView({ behavior: "smooth", block: "end" }); }, [messages]);

  async function openConversation(id: string) {
    setConversationId(id);
    const r = await api<{ data: Msg[] }>(`/ai/conversations/${id}`);
    setMessages(r.data);
  }

  async function send(text: string) {
    const message = text.trim();
    if (!message || sending) return;
    setInput("");
    setSending(true);
    setMessages((m) => [...m, { id: `u${Date.now()}`, role: "user", text: message }, { id: "pending", role: "assistant", text: "", pending: true }]);
    try {
      const r = await api<{ conversationId: string; reply: string; actions: Action[] }>("/ai/chat", { method: "POST", body: { message, conversationId } });
      setConversationId(r.conversationId);
      setMessages((m) => [...m.filter((x) => x.id !== "pending"), { id: `a${Date.now()}`, role: "assistant", text: r.reply, actions: r.actions }]);
      reloadConvs();
      if (r.actions.some((a) => a.status === "awaiting_approval")) reloadPending();
      if (r.actions.some((a) => a.status === "executed" && !a.tool.startsWith("list_") && !a.tool.startsWith("search_") && a.tool !== "business_summary")) {
        invalidate(mutate, "/customers", "/service-orders", "/appointments", "/finance", "/services", "/dashboard");
      }
    } catch (err) {
      const msg = err instanceof ApiError ? err.message : "Não consegui responder agora.";
      setMessages((m) => [...m.filter((x) => x.id !== "pending"), { id: `e${Date.now()}`, role: "assistant", text: `⚠️ ${msg}` }]);
    } finally {
      setSending(false);
    }
  }

  async function decide(id: string, approve: boolean) {
    try {
      await api(`/ai/actions/${id}/${approve ? "approve" : "reject"}`, { method: "POST" });
      toast(approve ? "Ação aprovada e executada." : "Ação recusada.");
      reloadPending();
      invalidate(mutate, "/customers", "/service-orders", "/finance", "/dashboard");
    } catch (err) {
      toast(err instanceof ApiError ? err.message : "Não foi possível concluir.", "error");
      throw err;
    }
  }

  if (status && !status.configured) {
    return (
      <>
        <PageHeader title="Assistente IA" />
        <div className="card mx-auto max-w-2xl p-8">
          <span className="mb-4 inline-flex h-14 w-14 items-center justify-center rounded-2xl bg-primary-50 text-primary"><KeyRound className="h-7 w-7" /></span>
          <h2 className="text-lg font-semibold text-slate-800">Falta só uma chave gratuita</h2>
          <p className="mt-1 text-sm text-slate-600">O assistente usa uma IA de plano gratuito. Quem administra o servidor precisa fazer isto uma vez:</p>
          <ol className="mt-4 list-decimal space-y-2 pl-5 text-sm text-slate-700">
            <li>Criar uma conta grátis em <strong>console.groq.com</strong> (sem cartão) e gerar uma API Key.</li>
            <li>Na hospedagem da API, adicionar a variável <code className="rounded bg-slate-100 px-1">AI_API_KEY</code> com essa chave.</li>
            <li>Reiniciar a API. Pronto: esta tela vira o chat.</li>
          </ol>
          <p className="mt-4 text-xs text-slate-500">Prefere o Google Gemini? Use <code className="rounded bg-slate-100 px-1">AI_PROVIDER=gemini</code> e uma chave do Google AI Studio.</p>
        </div>
      </>
    );
  }

  return (
    <>
      <PageHeader title="Assistente IA" description="Peça em português: ele consulta e registra no sistema por você."
        actions={<button type="button" className="btn btn-outline" onClick={() => { setConversationId(null); setMessages([]); }}><MessageSquarePlus className="h-4 w-4" /> Nova conversa</button>} />

      <div className="grid gap-5 lg:grid-cols-[1fr_280px]">
        <section className="card flex h-[calc(100vh-15rem)] min-h-[480px] flex-col" aria-label="Conversa">
          <div className="flex-1 space-y-5 overflow-y-auto p-5" aria-live="polite">
            {messages.length === 0 && (
              <div className="flex h-full flex-col items-center justify-center text-center">
                <AvocadoMark size={64} />
                <h2 className="mt-3 text-lg font-semibold text-slate-800">Oi! Sou o assistente do Avocato.</h2>
                <p className="mt-1 max-w-md text-sm text-slate-500">Posso cadastrar clientes, abrir OS, agendar, lançar contas e resumir seu negócio. Experimente:</p>
                <div className="mt-5 flex max-w-xl flex-wrap justify-center gap-2">
                  {SUGGESTIONS.map((s) => (
                    <button key={s} type="button" onClick={() => send(s)} className="rounded-full bg-primary-50 px-3 py-1.5 text-sm text-primary-dark transition-colors hover:bg-primary-100">{s}</button>
                  ))}
                </div>
              </div>
            )}
            {messages.map((m) => (
              <div key={m.id} className={clsx("flex gap-3", m.role === "user" && "flex-row-reverse")}>
                {m.role === "user" ? <UserAvatar avatar={me?.user.avatar} name={name} size={34} /> : (
                  <span className="inline-flex h-[34px] w-[34px] shrink-0 items-center justify-center rounded-full bg-primary-50"><AvocadoMark size={24} /></span>
                )}
                <div className={clsx("max-w-[85%] space-y-2", m.role === "user" && "items-end text-right")}>
                  {m.pending ? (
                    <div className="inline-flex items-center gap-2 rounded-2xl bg-slate-100 px-4 py-3 text-sm text-slate-500"><Spinner /> Pensando…</div>
                  ) : (
                    <div className={clsx("inline-block whitespace-pre-line rounded-2xl px-4 py-2.5 text-left text-sm",
                      m.role === "user" ? "bg-primary text-white" : "bg-slate-100 text-slate-800")}>{m.text}</div>
                  )}
                  {m.actions && m.actions.length > 0 && (
                    <div className="flex flex-col gap-1.5 text-left">
                      <div className="flex flex-wrap gap-1.5">{m.actions.filter((a) => a.status !== "awaiting_approval").map((a, i) => <ActionChip key={i} a={a} onDecide={decide} />)}</div>
                      {m.actions.filter((a) => a.status === "awaiting_approval").map((a, i) => <ActionChip key={`p${i}`} a={a} onDecide={decide} />)}
                    </div>
                  )}
                </div>
              </div>
            ))}
            <div ref={endRef} />
          </div>
          <form onSubmit={(e) => { e.preventDefault(); send(input); }} className="flex items-end gap-2 border-t border-slate-100 p-3">
            <label htmlFor="ai-input" className="sr-only">Mensagem para o assistente</label>
            <textarea id="ai-input" rows={1} value={input} onChange={(e) => setInput(e.target.value)} disabled={!status}
              onKeyDown={(e) => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); send(input); } }}
              placeholder="Ex.: abre uma OS de instalação de tomada para a Maria amanhã às 14h"
              className="input !h-11 !min-h-[44px] max-h-40 flex-1 resize-none py-2.5" />
            <button type="submit" disabled={sending || !input.trim()} aria-label="Enviar" className="btn btn-primary h-11 w-11 px-0">
              {sending ? <Spinner /> : <Send className="h-4 w-4" />}
            </button>
          </form>
        </section>

        <aside className="space-y-5">
          {(pending?.data.length ?? 0) > 0 && (
            <section className="card p-4" aria-label="Aguardando aprovação">
              <h2 className="mb-2 flex items-center gap-1.5 text-sm font-semibold text-amber-800"><Clock3 className="h-4 w-4" /> Aguardando aprovação</h2>
              <ul className="space-y-2">
                {pending!.data.map((p) => (
                  <li key={p.id} className="rounded-xl bg-amber-50 p-2.5 text-sm">
                    <p className="text-amber-900">{p.summary}</p>
                    <div className="mt-2 flex gap-1.5">
                      <button type="button" className="btn btn-primary btn-sm" onClick={() => decide(p.id, true).catch(() => undefined)}>Aprovar</button>
                      <button type="button" className="btn btn-outline btn-sm" onClick={() => decide(p.id, false).catch(() => undefined)}>Recusar</button>
                    </div>
                  </li>
                ))}
              </ul>
            </section>
          )}
          <section className="card p-4" aria-label="Conversas anteriores">
            <h2 className="mb-2 text-sm font-semibold text-slate-700">Conversas</h2>
            {!convs?.data.length ? <p className="text-sm text-slate-400">Nenhuma ainda.</p> : (
              <ul className="space-y-0.5">
                {convs.data.map((c) => (
                  <li key={c.id}>
                    <button type="button" onClick={() => openConversation(c.id)}
                      className={clsx("w-full rounded-lg px-2.5 py-2 text-left text-sm transition-colors", c.id === conversationId ? "bg-primary-50 text-primary-dark" : "text-slate-600 hover:bg-slate-50")}>
                      <span className="block truncate">{c.title}</span>
                      <span className="text-xs text-slate-400">{relative(c.updatedAt)}</span>
                    </button>
                  </li>
                ))}
              </ul>
            )}
          </section>
          {status && <p className="flex items-center gap-1.5 px-1 text-xs text-slate-400"><Bot className="h-3.5 w-3.5" /> {status.provider} · {status.model}</p>}
        </aside>
      </div>
    </>
  );
}
