"use client";

import { useEffect, useState } from "react";
import clsx from "clsx";
import { useSWRConfig } from "swr";
import { Clock, Pencil, Plus, Search, Trash2, Wrench } from "lucide-react";
import Modal from "@/components/ui/Modal";
import { MoneyField, TextArea, TextField, Toggle } from "@/components/ui/fields";
import { Badge, EmptyState, ErrorBox, ListSkeleton, PageHeader, Segmented, Spinner } from "@/components/ui/misc";
import { useToast } from "@/components/ui/toast";
import { api, ApiError } from "@/lib/api";
import { brl } from "@/lib/format";
import { invalidate, useApi } from "@/lib/hooks";
import { useSession } from "@/lib/session";
import type { Service } from "@/lib/types";

function ServiceForm({ open, onClose, service }: { open: boolean; onClose: () => void; service: Service | null }) {
  const toast = useToast();
  const { mutate } = useSWRConfig();
  const [name, setName] = useState("");
  const [category, setCategory] = useState("");
  const [description, setDescription] = useState("");
  const [price, setPrice] = useState<number | null>(null);
  const [cost, setCost] = useState<number | null>(null);
  const [commission, setCommission] = useState("0");
  const [duration, setDuration] = useState("");
  const [active, setActive] = useState(true);
  const [busy, setBusy] = useState(false);
  const [confirmDelete, setConfirmDelete] = useState(false);
  const [errors, setErrors] = useState<Record<string, string>>({});

  useEffect(() => {
    if (!open) return;
    setName(service?.name ?? ""); setCategory(service?.category ?? ""); setDescription(service?.description ?? "");
    setPrice(service?.priceCents ?? null); setCost(service?.costCents ?? null);
    setCommission(String(Math.round((service?.commissionRate ?? 0) * 100))); setDuration(service?.durationMinutes ? String(service.durationMinutes) : "");
    setActive(service?.isActive ?? true); setErrors({}); setConfirmDelete(false);
  }, [open, service]);

  const rate = Math.min(Math.max(Number(commission) || 0, 0), 100) / 100;
  const margin = (price ?? 0) - (cost ?? 0) - Math.round((price ?? 0) * rate);
  const marginPct = price ? Math.round((margin / price) * 100) : 0;

  async function save(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true);
    const body = {
      name: name.trim(), category: category.trim() || null, description: description.trim() || null,
      priceCents: price ?? 0, costCents: cost ?? 0, commissionRate: rate,
      durationMinutes: duration ? Number(duration) : null, isActive: active,
    };
    try {
      await api(service ? `/services/${service.id}` : "/services", { method: service ? "PATCH" : "POST", body });
      await invalidate(mutate, "/services");
      toast(service ? "Serviço atualizado." : "Serviço cadastrado.");
      onClose();
    } catch (err) {
      if (err instanceof ApiError) { setErrors(err.fieldErrors()); toast(err.message, "error"); }
    } finally {
      setBusy(false);
    }
  }

  async function remove() {
    const r = await api<{ mode: "deleted" | "deactivated" }>(`/services/${service!.id}`, { method: "DELETE" });
    await invalidate(mutate, "/services");
    toast(r.mode === "deleted" ? "Serviço excluído." : "Serviço já usado em OS: foi desativado para manter o histórico.", "info");
    onClose();
  }

  return (
    <Modal open={open} onClose={onClose} title={service ? "Editar serviço" : "Novo serviço"} size="lg"
      footer={<>
        {service && (confirmDelete
          ? <button type="button" className="btn btn-danger mr-auto" onClick={remove}>Confirmar exclusão</button>
          : <button type="button" className="btn btn-danger-soft mr-auto" onClick={() => setConfirmDelete(true)}><Trash2 className="h-4 w-4" /> Excluir</button>)}
        <button type="button" className="btn btn-ghost" onClick={onClose}>Cancelar</button>
        <button type="submit" form="service-form" className="btn btn-primary" disabled={busy}>{busy && <Spinner />} Salvar serviço</button>
      </>}>
      <form id="service-form" onSubmit={save} className="grid gap-4 sm:grid-cols-2">
        <TextField className="sm:col-span-2" label="Nome do serviço" required value={name} onChange={(e) => setName(e.target.value)} error={errors.name} placeholder="Ex.: Instalação de chuveiro" />
        <MoneyField label="Preço cobrado" required value={price} onChange={setPrice} error={errors.priceCents} />
        <MoneyField label="Custo (material etc.)" value={cost} onChange={setCost} hint="Opcional, para calcular a margem." />
        <TextField label="Comissão do profissional (%)" type="number" min={0} max={100} value={commission} onChange={(e) => setCommission(e.target.value)} />
        <TextField label="Duração (minutos)" type="number" min={5} step={5} value={duration} onChange={(e) => setDuration(e.target.value)} hint="Usada para montar a agenda." />
        <TextField label="Categoria" value={category} onChange={(e) => setCategory(e.target.value)} placeholder="Ex.: Elétrica" />
        <div className="flex items-end pb-2"><Toggle checked={active} onChange={setActive} label="Ativo" description="Aparece no link público e nas OS." /></div>
        <TextArea className="sm:col-span-2" label="Descrição" value={description} onChange={(e) => setDescription(e.target.value)} hint="Aparece para o cliente no link de pedidos." />
        <div className={clsx("rounded-2xl p-4 sm:col-span-2", margin >= 0 ? "bg-primary-50" : "bg-rose-50")} aria-live="polite">
          <p className="text-sm text-slate-600">Sobra por serviço (preço − custo − comissão)</p>
          <p className={clsx("text-2xl font-semibold", margin >= 0 ? "text-primary-dark" : "text-rose-700")}>
            {brl(margin)} <span className="text-base font-medium opacity-70">({marginPct}%)</span>
          </p>
        </div>
      </form>
    </Modal>
  );
}

export default function ServicosPage() {
  const { can } = useSession();
  const [q, setQ] = useState("");
  const [active, setActive] = useState<"true" | "all">("true");
  const [editing, setEditing] = useState<Service | null>(null);
  const [open, setOpen] = useState(false);
  const { data, error, mutate } = useApi<{ data: Service[] }>(`/services?active=${active}${q ? `&q=${encodeURIComponent(q)}` : ""}`);
  const canManage = can("services.manage");

  return (
    <>
      <PageHeader title="Serviços" description="Seu catálogo: preço, custo, comissão e tempo de cada serviço."
        actions={canManage && <button type="button" className="btn btn-primary" onClick={() => { setEditing(null); setOpen(true); }}><Plus className="h-4 w-4" /> Novo serviço</button>} />
      <div className="mb-4 flex flex-wrap items-center gap-3">
        <div className="relative min-w-[220px] flex-1">
          <Search className="pointer-events-none absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
          <input className="input pl-10" type="search" placeholder="Buscar serviço ou categoria" value={q} onChange={(e) => setQ(e.target.value)} aria-label="Buscar serviço" />
        </div>
        <Segmented label="Mostrar" value={active} onChange={setActive} options={[{ value: "true", label: "Ativos" }, { value: "all", label: "Todos" }]} />
      </div>

      {error && <ErrorBox message={error.message} onRetry={() => mutate()} />}
      {!data && !error && <div className="card"><ListSkeleton rows={4} /></div>}
      {data && data.data.length === 0 && (
        <div className="card">
          <EmptyState icon={Wrench} title="Nenhum serviço cadastrado" description="Cadastre o que você vende para usar nas OS, na agenda e no link de pedidos."
            action={canManage && <button type="button" className="btn btn-primary" onClick={() => { setEditing(null); setOpen(true); }}><Plus className="h-4 w-4" /> Novo serviço</button>} />
        </div>
      )}
      {data && data.data.length > 0 && (
        <ul className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3">
          {data.data.map((s) => {
            const pct = s.priceCents ? Math.round((s.marginCents / s.priceCents) * 100) : 0;
            return (
              <li key={s.id} className={clsx("card flex flex-col p-5", !s.isActive && "opacity-60")}>
                <div className="flex items-start justify-between gap-3">
                  <div className="min-w-0">
                    <p className="truncate font-medium text-slate-800">{s.name}</p>
                    <p className="text-xs text-slate-500">{s.category ?? "Sem categoria"}</p>
                  </div>
                  {canManage && (
                    <button type="button" aria-label={`Editar ${s.name}`} className="icon-btn text-slate-400 hover:bg-primary-50 hover:text-primary" onClick={() => { setEditing(s); setOpen(true); }}>
                      <Pencil className="h-4 w-4" />
                    </button>
                  )}
                </div>
                <p className="mt-3 text-2xl font-semibold text-slate-900">{brl(s.priceCents)}</p>
                <div className="mt-3 flex flex-wrap items-center gap-2 text-xs">
                  {s.durationMinutes && <span className="inline-flex items-center gap-1 text-slate-500"><Clock className="h-3.5 w-3.5" /> {s.durationMinutes} min</span>}
                  <Badge tone={s.marginCents >= 0 ? "green" : "rose"}>Margem {pct}%</Badge>
                  {(s.ordersCount ?? 0) > 0 && <Badge tone="slate">{s.ordersCount} OS</Badge>}
                  {!s.isActive && <Badge tone="slate">Inativo</Badge>}
                </div>
              </li>
            );
          })}
        </ul>
      )}
      <ServiceForm open={open} onClose={() => setOpen(false)} service={editing} />
    </>
  );
}
