"use client";

import { Suspense, useEffect, useState } from "react";
import { usePathname, useRouter, useSearchParams } from "next/navigation";
import clsx from "clsx";
import { useSWRConfig } from "swr";
import { ArrowDownCircle, ArrowUpCircle, CheckCircle2, Plus, Repeat, Wallet, XCircle } from "lucide-react";
import CustomerPicker from "@/components/forms/CustomerPicker";
import Modal from "@/components/ui/Modal";
import { MoneyField, SelectField, TextArea, TextField, Toggle } from "@/components/ui/fields";
import { Badge, EmptyState, ErrorBox, ListSkeleton, PageHeader, Segmented, Spinner } from "@/components/ui/misc";
import { useToast } from "@/components/ui/toast";
import { api, ApiError } from "@/lib/api";
import { brl, dateBR, todayISO } from "@/lib/format";
import { invalidate, useApi } from "@/lib/hooks";
import { useSession } from "@/lib/session";
import type { FinanceTotals, FinancialEntry } from "@/lib/types";

const METHODS = [
  { value: "pix", label: "Pix" }, { value: "cash", label: "Dinheiro" }, { value: "credit_card", label: "Cartão de crédito" },
  { value: "debit_card", label: "Cartão de débito" }, { value: "boleto", label: "Boleto" }, { value: "transfer", label: "Transferência" }, { value: "other", label: "Outro" },
];

function EntryForm({ open, onClose, direction: initialDirection }: { open: boolean; onClose: () => void; direction: "in" | "out" }) {
  const toast = useToast();
  const { mutate } = useSWRConfig();
  const { data: cats } = useApi<{ data: { id: string; name: string; direction: "in" | "out" }[] }>(open ? "/finance/categories" : null);
  const [direction, setDirection] = useState<"in" | "out">(initialDirection);
  const [description, setDescription] = useState("");
  const [amount, setAmount] = useState<number | null>(null);
  const [dueOn, setDueOn] = useState(todayISO());
  const [categoryId, setCategoryId] = useState("");
  const [customer, setCustomer] = useState<{ id: string; name: string } | null>(null);
  const [mode, setMode] = useState<"single" | "installments" | "recurring">("single");
  const [installments, setInstallments] = useState("2");
  const [recurrence, setRecurrence] = useState("monthly");
  const [paidNow, setPaidNow] = useState(false);
  const [method, setMethod] = useState("pix");
  const [notes, setNotes] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!open) return;
    setDirection(initialDirection); setDescription(""); setAmount(null); setDueOn(todayISO()); setCategoryId(""); setCustomer(null);
    setMode("single"); setInstallments("2"); setRecurrence("monthly"); setPaidNow(false); setMethod("pix"); setNotes(""); setError(null);
  }, [open, initialDirection]);

  async function save(e: React.FormEvent) {
    e.preventDefault();
    if (!amount) { setError("Informe o valor."); return; }
    setBusy(true);
    setError(null);
    try {
      await api("/finance/entries", {
        method: "POST",
        body: {
          direction, description: description.trim(), amountCents: amount, dueOn, categoryId: categoryId || null,
          customerId: direction === "in" ? customer?.id ?? null : null, paymentMethod: method, notes: notes.trim() || null,
          installments: mode === "installments" ? Number(installments) : 1, recurrence: mode === "recurring" ? recurrence : "none", paidNow,
        },
      });
      await invalidate(mutate, "/finance", "/dashboard");
      toast(direction === "in" ? "Receita lançada." : "Despesa lançada.");
      onClose();
    } catch (err) {
      setError(err instanceof ApiError ? err.message : "Não foi possível salvar.");
    } finally {
      setBusy(false);
    }
  }

  return (
    <Modal open={open} onClose={onClose} title="Novo lançamento" size="lg"
      footer={<><button type="button" className="btn btn-ghost" onClick={onClose}>Cancelar</button>
        <button type="submit" form="entry-form" className="btn btn-primary" disabled={busy}>{busy && <Spinner />} Lançar</button></>}>
      <form id="entry-form" onSubmit={save} className="grid gap-4 sm:grid-cols-2">
        <div className="sm:col-span-2">
          <Segmented label="Tipo" value={direction} onChange={setDirection} options={[{ value: "in", label: "Receita (a receber)" }, { value: "out", label: "Despesa (a pagar)" }]} />
        </div>
        <TextField className="sm:col-span-2" label="Descrição" required value={description} onChange={(e) => setDescription(e.target.value)}
          placeholder={direction === "in" ? "Ex.: Serviço para Paulo" : "Ex.: Aluguel da loja"} />
        <MoneyField label={mode === "installments" ? "Valor total" : "Valor"} required value={amount} onChange={setAmount} />
        <TextField label={mode === "installments" ? "1º vencimento" : "Vencimento"} type="date" required value={dueOn} onChange={(e) => setDueOn(e.target.value)} />
        <SelectField label="Categoria" value={categoryId} onChange={(e) => setCategoryId(e.target.value)} placeholder="Sem categoria"
          options={(cats?.data ?? []).filter((c) => c.direction === direction).map((c) => ({ value: c.id, label: c.name }))} />
        <SelectField label="Forma de pagamento" value={method} onChange={(e) => setMethod(e.target.value)} options={METHODS} />
        {direction === "in" && <div className="sm:col-span-2"><CustomerPicker label="Cliente (opcional)" value={customer} onChange={setCustomer} /></div>}

        <div className="sm:col-span-2">
          <Segmented label="Repetição" value={mode} onChange={setMode}
            options={[{ value: "single", label: "Única" }, { value: "installments", label: "Parcelada" }, { value: "recurring", label: "Fixa (recorrente)" }]} />
        </div>
        {mode === "installments" && (
          <TextField label="Número de parcelas" type="number" min={2} max={48} value={installments} onChange={(e) => setInstallments(e.target.value)}
            hint={amount ? `${installments}× de ${brl(Math.floor(amount / (Number(installments) || 1)))}` : undefined} />
        )}
        {mode === "recurring" && (
          <SelectField label="Repete" value={recurrence} onChange={(e) => setRecurrence(e.target.value)} hint="O Avocato lança as próximas sozinho."
            options={[{ value: "weekly", label: "Toda semana" }, { value: "monthly", label: "Todo mês" }, { value: "yearly", label: "Todo ano" }]} />
        )}
        <div className="sm:col-span-2"><Toggle checked={paidNow} onChange={setPaidNow} label={direction === "in" ? "Já recebi" : "Já paguei"} description="Registra a baixa agora, no caixa." /></div>
        <TextArea className="sm:col-span-2" label="Observações" value={notes} onChange={(e) => setNotes(e.target.value)} />
        {error && <p role="alert" className="rounded-xl bg-rose-50 px-3 py-2.5 text-sm text-rose-700 sm:col-span-2">{error}</p>}
      </form>
    </Modal>
  );
}

function PayModal({ entry, onClose }: { entry: FinancialEntry | null; onClose: () => void }) {
  const toast = useToast();
  const { mutate } = useSWRConfig();
  const [amount, setAmount] = useState<number | null>(null);
  const [method, setMethod] = useState("pix");
  const [date, setDate] = useState(todayISO());
  const [busy, setBusy] = useState(false);
  useEffect(() => {
    if (entry) { setAmount(entry.amountCents - entry.paidAmountCents); setMethod(entry.paymentMethod ?? "pix"); setDate(todayISO()); }
  }, [entry]);
  if (!entry) return null;

  async function pay(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true);
    try {
      await api(`/finance/entries/${entry!.id}/pay`, { method: "POST", body: { amountCents: amount ?? undefined, paymentMethod: method, paidAt: new Date(`${date}T12:00:00`).toISOString() } });
      await invalidate(mutate, "/finance", "/dashboard", "/service-orders");
      toast(entry!.direction === "in" ? "Recebimento registrado." : "Pagamento registrado.");
      onClose();
    } catch (err) {
      toast(err instanceof ApiError ? err.message : "Não foi possível registrar.", "error");
    } finally {
      setBusy(false);
    }
  }

  return (
    <Modal open onClose={onClose} size="sm" title={entry.direction === "in" ? "Registrar recebimento" : "Registrar pagamento"} description={entry.description}
      footer={<><button type="button" className="btn btn-ghost" onClick={onClose}>Cancelar</button>
        <button type="submit" form="pay-form" className="btn btn-primary" disabled={busy}>{busy && <Spinner />} Confirmar</button></>}>
      <form id="pay-form" onSubmit={pay} className="space-y-4">
        <MoneyField label="Valor" value={amount} onChange={setAmount} hint={`Em aberto: ${brl(entry.amountCents - entry.paidAmountCents)}. Valor menor = pagamento parcial.`} />
        <SelectField label="Forma" value={method} onChange={(e) => setMethod(e.target.value)} options={METHODS} />
        <TextField label="Data" type="date" value={date} onChange={(e) => setDate(e.target.value)} />
      </form>
    </Modal>
  );
}

function statusBadge(e: FinancialEntry) {
  if (e.status === "paid") return <Badge tone="green">{e.direction === "in" ? "Recebido" : "Pago"}</Badge>;
  if (e.status === "canceled") return <Badge tone="slate">Cancelado</Badge>;
  if (e.isOverdue) return <Badge tone="rose">Vencido</Badge>;
  if (e.status === "partially_paid") return <Badge tone="amber">Parcial</Badge>;
  return <Badge tone="sky">Em aberto</Badge>;
}

function FinanceiroView() {
  const params = useSearchParams();
  const router = useRouter();
  const pathname = usePathname();
  const toast = useToast();
  const { can } = useSession();
  const { mutate: gmutate } = useSWRConfig();
  const [direction, setDirection] = useState<"all" | "in" | "out">((params.get("tipo") as "in" | "out") || "all");
  const [status, setStatus] = useState<"open" | "overdue" | "paid" | "all">("open");
  const [formOpen, setFormOpen] = useState(false);
  const [formDirection, setFormDirection] = useState<"in" | "out">("in");
  const [paying, setPaying] = useState<FinancialEntry | null>(null);
  const [showRecurring, setShowRecurring] = useState(false);

  useEffect(() => {
    const novo = params.get("novo");
    if (novo === "in" || novo === "out") { setFormDirection(novo); setFormOpen(true); router.replace(pathname); }
  }, [params, router, pathname]);

  const qs = new URLSearchParams({ status });
  if (direction !== "all") qs.set("direction", direction);
  const { data, error, isLoading, mutate } = useApi<{ data: FinancialEntry[]; totals: FinanceTotals }>(`/finance/entries?${qs}`);
  const { data: rules } = useApi<{ data: { id: string; direction: "in" | "out"; description: string; amountCents: number; frequency: string; nextDueOn: string; isActive: boolean }[] }>(showRecurring ? "/finance/recurring" : null);
  const t = data?.totals;
  const canManage = can("finance.manage");

  async function cancel(e: FinancialEntry) {
    try {
      await api(`/finance/entries/${e.id}/cancel`, { method: "POST" });
      await invalidate(gmutate, "/finance", "/dashboard");
      toast("Lançamento cancelado.");
    } catch (err) {
      toast(err instanceof ApiError ? err.message : "Não foi possível cancelar.", "error");
    }
  }

  const cards = [
    { label: "A receber", value: t?.receivableOpenCents, sub: t?.receivableOverdueCents ? `${brl(t.receivableOverdueCents)} vencido` : "nada vencido", icon: ArrowDownCircle, tone: "text-primary bg-primary-50", alert: !!t?.receivableOverdueCents },
    { label: "Recebido no mês", value: t?.receivedMonthCents, sub: "entradas registradas", icon: Wallet, tone: "text-secondary bg-secondary-50" },
    { label: "A pagar", value: t?.payableOpenCents, sub: t?.payableOverdueCents ? `${brl(t.payableOverdueCents)} vencido` : "nada vencido", icon: ArrowUpCircle, tone: "text-amber-600 bg-amber-50", alert: !!t?.payableOverdueCents },
    { label: "Pago no mês", value: t?.paidMonthCents, sub: "saídas registradas", icon: CheckCircle2, tone: "text-slate-600 bg-slate-100" },
  ];

  return (
    <>
      <PageHeader title="Financeiro" description="Contas a receber e a pagar. Serviços concluídos entram aqui sozinhos."
        actions={<>
          <button type="button" className="btn btn-outline" onClick={() => setShowRecurring(true)}><Repeat className="h-4 w-4" /> Contas fixas</button>
          {canManage && <>
            <button type="button" className="btn btn-outline" onClick={() => { setFormDirection("out"); setFormOpen(true); }}><Plus className="h-4 w-4" /> Despesa</button>
            <button type="button" className="btn btn-primary" onClick={() => { setFormDirection("in"); setFormOpen(true); }}><Plus className="h-4 w-4" /> Receita</button>
          </>}
        </>} />

      <div className="mb-5 grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        {cards.map((c) => (
          <div key={c.label} className="card flex items-center gap-4 p-5">
            <span className={clsx("inline-flex h-11 w-11 items-center justify-center rounded-xl", c.tone)}><c.icon className="h-5 w-5" /></span>
            <div>
              <p className="text-lg font-semibold text-slate-800">{c.value === undefined ? "…" : brl(c.value)}</p>
              <p className="text-sm text-slate-500">{c.label}</p>
              <p className={clsx("text-xs", c.alert ? "font-medium text-rose-600" : "text-slate-400")}>{c.sub}</p>
            </div>
          </div>
        ))}
      </div>

      <div className="card">
        <div className="flex flex-wrap items-center gap-3 border-b border-slate-100 p-4">
          <Segmented label="Tipo" value={direction} onChange={setDirection} options={[{ value: "all", label: "Tudo" }, { value: "in", label: "Receitas" }, { value: "out", label: "Despesas" }]} />
          <Segmented label="Situação" value={status} onChange={setStatus} options={[{ value: "open", label: "Em aberto" }, { value: "overdue", label: "Vencidas" }, { value: "paid", label: "Quitadas" }, { value: "all", label: "Todas" }]} />
        </div>
        {error && <ErrorBox message={error.message} onRetry={() => mutate()} />}
        {isLoading && !data && <ListSkeleton />}
        {data && data.data.length === 0 && <EmptyState icon={Wallet} title="Nenhum lançamento aqui" description="Lance receitas e despesas ou conclua uma OS para gerar a conta a receber." />}
        {data && data.data.length > 0 && (
          <div className="overflow-x-auto">
            <table className="w-full min-w-[640px]">
              <thead className="border-b border-slate-100">
                <tr><th className="table-head">Vencimento</th><th className="table-head">Descrição</th><th className="table-head text-right">Valor</th><th className="table-head">Situação</th><th className="table-head"><span className="sr-only">Ações</span></th></tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {data.data.map((e) => {
                  const open = e.status === "open" || e.status === "partially_paid";
                  return (
                    <tr key={e.id} className="hover:bg-slate-50/70">
                      <td className={clsx("table-cell whitespace-nowrap", e.isOverdue && "font-medium text-rose-600")}>{dateBR(e.dueOn)}</td>
                      <td className="table-cell">
                        <span className="flex items-center gap-2">
                          {e.direction === "in" ? <ArrowDownCircle className="h-4 w-4 shrink-0 text-primary" aria-label="Receita" /> : <ArrowUpCircle className="h-4 w-4 shrink-0 text-amber-500" aria-label="Despesa" />}
                          <span className="min-w-0">
                            <span className="block truncate font-medium text-slate-800">{e.description}</span>
                            <span className="block truncate text-xs text-slate-500">
                              {[e.customer?.name, e.category?.name, e.recurringRuleId && "fixa"].filter(Boolean).join(" · ")}
                            </span>
                          </span>
                        </span>
                      </td>
                      <td className={clsx("table-cell whitespace-nowrap text-right font-medium", e.direction === "in" ? "text-slate-800" : "text-slate-600")}>
                        {e.direction === "out" && "− "}{brl(e.amountCents)}
                        {e.status === "partially_paid" && <span className="block text-xs font-normal text-slate-500">pago {brl(e.paidAmountCents)}</span>}
                      </td>
                      <td className="table-cell">{statusBadge(e)}</td>
                      <td className="table-cell">
                        {canManage && open && (
                          <div className="flex justify-end gap-1">
                            <button type="button" className="btn btn-soft btn-sm" onClick={() => setPaying(e)}>{e.direction === "in" ? "Receber" : "Pagar"}</button>
                            {e.paidAmountCents === 0 && (
                              <button type="button" aria-label={`Cancelar ${e.description}`} className="icon-btn h-8 w-8 text-slate-400 hover:bg-rose-50 hover:text-rose-600" onClick={() => cancel(e)}>
                                <XCircle className="h-4 w-4" />
                              </button>
                            )}
                          </div>
                        )}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>

      <EntryForm open={formOpen} onClose={() => setFormOpen(false)} direction={formDirection} />
      <PayModal entry={paying} onClose={() => setPaying(null)} />
      <Modal open={showRecurring} onClose={() => setShowRecurring(false)} title="Contas fixas" description="Lançadas automaticamente a cada período." size="lg">
        {!rules ? <ListSkeleton rows={3} /> : rules.data.length === 0 ? (
          <p className="rounded-xl bg-slate-50 p-4 text-sm text-slate-500">Nenhuma conta fixa. Ao lançar, escolha “Fixa (recorrente)” para aluguel, internet, mensalidades…</p>
        ) : (
          <ul className="divide-y divide-slate-100">
            {rules.data.map((r) => (
              <li key={r.id} className="flex items-center justify-between gap-3 py-3">
                <div>
                  <p className="text-sm font-medium text-slate-800">{r.description}</p>
                  <p className="text-xs text-slate-500">{brl(r.amountCents)} · {r.frequency === "monthly" ? "mensal" : r.frequency === "weekly" ? "semanal" : "anual"} · próxima {dateBR(r.nextDueOn)}</p>
                </div>
                {canManage && (
                  <Toggle checked={r.isActive} label={r.isActive ? "Ativa" : "Pausada"} onChange={async (v) => {
                    await api(`/finance/recurring/${r.id}`, { method: "PATCH", body: { isActive: v } });
                    await invalidate(gmutate, "/finance");
                  }} />
                )}
              </li>
            ))}
          </ul>
        )}
      </Modal>
    </>
  );
}

export default function FinanceiroPage() {
  return <Suspense><FinanceiroView /></Suspense>;
}
