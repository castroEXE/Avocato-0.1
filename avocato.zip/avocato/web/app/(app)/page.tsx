"use client";

import Link from "next/link";
import { BellRing, CalendarDays, ChevronRight, Plus, Star, Store, Users, Wallet2 } from "lucide-react";
import { EarningCard, OrderCard } from "@/components/dashboard/StatCard";
import IncomeCard from "@/components/dashboard/IncomeCard";
import CashflowChart from "@/components/dashboard/CashflowChart";
import TopServicesWidget from "@/components/dashboard/TopServicesWidget";
import { ErrorBox, Skeleton } from "@/components/ui/misc";
import { brl, greeting, timeBR } from "@/lib/format";
import { useApi } from "@/lib/hooks";
import { useSession } from "@/lib/session";
import type { Dashboard } from "@/lib/types";

function DashboardSkeleton() {
  return (
    <div className="grid grid-cols-12 gap-5" aria-busy="true" aria-label="Carregando painel">
      <Skeleton className="col-span-12 h-[188px] md:col-span-6 xl:col-span-4" />
      <Skeleton className="col-span-12 h-[188px] md:col-span-6 xl:col-span-4" />
      <Skeleton className="col-span-12 h-[188px] xl:col-span-4" />
      <Skeleton className="col-span-12 h-[420px] xl:col-span-8" />
      <Skeleton className="col-span-12 h-[420px] xl:col-span-4" />
    </div>
  );
}

export default function PainelPage() {
  const { me, can, hasModule, term } = useSession();
  const { data, error, mutate } = useApi<Dashboard>("/dashboard", { refreshInterval: 120_000 });
  const raw = new Date().toLocaleDateString("pt-BR", { weekday: "long", day: "numeric", month: "long" });
  const today = raw.charAt(0).toUpperCase() + raw.slice(1);

  return (
    <>
      <div className="mb-5 flex flex-wrap items-end justify-between gap-3">
        <div>
          <h1 className="text-xl font-semibold tracking-tight text-slate-900 sm:text-2xl">{greeting(me?.user.fullName ?? "")} 🥑</h1>
          <p className="mt-1 text-sm text-slate-500">{today}</p>
        </div>
        <div className="flex gap-2">
          {hasModule("appointments") && can("appointments.create") && (
            <Link href="/agenda?novo=1" className="btn btn-outline"><CalendarDays className="h-4 w-4" /> Agendar</Link>
          )}
          {hasModule("service_orders") && can("service_orders.create") && (
            <Link href="/ordens?nova=1" className="btn btn-primary"><Plus className="h-4 w-4" /> Nova OS</Link>
          )}
        </div>
      </div>

      {error && <ErrorBox message={error.message} onRetry={() => mutate()} />}
      {!data && !error && <DashboardSkeleton />}

      {data && (
        <div className="grid grid-cols-12 gap-5">
          {data.orders.requested > 0 && (
            <Link href="/ordens?status=requested"
              className="col-span-12 flex items-center gap-3 rounded-2xl bg-amber-50 px-5 py-4 text-amber-900 ring-1 ring-amber-100 transition-colors hover:bg-amber-100">
              <BellRing className="h-5 w-5 shrink-0 text-amber-600" />
              <p className="flex-1 text-sm">
                <strong>{data.orders.requested} {data.orders.requested === 1 ? "solicitação nova" : "solicitações novas"}</strong> de clientes esperando sua resposta.
              </p>
              <ChevronRight className="h-4 w-4" />
            </Link>
          )}

          <div className="col-span-12 md:col-span-6 xl:col-span-4">
            {data.finance ? (
              <EarningCard valueCents={data.finance.receivedMonthCents} previousCents={data.finance.receivedPrevMonthCents} />
            ) : (
              <IncomeCard icon={Users} tone="green" value={String(data.customers.total)} label={term("customers", "Clientes")} />
            )}
          </div>
          <div className="col-span-12 md:col-span-6 xl:col-span-4">
            <OrderCard series={data.orders.series} doneThisMonth={data.orders.doneThisMonth} />
          </div>
          <div className="col-span-12 grid gap-5 sm:grid-cols-2 xl:col-span-4 xl:grid-cols-1 xl:grid-rows-2">
            {data.finance ? (
              <>
                <IncomeCard icon={Wallet2} tone="green" value={brl(data.finance.receivableOpenCents)} label="A receber" href="/financeiro?tipo=in"
                  detail={data.finance.receivableOverdueCents > 0 ? `${brl(data.finance.receivableOverdueCents)} vencido` : undefined} />
                <IncomeCard icon={Store} tone="amber" value={brl(data.finance.payableOpenCents)} label="A pagar" href="/financeiro?tipo=out"
                  detail={data.finance.payableOverdueCents > 0 ? `${brl(data.finance.payableOverdueCents)} vencido` : undefined} />
              </>
            ) : (
              <>
                <IncomeCard icon={CalendarDays} tone="green" value={String(data.todayAppointments)} label="Agendamentos hoje" />
                <IncomeCard icon={Star} tone="amber" value={data.averageRating ? `${data.averageRating} ★` : "—"} label="Avaliação média" />
              </>
            )}
          </div>

          <div className="col-span-12 xl:col-span-8">
            {data.finance ? <CashflowChart data={data.cashflow} /> : <UpcomingCard data={data} />}
          </div>
          <div className="col-span-12 xl:col-span-4">
            <TopServicesWidget services={data.topServices} series={data.orders.series} />
          </div>

          {data.finance && (
            <>
              <div className="col-span-12 lg:col-span-7"><UpcomingCard data={data} /></div>
              <div className="col-span-12 lg:col-span-5">
                <section className="card grid h-full grid-cols-3 divide-x divide-slate-100 p-5" aria-label="Números rápidos">
                  {[
                    { label: term("customers", "Clientes"), value: data.customers.total, sub: `+${data.customers.newThisMonth} no mês` },
                    { label: "OS em andamento", value: data.orders.active, sub: "abertas e agendadas" },
                    { label: "Avaliação", value: data.averageRating ? `${data.averageRating}★` : "—", sub: "média dos clientes" },
                  ].map((s) => (
                    <div key={s.label} className="flex flex-col items-center justify-center px-2 text-center">
                      <p className="text-2xl font-semibold text-slate-800">{s.value}</p>
                      <p className="mt-1 text-sm text-slate-600">{s.label}</p>
                      <p className="text-xs text-slate-400">{s.sub}</p>
                    </div>
                  ))}
                </section>
              </div>
            </>
          )}
        </div>
      )}
    </>
  );
}

function UpcomingCard({ data }: { data: Dashboard }) {
  return (
    <section className="card h-full p-5 sm:p-6" aria-labelledby="up-title">
      <div className="flex items-center justify-between">
        <h2 id="up-title" className="text-lg font-medium text-slate-800">Próximos atendimentos</h2>
        <Link href="/agenda" className="text-sm font-medium text-primary hover:text-primary-dark">Ver agenda</Link>
      </div>
      {data.upcoming.length === 0 ? (
        <p className="py-10 text-center text-sm text-slate-400">Nenhum agendamento pela frente.</p>
      ) : (
        <ul className="mt-3 divide-y divide-slate-100">
          {data.upcoming.map((a) => {
            const d = new Date(a.startsAt);
            return (
              <li key={a.id} className="flex items-center gap-4 py-3">
                <div className="flex w-14 shrink-0 flex-col items-center rounded-xl bg-primary-50 py-1.5 text-primary-dark">
                  <span className="text-[11px] uppercase">{d.toLocaleDateString("pt-BR", { weekday: "short" }).replace(".", "")}</span>
                  <span className="text-lg font-semibold leading-none">{d.getDate()}</span>
                </div>
                <div className="min-w-0 flex-1">
                  <p className="truncate text-sm font-medium text-slate-800">{a.customer}</p>
                  <p className="truncate text-xs text-slate-500">{[a.service, a.staff].filter(Boolean).join(" · ") || "Atendimento"}</p>
                </div>
                <span className="text-sm font-medium text-slate-700">{timeBR(a.startsAt)}</span>
              </li>
            );
          })}
        </ul>
      )}
    </section>
  );
}
