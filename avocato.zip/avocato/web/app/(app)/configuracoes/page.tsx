"use client";

import { useEffect, useState } from "react";
import { Check, Copy, ExternalLink } from "lucide-react";
import { SelectField, TextArea, TextField, Toggle } from "@/components/ui/fields";
import { Badge, PageHeader, Spinner } from "@/components/ui/misc";
import { useToast } from "@/components/ui/toast";
import { api, ApiError } from "@/lib/api";
import { dateBR } from "@/lib/format";
import { useSession } from "@/lib/session";

const MODULES: { key: string; label: string; description: string }[] = [
  { key: "service_orders", label: "Ordens de serviço", description: "Pedidos, execução, conclusão e avaliação." },
  { key: "appointments", label: "Agenda", description: "Horários da equipe e lembretes." },
  { key: "services", label: "Serviços", description: "Catálogo com preço, custo e margem." },
  { key: "team", label: "Equipe", description: "Funcionários e prestadores." },
  { key: "finance", label: "Financeiro", description: "Contas a receber e a pagar, caixa." },
  { key: "ai", label: "Assistente IA", description: "Chat que trabalha no sistema por você." },
];

const TIMEZONES = [
  ["America/Sao_Paulo", "Brasília (SP, RJ, MG, Sul, Nordeste…)"], ["America/Manaus", "Amazonas (−1h)"], ["America/Cuiaba", "Mato Grosso (−1h)"],
  ["America/Porto_Velho", "Rondônia (−1h)"], ["America/Rio_Branco", "Acre (−2h)"], ["America/Noronha", "Fernando de Noronha (+1h)"],
];

export default function ConfiguracoesPage() {
  const { context, can, refresh } = useSession();
  const toast = useToast();
  const editable = can("settings.manage");
  const [name, setName] = useState("");
  const [timezone, setTimezone] = useState("America/Sao_Paulo");
  const [phone, setPhone] = useState("");
  const [description, setDescription] = useState("");
  const [customersTerm, setCustomersTerm] = useState("Clientes");
  const [publicOn, setPublicOn] = useState(true);
  const [modules, setModules] = useState<Record<string, boolean>>({});
  const [busy, setBusy] = useState(false);
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    if (!context) return;
    setName(context.organization.name);
    setTimezone(context.organization.timezone);
    setPhone(String(context.settings.businessProfile.phone ?? ""));
    setDescription(String(context.settings.businessProfile.description ?? ""));
    setCustomersTerm(context.settings.terminology.customers ?? "Clientes");
    setPublicOn(context.settings.workflowConfiguration.publicRequestsEnabled !== false);
    setModules(Object.fromEntries(MODULES.map((m) => [m.key, context.enabledModules.includes(m.key)])));
  }, [context]);

  if (!context) return null;
  const url = `${typeof window !== "undefined" ? window.location.origin : ""}/solicitar/${context.organization.slug}`;

  async function save() {
    setBusy(true);
    try {
      if (name.trim() !== context!.organization.name || timezone !== context!.organization.timezone) {
        await api("/organization", { method: "PATCH", body: { name: name.trim(), timezone } });
      }
      await api("/organization/settings", {
        method: "PATCH",
        body: {
          businessProfile: { phone: phone.trim(), description: description.trim() },
          terminology: { customers: customersTerm.trim() || "Clientes" },
          workflowConfiguration: { publicRequestsEnabled: publicOn },
          enabledModules: modules,
        },
      });
      await refresh();
      toast("Configurações salvas.");
    } catch (err) {
      toast(err instanceof ApiError ? err.message : "Não foi possível salvar.", "error");
    } finally {
      setBusy(false);
    }
  }

  const sub = context.subscription;
  return (
    <>
      <PageHeader title="Configurações" description="Como sua empresa aparece e quais partes do Avocato ela usa."
        actions={editable && <button type="button" className="btn btn-primary" onClick={save} disabled={busy || name.trim().length < 2}>{busy && <Spinner />} Salvar alterações</button>} />
      {!editable && <p className="mb-4 rounded-xl bg-slate-100 p-3 text-sm text-slate-600">Só administradores alteram estas configurações.</p>}

      <div className="grid gap-5 xl:grid-cols-2">
        <section className="card space-y-4 p-5 sm:p-6" aria-label="Empresa">
          <h2 className="text-lg font-medium text-slate-800">Empresa</h2>
          <TextField label="Nome" value={name} onChange={(e) => setName(e.target.value)} disabled={!editable} />
          <SelectField label="Fuso horário" value={timezone} onChange={(e) => setTimezone(e.target.value)} disabled={!editable}
            options={TIMEZONES.map(([value, label]) => ({ value, label }))} />
          <TextField label="WhatsApp da empresa" type="tel" value={phone} onChange={(e) => setPhone(e.target.value)} disabled={!editable} />
          <TextArea label="Sobre a empresa" value={description} onChange={(e) => setDescription(e.target.value)} disabled={!editable}
            hint="Aparece no topo do seu link de pedidos." />
          <TextField label="Como você chama seus clientes?" value={customersTerm} onChange={(e) => setCustomersTerm(e.target.value)} disabled={!editable}
            hint="Ex.: Pacientes, Tutores, Alunos. Muda o menu e as telas." />
        </section>

        <div className="space-y-5">
          <section className="card space-y-4 p-5 sm:p-6" aria-label="Link de pedidos">
            <h2 className="text-lg font-medium text-slate-800">Link de pedidos</h2>
            <Toggle checked={publicOn} onChange={setPublicOn} label="Receber pedidos pelo link" description="Clientes pedem serviços sem login. Chegam como “Solicitação” nas OS." />
            {publicOn && (
              <div className="flex flex-wrap items-center gap-2 rounded-xl bg-primary-50 p-3">
                <code className="min-w-0 flex-1 truncate text-sm text-primary-dark">{url}</code>
                <button type="button" className="btn btn-soft btn-sm bg-white" onClick={async () => { await navigator.clipboard.writeText(url).catch(() => undefined); setCopied(true); setTimeout(() => setCopied(false), 2000); }}>
                  {copied ? <Check className="h-4 w-4" /> : <Copy className="h-4 w-4" />} {copied ? "Copiado" : "Copiar"}
                </button>
                <a href={url} target="_blank" rel="noreferrer" className="btn btn-soft btn-sm bg-white"><ExternalLink className="h-4 w-4" /> Abrir</a>
              </div>
            )}
          </section>

          <section className="card p-5 sm:p-6" aria-label="Módulos">
            <h2 className="mb-1 text-lg font-medium text-slate-800">Módulos</h2>
            <p className="mb-4 text-sm text-slate-500">Desligue o que sua empresa não usa: o menu fica mais limpo.</p>
            <div className="space-y-4">
              {MODULES.map((m) => (
                <Toggle key={m.key} checked={!!modules[m.key]} label={m.label} description={m.description}
                  onChange={(v) => editable && setModules((s) => ({ ...s, [m.key]: v }))} />
              ))}
            </div>
          </section>

          <section className="card p-5 sm:p-6" aria-label="Plano">
            <h2 className="mb-2 text-lg font-medium text-slate-800">Plano</h2>
            <p className="flex flex-wrap items-center gap-2 text-sm text-slate-600">
              {sub.planName} <Badge tone={sub.status === "active" ? "green" : "amber"}>{sub.status === "trialing" ? "Em teste" : sub.status === "active" ? "Ativo" : sub.status}</Badge>
              {sub.trialEndsAt && sub.status === "trialing" && <span className="text-slate-500">até {dateBR(sub.trialEndsAt)}</span>}
            </p>
            {sub.limits.ai_requests_month != null && <p className="mt-1 text-xs text-slate-500">Inclui {sub.limits.ai_requests_month} mensagens de IA por mês.</p>}
          </section>
        </div>
      </div>
    </>
  );
}
