"use client";

import { useEffect, useState } from "react";
import AvatarBuilder from "@/components/avatar/AvatarBuilder";
import { TextField } from "@/components/ui/fields";
import { PageHeader, Spinner } from "@/components/ui/misc";
import { useToast } from "@/components/ui/toast";
import { api, ApiError } from "@/lib/api";
import { defaultAvatar } from "@/lib/avatar";
import { useSession } from "@/lib/session";
import { supabase } from "@/lib/supabase";
import type { AvatarConfig } from "@/lib/types";

export default function PerfilPage() {
  const { me, context, refresh } = useSession();
  const toast = useToast();
  const [name, setName] = useState("");
  const [avatar, setAvatar] = useState<AvatarConfig | null>(null);
  const [busy, setBusy] = useState(false);
  const [password, setPassword] = useState("");
  const [pwBusy, setPwBusy] = useState(false);

  useEffect(() => {
    if (!me) return;
    setName(me.user.fullName);
    setAvatar(me.user.avatar ?? defaultAvatar(me.user.fullName || me.user.email || "avocato"));
  }, [me]);

  if (!me || !avatar) return null;
  const dirty = name.trim() !== me.user.fullName || JSON.stringify(avatar) !== JSON.stringify(me.user.avatar);

  async function save() {
    setBusy(true);
    try {
      await api("/profile", { method: "PATCH", body: { fullName: name.trim(), avatar } });
      await refresh();
      toast("Perfil salvo. Seu novo avatar já aparece para a equipe.");
    } catch (err) {
      toast(err instanceof ApiError ? err.message : "Não foi possível salvar.", "error");
    } finally {
      setBusy(false);
    }
  }

  async function changePassword(e: React.FormEvent) {
    e.preventDefault();
    setPwBusy(true);
    const { error } = await supabase().auth.updateUser({ password });
    setPwBusy(false);
    if (error) toast(/should be/i.test(error.message) ? "A senha precisa ter pelo menos 6 caracteres." : error.message, "error");
    else { toast("Senha alterada."); setPassword(""); }
  }

  return (
    <>
      <PageHeader title="Meu perfil" description="Escolha como você aparece para a equipe."
        actions={<button type="button" className="btn btn-primary" disabled={!dirty || busy || !name.trim()} onClick={save}>{busy && <Spinner />} Salvar perfil</button>} />
      <div className="grid gap-5 xl:grid-cols-[1fr_320px]">
        <section className="card p-5 sm:p-6" aria-label="Avatar">
          <h2 className="mb-4 text-lg font-medium text-slate-800">Seu avatar</h2>
          <AvatarBuilder value={avatar} onChange={setAvatar} name={name || "Você"} />
        </section>
        <div className="space-y-5">
          <section className="card space-y-4 p-5" aria-label="Dados">
            <h2 className="text-lg font-medium text-slate-800">Seus dados</h2>
            <TextField label="Nome" value={name} onChange={(e) => setName(e.target.value)} required />
            <TextField label="E-mail" value={me.user.email ?? ""} disabled hint="O e-mail é o seu login." />
            <p className="text-sm text-slate-500">Papel em {context?.organization.name}: <strong className="text-slate-700">{context?.role.name}</strong></p>
          </section>
          <form onSubmit={changePassword} className="card space-y-4 p-5" aria-label="Senha">
            <h2 className="text-lg font-medium text-slate-800">Trocar senha</h2>
            <TextField label="Nova senha" type="password" minLength={6} autoComplete="new-password" value={password} onChange={(e) => setPassword(e.target.value)} />
            <button type="submit" className="btn btn-outline w-full" disabled={pwBusy || password.length < 6}>{pwBusy && <Spinner />} Atualizar senha</button>
          </form>
        </div>
      </div>
    </>
  );
}
