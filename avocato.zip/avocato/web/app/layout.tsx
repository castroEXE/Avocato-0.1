import type { Metadata, Viewport } from "next";
import "@fontsource/roboto/400.css";
import "@fontsource/roboto/500.css";
import "@fontsource/roboto/700.css";
import Providers from "./providers";
import "./globals.css";

export const metadata: Metadata = {
  title: { default: "Avocato", template: "%s · Avocato" },
  description: "Avocato: gestão completa para pequenas empresas de serviço — pedidos, OS, agenda, clientes, financeiro e assistente com IA.",
  applicationName: "Avocato",
};

export const viewport: Viewport = { themeColor: "#047857" };

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="pt-BR">
      <body className="min-h-screen font-sans">
        <Providers>{children}</Providers>
      </body>
    </html>
  );
}
