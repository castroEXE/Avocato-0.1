"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import clsx from "clsx";
import { LogOut } from "lucide-react";
import AuthLayout from "@/components/layout/AuthLayout";
import { Splash } from "@/components/layout/AppShell";
import { TextField, Toggle } from "@/components/ui/fields";
import { Spinner } from "@/components/ui/misc";
import { api, ApiError, orgStore } from "@/lib/api";
import { brl } from "@/lib/format";
import { SEGMENTS } from "@/lib/segments";
import { useSession } from "@/lib/session";

export default function CriarEmpresaPage() {
  const router = useRouter();
  const { status, me, refresh, signOut } = useSession();
  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [segment, setSegment] = useState("manutencao");
  const [seed, setSeed] = useState(true);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (status === "signed_out") router.replace("/entrar");
  }, [status, router]);

  if (status === "loading" || status === "signed_out") return <Splash />;

  const seg = SEGMENTS.find((s) => s.key === segment)!;

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true);
    setError(null);
    try {
      const org = await api<{ id: string }>("/organizations", { method: "POST", body: { name: name.trim() } });
      orgStore.set(org.id);
      await api("/organization/settings", {
        method: "PATCH",
        body: {
          onboardingStatus: "completed",
          businessProfile: { segment, ...(phone.trim() ? { phone: phone.trim() } : {}) },
          ...(seg.terminology ? { terminology: seg.terminology } : {}),
        },
      });
      if (seed) {
        for (const s of seg.services) await api("/services", { method: "POST", body: s });
      }
      await refresh();
      router.replace("/");
    } catch (err) {
      setError(err instanceof ApiError ? err.message : "Não foi possível criar a empresa.");
      setBusy(false);
    }
  }

  const first = me?.user.fullName.split(" ")[0];
  return (
    <AuthLayout>
      <h1 className="text-2xl font-semibold tracking-tight text-slate-900">{first ? `Olá, ${first}! ` : ""}Vamos criar sua empresa</h1>
      <p className="mt-1 text-sm text-slate-500">Leva menos de um minuto. Dá para mudar tudo depois.</p>

      <form onSubmit={submit} className="mt-6 space-y-5">
        <TextField label="Nome da empresa" required minLength={2} value={name} onChange={(e) => setName(e.target.value)} placeholder="Ex.: Elétrica Rosa" />
        <fieldset>
          <legend className="field-label">Qual é o seu ramo?</legend>
          <div className="grid grid-cols-2 gap-2">
            {SEGMENTS.map((s) => (
              <button key={s.key} type="button" onClick={() => setSegment(s.key)} aria-pressed={segment === s.key}
                className={clsx("flex items-center gap-2 rounded-xl px-3 py-2.5 text-left text-sm transition-colors",
                  segment === s.key ? "bg-primary-50 font-medium text-primary-dark ring-2 ring-primary" : "bg-white text-slate-600 ring-1 ring-slate-200 hover:bg-slate-50")}>
                <span aria-hidden="true" className="text-lg">{s.emoji}</span>
                <span className="leading-tight">{s.label}</span>
              </button>
            ))}
          </div>
        </fieldset>
        <TextField label="WhatsApp da empresa" type="tel" autoComplete="tel" value={phone} onChange={(e) => setPhone(e.target.value)} placeholder="(21) 99999-0000"
          hint="Aparece no seu link público de pedidos." />
        {seg.services.length > 0 && (
          <div className="rounded-2xl bg-white p-4 ring-1 ring-slate-200">
            <Toggle checked={seed} onChange={setSeed} label="Começar com serviços sugeridos" description="Você ajusta preços e nomes depois." />
            {seed && (
              <ul className="mt-3 flex flex-wrap gap-1.5">
                {seg.services.map((s) => (
                  <li key={s.name} className="rounded-full bg-primary-50 px-2.5 py-1 text-xs text-primary-dark">{s.name} · {brl(s.priceCents)}</li>
                ))}
              </ul>
            )}
          </div>
        )}
        {error && <p role="alert" className="rounded-xl bg-rose-50 px-3 py-2.5 text-sm text-rose-700">{error}</p>}
        <button type="submit" disabled={busy || name.trim().length < 2} className="btn btn-primary h-11 w-full">
          {busy && <Spinner />} Criar minha empresa
        </button>
      </form>
      <button type="button" onClick={async () => { await signOut(); router.replace("/entrar"); }}
        className="mx-auto mt-5 flex items-center gap-1.5 text-sm text-slate-500 hover:text-slate-700">
        <LogOut className="h-4 w-4" /> Sair
      </button>
    </AuthLayout>
  );
}
