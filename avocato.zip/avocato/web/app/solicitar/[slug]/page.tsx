"use client";

import { use, useEffect, useState } from "react";
import clsx from "clsx";
import { CheckCircle2, Clock, MessageCircle } from "lucide-react";
import AvocadoMark from "@/components/brand/AvocadoMark";
import { Wordmark } from "@/components/layout/Logo";
import { TextArea, TextField } from "@/components/ui/fields";
import { Spinner } from "@/components/ui/misc";
import { api, ApiError } from "@/lib/api";
import { brl, orderNumber, todayISO, whatsappLink } from "@/lib/format";

type Form = {
  organization: { name: string; slug: string; description: string | null; phone: string | null };
  services: { id: string; name: string; description: string | null; priceCents: number; durationMinutes: number | null }[];
};

function Shell({ children }: { children: React.ReactNode }) {
  return (
    <div className="min-h-screen bg-surface-page">
      <div className="h-40 bg-gradient-to-br from-primary to-primary-darker" />
      <main className="mx-auto -mt-24 max-w-2xl px-4 pb-12">{children}
        <p className="mt-8 flex items-center justify-center gap-1.5 text-xs text-slate-400">Feito com <AvocadoMark size={16} /> <Wordmark className="text-xs" /></p>
      </main>
    </div>
  );
}

/** Página pública: o cliente da empresa pede um serviço sem precisar de conta. */
export default function SolicitarPage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = use(params);
  const [form, setForm] = useState<Form | null>(null);
  const [notFound, setNotFound] = useState(false);
  const [serviceId, setServiceId] = useState("");
  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [email, setEmail] = useState("");
  const [date, setDate] = useState("");
  const [description, setDescription] = useState("");
  const [website, setWebsite] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [done, setDone] = useState<{ number: number } | null>(null);

  useEffect(() => {
    api<Form>(`/public/request-form/${slug}`, { anonymous: true })
      .then((f) => { setForm(f); document.title = `Pedir serviço · ${f.organization.name}`; })
      .catch(() => setNotFound(true));
  }, [slug]);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    if (phone.replace(/\D/g, "").length < 8 && !email.trim()) { setError("Deixe um telefone ou e-mail para a gente te responder."); return; }
    setBusy(true);
    setError(null);
    try {
      const r = await api<{ number: number }>(`/public/requests/${slug}`, {
        method: "POST", anonymous: true,
        body: { name: name.trim(), phone: phone.trim() || undefined, email: email.trim(), serviceId, description: description.trim() || undefined, preferredDate: date, website },
      });
      setDone(r);
    } catch (err) {
      setError(err instanceof ApiError ? (err.status === 429 ? "Muitos pedidos seguidos. Aguarde alguns minutos." : err.message) : "Não foi possível enviar.");
    } finally {
      setBusy(false);
    }
  }


  if (notFound) {
    return <Shell><div className="card p-8 text-center"><AvocadoMark size={56} className="mx-auto" /><h1 className="mt-3 text-lg font-semibold text-slate-800">Página não encontrada</h1><p className="mt-1 text-sm text-slate-500">Este link de pedidos não existe ou foi desativado pela empresa.</p></div></Shell>;
  }
  if (!form) return <Shell><div className="card flex justify-center p-12"><Spinner className="h-6 w-6 text-primary" /></div></Shell>;

  const wa = whatsappLink(form.organization.phone, `Olá! Acabei de enviar a solicitação ${done ? orderNumber(done.number) : ""} pelo site.`);

  if (done) {
    return (
      <Shell>
        <div className="card p-8 text-center">
          <CheckCircle2 className="mx-auto h-14 w-14 text-primary" />
          <h1 className="mt-3 text-xl font-semibold text-slate-800">Pedido enviado!</h1>
          <p className="mt-1 text-slate-600">A {form.organization.name} recebeu sua solicitação <strong>{orderNumber(done.number)}</strong> e vai entrar em contato.</p>
          {wa && <a href={wa} target="_blank" rel="noreferrer" className="btn btn-primary mt-6"><MessageCircle className="h-4 w-4" /> Falar no WhatsApp</a>}
        </div>
      </Shell>
    );
  }

  return (
    <Shell>
      <div className="card p-6 sm:p-8">
        <div className="flex items-center gap-3">
          <span className="inline-flex h-12 w-12 items-center justify-center rounded-2xl bg-primary-50 text-xl font-bold text-primary">{form.organization.name[0]}</span>
          <div>
            <h1 className="text-xl font-semibold text-slate-900">{form.organization.name}</h1>
            <p className="text-sm text-slate-500">Peça seu serviço — respondemos rapidinho.</p>
          </div>
        </div>
        {form.organization.description && <p className="mt-4 whitespace-pre-line text-sm text-slate-600">{form.organization.description}</p>}

        <form onSubmit={submit} className="mt-6 space-y-5">
          {form.services.length > 0 && (
            <fieldset>
              <legend className="field-label">Qual serviço você precisa?</legend>
              <div className="grid gap-2 sm:grid-cols-2">
                {[...form.services, { id: "", name: "Outro / não sei", description: "Descreva abaixo", priceCents: -1, durationMinutes: null }].map((s) => (
                  <button key={s.id || "outro"} type="button" onClick={() => setServiceId(s.id)} aria-pressed={serviceId === s.id}
                    className={clsx("rounded-xl p-3 text-left transition-colors", serviceId === s.id ? "bg-primary-50 ring-2 ring-primary" : "ring-1 ring-slate-200 hover:bg-slate-50")}>
                    <span className="block text-sm font-medium text-slate-800">{s.name}</span>
                    <span className="mt-0.5 flex items-center gap-2 text-xs text-slate-500">
                      {s.priceCents >= 0 && <span className="font-medium text-primary-dark">{s.priceCents > 0 ? `a partir de ${brl(s.priceCents)}` : "sob consulta"}</span>}
                      {s.durationMinutes && <span className="inline-flex items-center gap-0.5"><Clock className="h-3 w-3" />{s.durationMinutes} min</span>}
                      {s.priceCents < 0 && s.description}
                    </span>
                  </button>
                ))}
              </div>
            </fieldset>
          )}
          <TextField label="Seu nome" required minLength={2} autoComplete="name" value={name} onChange={(e) => setName(e.target.value)} />
          <div className="grid gap-4 sm:grid-cols-2">
            <TextField label="WhatsApp / telefone" type="tel" autoComplete="tel" value={phone} onChange={(e) => setPhone(e.target.value)} placeholder="(21) 99999-0000" />
            <TextField label="E-mail" type="email" autoComplete="email" value={email} onChange={(e) => setEmail(e.target.value)} hint="Telefone ou e-mail, pelo menos um." />
          </div>
          <TextField label="Data de preferência" type="date" min={todayISO()} value={date} onChange={(e) => setDate(e.target.value)} />
          <TextArea label="Conte o que precisa" value={description} onChange={(e) => setDescription(e.target.value)} placeholder="Endereço, detalhes do problema, melhor horário…" />
          <div aria-hidden="true" className="absolute -left-[9999px] h-0 w-0 overflow-hidden">
            <label>Site<input tabIndex={-1} autoComplete="off" value={website} onChange={(e) => setWebsite(e.target.value)} /></label>
          </div>
          {error && <p role="alert" className="rounded-xl bg-rose-50 px-3 py-2.5 text-sm text-rose-700">{error}</p>}
          <button type="submit" disabled={busy} className="btn btn-primary h-12 w-full text-base">{busy && <Spinner />} Enviar pedido</button>
          <p className="text-center text-xs text-slate-400">Seus dados são usados só para a {form.organization.name} responder a este pedido.</p>
        </form>
      </div>
    </Shell>
  );
}
