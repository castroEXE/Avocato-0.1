import { createRemoteJWKSet, jwtVerify, type JWTPayload } from "jose";

export type AuthIdentity = { userId: string; email: string | null };

export type TokenVerifier = (token: string) => Promise<AuthIdentity>;

/**
 * Valida o access token emitido pelo Supabase Auth.
 * - Projetos com JWT Signing Keys (padrão atual): chave pública via JWKS.
 * - Projetos com segredo legado (HS256): SUPABASE_JWT_SECRET.
 * A API nunca confia em claims sem verificar assinatura, emissor e audiência.
 */
export function createSupabaseVerifier(opts: { supabaseUrl: string; jwtSecret?: string | undefined }): TokenVerifier {
  const issuer = `${opts.supabaseUrl.replace(/\/$/, "")}/auth/v1`;
  const verify = opts.jwtSecret
    ? (token: string) =>
        jwtVerify(token, new TextEncoder().encode(opts.jwtSecret), { issuer, audience: "authenticated", clockTolerance: 5 })
    : (() => {
        const jwks = createRemoteJWKSet(new URL(`${issuer}/.well-known/jwks.json`));
        return (token: string) => jwtVerify(token, jwks, { issuer, audience: "authenticated", clockTolerance: 5 });
      })();

  return async (token) => {
    const { payload } = await verify(token);
    return toIdentity(payload);
  };
}

const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

function toIdentity(payload: JWTPayload): AuthIdentity {
  if (!payload.sub || !UUID.test(payload.sub)) throw new Error("token sem sub válido");
  const email = typeof payload.email === "string" ? payload.email : null;
  return { userId: payload.sub, email };
}
