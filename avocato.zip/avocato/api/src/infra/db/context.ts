import type pg from "pg";

/** Cliente de banco disponível dentro de uma unidade de trabalho. */
export type Db = Pick<pg.PoolClient, "query">;

export type DbRole = "avocato_app" | "avocato_platform";

export type DbContext = {
  /** null só em rotas públicas (ex.: formulário de solicitação) */
  userId: string | null;
  orgId?: string | null;
  role?: DbRole;
};

const ROLES: ReadonlySet<DbRole> = new Set(["avocato_app", "avocato_platform"]);

/**
 * Abre uma transação com o contexto de segurança do banco:
 *   SET LOCAL ROLE  → papel sem BYPASSRLS (o RLS sempre vale)
 *   app.user_id / app.org_id → lidos pelas policies via app.current_org_id()
 * Tudo é LOCAL: some no COMMIT/ROLLBACK e não vaza entre requisições do pool.
 */
export async function withDbContext<T>(pool: pg.Pool, ctx: DbContext, fn: (db: Db) => Promise<T>): Promise<T> {
  const role = ctx.role ?? "avocato_app";
  if (!ROLES.has(role)) throw new Error(`papel de banco inválido: ${role}`);

  const client = await pool.connect();
  try {
    await client.query("begin");
    await client.query(`set local role ${role}`); // valor vem do allowlist acima
    await client.query("select set_config('app.user_id', $1, true), set_config('app.org_id', $2, true)", [
      ctx.userId ?? "",
      ctx.orgId ?? "",
    ]);
    const result = await fn(client);
    await client.query("commit");
    return result;
  } catch (err) {
    await client.query("rollback").catch(() => undefined);
    throw err;
  } finally {
    client.release();
  }
}
