import pg from "pg";

// int8 e numeric chegam como string por padrão. Centavos cabem com folga
// em Number (até 2^53), então convertemos aqui, uma vez.
pg.types.setTypeParser(pg.types.builtins.INT8, (v) => Number(v));
pg.types.setTypeParser(pg.types.builtins.NUMERIC, (v) => Number(v));
// date puro (vencimentos) fica como texto 'AAAA-MM-DD': sem conversão de fuso
pg.types.setTypeParser(pg.types.builtins.DATE, (v) => v);

export function createPool(connectionString: string, max: number) {
  return new pg.Pool({
    connectionString,
    max,
    idleTimeoutMillis: 30_000,
    connectionTimeoutMillis: 5_000,
    application_name: "avocato-api",
  });
}

export type Pool = pg.Pool;
