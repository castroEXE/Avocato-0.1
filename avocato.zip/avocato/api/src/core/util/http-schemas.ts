import { z } from "zod";

export const IdParams = z.object({ id: z.uuid() });

export const Paging = {
  limit: z.coerce.number().int().min(1).max(200).default(50),
  offset: z.coerce.number().int().min(0).default(0),
};

/** Valores em centavos (inteiros). */
export const Cents = z.number().int().min(0).max(1_000_000_000_00);

export const iso = (d: Date | null | undefined) => (d ? d.toISOString() : null);
export const isoDate = (d: Date | string | null | undefined) => {
  if (!d) return null;
  if (typeof d === "string") return d.slice(0, 10);
  // datas puras (date) chegam como meia-noite local; formata sem converter fuso
  const y = d.getFullYear(), m = String(d.getMonth() + 1).padStart(2, "0"), day = String(d.getDate()).padStart(2, "0");
  return `${y}-${m}-${day}`;
};
