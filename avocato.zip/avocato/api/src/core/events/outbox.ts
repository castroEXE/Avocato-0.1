import type { Db } from "../../infra/db/context.js";
import type { TenantContext } from "../context.js";

export type DomainEvent = {
  type: `${string}.${string}`;   // 'customer.created'
  entityType: string;
  entityId: string | null;
  payload?: Record<string, unknown>;
};

/**
 * Outbox: o evento é gravado na mesma transação da mudança.
 * O motor de automações (Fase 12) consome app.domain_events.
 */
export async function emitEvent(db: Db, ctx: TenantContext, event: DomainEvent): Promise<void> {
  await db.query(
    `insert into app.domain_events (org_id, type, entity_type, entity_id, payload, actor_type, actor_user_id)
     values ($1, $2, $3, $4, $5, $6, $7)`,
    [ctx.orgId, event.type, event.entityType, event.entityId, event.payload ?? {}, ctx.actor, ctx.userId],
  );
}
