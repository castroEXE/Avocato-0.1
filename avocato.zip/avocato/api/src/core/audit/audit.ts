import type { Db } from "../../infra/db/context.js";
import type { TenantContext } from "../context.js";

type Json = Record<string, unknown>;

export type AuditEntry = {
  action: string;          // 'customer.update'
  entityType: string;      // 'customer'
  entityId: string | null;
  before?: Json | null;
  after?: Json | null;
  metadata?: Json;
};

/** Mantém só as chaves que mudaram, para o log mostrar "antes → depois". */
export function diff(before: Json, after: Json): { before: Json; after: Json } {
  const b: Json = {};
  const a: Json = {};
  for (const key of new Set([...Object.keys(before), ...Object.keys(after)])) {
    if (key === "updatedAt" || key === "updated_at") continue;
    if (JSON.stringify(before[key]) !== JSON.stringify(after[key])) {
      b[key] = before[key] ?? null;
      a[key] = after[key] ?? null;
    }
  }
  return { before: b, after: a };
}

/** Grava na mesma transação da mudança: ou os dois acontecem, ou nenhum. */
export async function audit(db: Db, ctx: TenantContext, entry: AuditEntry): Promise<void> {
  await db.query(
    `insert into app.audit_logs (org_id, actor_type, actor_user_id, action, entity_type, entity_id, before, after, metadata)
     values ($1, $2, $3, $4, $5, $6, $7, $8, $9)`,
    [
      ctx.orgId,
      ctx.actor,
      ctx.userId,
      entry.action,
      entry.entityType,
      entry.entityId,
      entry.before ?? null,
      entry.after ?? null,
      { ...ctx.meta, ...entry.metadata },
    ],
  );
}
