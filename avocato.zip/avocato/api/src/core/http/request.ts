import type { FastifyRequest } from "fastify";
import type { AuthIdentity } from "../../infra/auth/jwt.js";
import type { TenantContext } from "../context.js";
import { Errors } from "../errors.js";
import "../../plugins/types.js";

export function authOf(req: FastifyRequest): AuthIdentity {
  if (!req.auth) throw Errors.unauthenticated();
  return req.auth;
}

export function tenantOf(req: FastifyRequest): TenantContext {
  if (!req.tenant) throw Errors.tenantRequired();
  return req.tenant;
}
