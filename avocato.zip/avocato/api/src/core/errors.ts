/** Erro de aplicação com status HTTP e código estável para o frontend. */
export class AppError extends Error {
  constructor(
    public readonly statusCode: number,
    public readonly code: string,
    message: string,
    public readonly details?: unknown,
  ) {
    super(message);
    this.name = "AppError";
  }
}

export const Errors = {
  unauthenticated: () => new AppError(401, "unauthenticated", "Faça login para continuar."),
  forbidden: (permission?: string) =>
    new AppError(403, "forbidden", "Você não tem permissão para esta ação.", permission ? { permission } : undefined),
  noTenant: () =>
    new AppError(403, "tenant_forbidden", "Você não tem acesso a esta empresa ou ela está inativa."),
  tenantRequired: () =>
    new AppError(400, "tenant_required", "Informe a empresa no header X-Organization-Id."),
  notFound: (entity: string) => new AppError(404, "not_found", `${entity} não encontrado.`),
  validation: (details: unknown) => new AppError(400, "validation_error", "Alguns campos estão inválidos.", details),
  conflict: (message: string) => new AppError(409, "conflict", message),
  moduleDisabled: (module: string) =>
    new AppError(403, "module_disabled", `O módulo "${module}" não está ativo para esta empresa.`, { module }),
};

type PgLikeError = { code?: string; constraint?: string };

/** Traduz erros do Postgres em erros de aplicação sem vazar detalhes internos. */
export function fromPgError(err: unknown): AppError | null {
  const e = err as PgLikeError;
  switch (e?.code) {
    case "23505":
      return new AppError(409, "duplicate", "Já existe um registro com esses dados.", { constraint: e.constraint });
    case "23503":
      return new AppError(422, "invalid_reference", "Um dos registros relacionados não existe nesta empresa.", {
        constraint: e.constraint,
      });
    case "23514":
    case "22P02":
    case "22023":
      return new AppError(400, "invalid_value", "Valor inválido.", { constraint: e.constraint });
    case "23P01":
      return new AppError(409, "schedule_conflict", "Esse horário conflita com outro agendamento do mesmo profissional.");
    case "42501":
      return Errors.forbidden();
    default:
      return null;
  }
}
