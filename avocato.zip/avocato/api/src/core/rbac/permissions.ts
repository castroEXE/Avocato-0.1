/**
 * Espelho tipado do catálogo app.permissions (migration 0700).
 * Um teste de integração garante que os dois nunca divergem.
 */
export const PERMISSIONS = [
  "settings.read", "settings.manage", "members.read", "members.manage", "roles.manage",
  "billing.read", "billing.manage", "audit.read", "notifications.read",
  "customers.read", "customers.create", "customers.update", "customers.delete",
  "leads.read", "leads.create", "leads.update", "leads.delete",
  "opportunities.read", "opportunities.create", "opportunities.update", "opportunities.delete", "pipelines.manage",
  "activities.read", "activities.create",
  "tasks.read", "tasks.create", "tasks.update", "tasks.delete",
  "services.read", "services.manage",
  "appointments.read", "appointments.create", "appointments.update", "appointments.delete",
  "service_orders.read", "service_orders.create", "service_orders.update", "service_orders.delete",
  "staff.read", "staff.manage",
  "products.read", "products.manage", "inventory.adjust",
  "suppliers.read", "suppliers.manage",
  "finance.read", "finance.manage", "finance.authorize_payment", "bank_accounts.manage", "integrations.manage",
  "automations.read", "automations.manage",
  "reports.read",
  "documents.read", "documents.manage",
  "ai.use", "ai.approve_actions",
] as const;

export type Permission = (typeof PERMISSIONS)[number];

const KNOWN = new Set<string>(PERMISSIONS);

export function isPermission(value: string): value is Permission {
  return KNOWN.has(value);
}

export const MODULES = [
  "core", "customers", "crm", "services", "appointments", "service_orders", "team", "inventory",
  "suppliers", "finance", "banking", "automation", "reports", "documents", "ai", "fleet",
] as const;

export type ModuleKey = (typeof MODULES)[number];
