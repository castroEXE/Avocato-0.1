import type pg from "pg";
import { withDbContext, type Db } from "../infra/db/context.js";
import { Errors } from "./errors.js";
import type { ModuleKey, Permission } from "./rbac/permissions.js";

export type ActorType = "user" | "ai" | "automation" | "system";

export type RequestMeta = { requestId?: string; ip?: string; userAgent?: string; aiActionId?: string };

/**
 * Contexto de uma operação dentro de uma empresa (tenant).
 * Criado pelo plugin de tenant DEPOIS de o banco confirmar a membership.
 * Serviços de aplicação recebem este objeto — nunca o request do Fastify —
 * para que HTTP, IA e automações passem pelas mesmas regras.
 */
export class TenantContext {
  constructor(
    private readonly pool: pg.Pool,
    readonly userId: string,
    readonly orgId: string,
    readonly permissions: ReadonlySet<Permission>,
    readonly enabledModules: ReadonlySet<ModuleKey>,
    readonly actor: ActorType = "user",
    readonly meta: RequestMeta = {},
  ) {}

  can(permission: Permission): boolean {
    return this.permissions.has(permission);
  }

  /** Lança 403 se faltar a permissão. Serviços chamam isto em toda operação. */
  require(permission: Permission): void {
    if (!this.can(permission)) throw Errors.forbidden(permission);
  }

  /** Lança 403 se o módulo estiver desligado na configuração da empresa. */
  requireModule(module: ModuleKey): void {
    if (!this.enabledModules.has(module)) throw Errors.moduleDisabled(module);
  }

  /** Unidade de trabalho: uma transação com RLS do tenant aplicado. */
  run<T>(fn: (db: Db) => Promise<T>): Promise<T> {
    return withDbContext(this.pool, { userId: this.userId, orgId: this.orgId, role: "avocato_app" }, fn);
  }

  /** Mesmo usuário e empresa, agindo como outro ator (ex.: IA). */
  as(actor: ActorType, meta: RequestMeta = {}): TenantContext {
    return new TenantContext(this.pool, this.userId, this.orgId, this.permissions, this.enabledModules, actor, {
      ...this.meta,
      ...meta,
    });
  }
}
