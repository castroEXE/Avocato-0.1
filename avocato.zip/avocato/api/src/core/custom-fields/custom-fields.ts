import { z } from "zod";
import type { Db } from "../../infra/db/context.js";
import { Errors } from "../errors.js";

export type CustomFieldEntity =
  | "customer" | "lead" | "opportunity" | "service" | "product"
  | "appointment" | "service_order" | "staff_member" | "supplier";

export type CustomFieldDefinition = {
  key: string;
  label: string;
  fieldType:
    | "text" | "long_text" | "number" | "currency" | "date" | "boolean"
    | "select" | "multi_select" | "phone" | "email" | "url";
  options: string[];
  isRequired: boolean;
};

function schemaFor(def: CustomFieldDefinition): z.ZodType {
  switch (def.fieldType) {
    case "text": return z.string().max(500);
    case "long_text": return z.string().max(5000);
    case "phone": return z.string().max(40);
    case "number": return z.number().finite();
    case "currency": return z.number().int(); // centavos
    case "date": return z.iso.date();
    case "boolean": return z.boolean();
    case "email": return z.email();
    case "url": return z.url();
    case "select": return z.enum(def.options as [string, ...string[]]);
    case "multi_select": return z.array(z.enum(def.options as [string, ...string[]])).max(50);
  }
}

/**
 * Valida campos personalizados contra as definições da empresa.
 * Função pura (sem banco) para ser testável e reutilizável.
 *   mode 'create' → exige os obrigatórios
 *   mode 'patch'  → valida só o que veio
 */
export function validateCustomFields(
  defs: CustomFieldDefinition[],
  input: Record<string, unknown> | undefined,
  mode: "create" | "patch",
): Record<string, unknown> {
  const values = input ?? {};
  const byKey = new Map(defs.map((d) => [d.key, d]));
  const issues: { field: string; message: string }[] = [];
  const out: Record<string, unknown> = {};

  for (const [key, value] of Object.entries(values)) {
    const def = byKey.get(key);
    if (!def) {
      issues.push({ field: `customFields.${key}`, message: "Campo personalizado não existe para esta empresa." });
      continue;
    }
    if (value === null) {
      if (def.isRequired) issues.push({ field: `customFields.${key}`, message: `${def.label} é obrigatório.` });
      else out[key] = null;
      continue;
    }
    const parsed = schemaFor(def).safeParse(value);
    if (parsed.success) out[key] = parsed.data;
    else issues.push({ field: `customFields.${key}`, message: `${def.label}: valor inválido.` });
  }

  if (mode === "create") {
    for (const def of defs) {
      if (def.isRequired && !(def.key in values)) {
        issues.push({ field: `customFields.${def.key}`, message: `${def.label} é obrigatório.` });
      }
    }
  }

  if (issues.length) throw Errors.validation(issues);
  return out;
}

export async function loadCustomFieldDefinitions(
  db: Db,
  orgId: string,
  entity: CustomFieldEntity,
): Promise<CustomFieldDefinition[]> {
  const { rows } = await db.query<{
    key: string; label: string; field_type: CustomFieldDefinition["fieldType"]; options: string[]; is_required: boolean;
  }>(
    `select key, label, field_type, options, is_required
       from app.custom_field_definitions
      where org_id = $1 and entity = $2 and is_active
      order by position, key`,
    [orgId, entity],
  );
  return rows.map((r) => ({
    key: r.key, label: r.label, fieldType: r.field_type, options: r.options, isRequired: r.is_required,
  }));
}
