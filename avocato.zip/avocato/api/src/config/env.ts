import { z } from "zod";

const EnvSchema = z.object({
  NODE_ENV: z.enum(["development", "test", "production"]).default("development"),
  HOST: z.string().default("0.0.0.0"),
  PORT: z.coerce.number().int().positive().default(3333),
  LOG_LEVEL: z.enum(["fatal", "error", "warn", "info", "debug", "trace", "silent"]).default("info"),
  DATABASE_URL: z.string().url(),
  DB_POOL_MAX: z.coerce.number().int().min(1).max(100).default(10),
  SUPABASE_URL: z.string().url(),
  SUPABASE_JWT_SECRET: z.string().optional().transform((v) => (v ? v : undefined)),
  CORS_ORIGINS: z
    .string()
    .default("")
    .transform((v) => v.split(",").map((s) => s.trim()).filter(Boolean)),
  RATE_LIMIT_MAX: z.coerce.number().int().positive().default(300),
  // IA (APIs gratuitas compatíveis com o formato OpenAI: Groq ou Google Gemini)
  AI_PROVIDER: z.enum(["groq", "gemini", "openai_compatible"]).default("groq"),
  AI_API_KEY: z.string().optional().transform((v) => (v ? v : undefined)),
  AI_MODEL: z.string().optional().transform((v) => (v ? v : undefined)),
  AI_BASE_URL: z.string().url().optional().or(z.literal("").transform(() => undefined)),
});

export type Env = z.infer<typeof EnvSchema>;

/** Valida as variáveis de ambiente uma vez, na subida. Falha cedo e alto. */
export function loadEnv(source: NodeJS.ProcessEnv = process.env): Env {
  const parsed = EnvSchema.safeParse(source);
  if (!parsed.success) {
    const issues = parsed.error.issues.map((i) => `  - ${i.path.join(".")}: ${i.message}`).join("\n");
    throw new Error(`Variáveis de ambiente inválidas:\n${issues}`);
  }
  return parsed.data;
}
