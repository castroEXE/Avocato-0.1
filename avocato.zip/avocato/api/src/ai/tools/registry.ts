import { randomUUID } from "node:crypto";
import { z } from "zod";
import type { TenantContext } from "../../core/context.js";
import { AppError, Errors } from "../../core/errors.js";
import type { AiActionStore } from "./action-store.js";
import type { ToolDefinition } from "./tool.js";

export type ToolCallResult =
  | { status: "executed"; actionId: string; output: unknown }
  | { status: "awaiting_approval"; actionId: string; summary: string }
  | { status: "invalid_input"; issues: { path: string; message: string }[] }
  | { status: "failed"; actionId: string; error: string };

/** Formato aceito pela Messages API da Anthropic (campo `tools`). */
export type ModelToolSpec = { name: string; description: string; input_schema: Record<string, unknown> };

/**
 * Catálogo de ferramentas da IA + política de execução:
 *   • precisa de ai.use e da permissão da própria tool
 *   • entrada validada com Zod (erros voltam ao modelo para ele corrigir)
 *   • risco 'low' executa e registra; 'sensitive' para em awaiting_approval
 *   • toda chamada vira uma linha em ai_actions
 */
export class ToolRegistry {
  private readonly tools = new Map<string, ToolDefinition>();

  constructor(private readonly store: AiActionStore) {}

  register(...defs: ToolDefinition[]): this {
    for (const d of defs) {
      if (this.tools.has(d.name)) throw new Error(`tool duplicada: ${d.name}`);
      this.tools.set(d.name, d);
    }
    return this;
  }

  /** Só as tools que ESTE usuário pode usar e cujo módulo está ativo. */
  /** Frase legível de uma ação (para listar pendências na tela). */
  describe(toolName: string, input: unknown): string {
    const tool = this.tools.get(toolName);
    if (!tool) return toolName;
    const parsed = tool.input.safeParse(input);
    return parsed.success ? tool.summarize(parsed.data) : toolName;
  }

  specsFor(ctx: TenantContext): ModelToolSpec[] {
    if (!ctx.can("ai.use")) return [];
    return [...this.tools.values()]
      .filter((t) => ctx.can(t.permission))
      .map((t) => ({
        name: t.name,
        description: t.risk === "sensitive" ? `${t.description} (Requer aprovação humana antes de executar.)` : t.description,
        input_schema: z.toJSONSchema(t.input, { io: "input" }) as Record<string, unknown>,
      }));
  }

  async invoke(ctx: TenantContext, name: string, rawInput: unknown, opts: { conversationId?: string | null } = {}): Promise<ToolCallResult> {
    ctx.require("ai.use");
    const tool = this.tools.get(name);
    if (!tool) throw new AppError(404, "tool_not_found", `Ferramenta "${name}" não existe.`);
    ctx.require(tool.permission);

    const parsed = tool.input.safeParse(rawInput);
    if (!parsed.success) {
      return {
        status: "invalid_input",
        issues: parsed.error.issues.map((i) => ({ path: i.path.join("."), message: i.message })),
      };
    }

    const actionId = randomUUID();
    const base = {
      id: actionId, toolName: name, input: parsed.data, riskLevel: tool.risk, requestedBy: ctx.userId,
      conversationId: opts.conversationId ?? null, error: null, output: null,
    };

    if (tool.risk === "sensitive") {
      await this.store.create(ctx, { ...base, status: "awaiting_approval" });
      return { status: "awaiting_approval", actionId, summary: tool.summarize(parsed.data) };
    }

    try {
      const output = await tool.execute(ctx.as("ai", { aiActionId: actionId }), parsed.data);
      await this.store.create(ctx, { ...base, status: "executed", output });
      return { status: "executed", actionId, output };
    } catch (err) {
      const message = err instanceof AppError ? err.message : "Falha ao executar a ação.";
      await this.store.create(ctx, { ...base, status: "failed", error: message });
      if (err instanceof AppError && err.statusCode < 500) return { status: "failed", actionId, error: message };
      throw err;
    }
  }

  /** Humano aprova uma ação sensível. Quem aprova também precisa da permissão da tool. */
  async approve(ctx: TenantContext, actionId: string): Promise<ToolCallResult> {
    ctx.require("ai.approve_actions");
    const decided = await this.store.decide(ctx, actionId, "approved");
    if (!decided) throw Errors.notFound("Ação pendente");

    const tool = this.tools.get(decided.toolName);
    if (!tool) {
      await this.store.finish(ctx, actionId, { status: "failed", error: "Ferramenta removida." });
      return { status: "failed", actionId, error: "Ferramenta removida." };
    }
    try {
      ctx.require(tool.permission);
      const input = tool.input.parse(decided.input);
      const output = await tool.execute(ctx.as("ai", { aiActionId: actionId }), input);
      await this.store.finish(ctx, actionId, { status: "executed", output });
      return { status: "executed", actionId, output };
    } catch (err) {
      const message = err instanceof AppError ? err.message : "Falha ao executar a ação.";
      await this.store.finish(ctx, actionId, { status: "failed", error: message });
      if (err instanceof AppError) throw err;
      throw err;
    }
  }

  async reject(ctx: TenantContext, actionId: string): Promise<void> {
    ctx.require("ai.approve_actions");
    const decided = await this.store.decide(ctx, actionId, "rejected");
    if (!decided) throw Errors.notFound("Ação pendente");
  }
}
