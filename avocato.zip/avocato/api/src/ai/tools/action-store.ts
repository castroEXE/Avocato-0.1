import type { TenantContext } from "../../core/context.js";
import type { ToolRisk } from "./tool.js";

export type AiActionStatus = "awaiting_approval" | "approved" | "rejected" | "executed" | "failed";

export type AiActionRecord = {
  id: string;
  toolName: string;
  input: unknown;
  output: unknown;
  riskLevel: ToolRisk;
  status: AiActionStatus;
  requestedBy: string;
  conversationId: string | null;
  error: string | null;
  createdAt: string;
};

/** Persistência das ações da IA. Interface para permitir teste sem banco. */
export interface AiActionStore {
  create(ctx: TenantContext, a: Omit<AiActionRecord, "createdAt">): Promise<void>;
  /** Passa de awaiting_approval para approved/rejected de forma atômica. */
  decide(ctx: TenantContext, id: string, decision: "approved" | "rejected"): Promise<AiActionRecord | null>;
  finish(ctx: TenantContext, id: string, r: { status: "executed" | "failed"; output?: unknown; error?: string }): Promise<void>;
  list(ctx: TenantContext, f: { status?: AiActionStatus; limit: number }): Promise<AiActionRecord[]>;
}

type Row = {
  id: string; tool_name: string; input: unknown; output: unknown; risk_level: ToolRisk; status: AiActionStatus;
  requested_by: string; conversation_id: string | null; error: string | null; created_at: Date;
};

const toRecord = (r: Row): AiActionRecord => ({
  id: r.id, toolName: r.tool_name, input: r.input, output: r.output, riskLevel: r.risk_level, status: r.status,
  requestedBy: r.requested_by, conversationId: r.conversation_id, error: r.error, createdAt: r.created_at.toISOString(),
});

export const pgAiActionStore: AiActionStore = {
  async create(ctx, a) {
    await ctx.run((db) => db.query(
      `insert into app.ai_actions (id, org_id, conversation_id, tool_name, input, output, risk_level, status, requested_by, error,
                                   executed_at)
       values ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, case when $8 = 'executed' then now() end)`,
      [a.id, ctx.orgId, a.conversationId, a.toolName, JSON.stringify(a.input), a.output === undefined ? null : JSON.stringify(a.output),
        a.riskLevel, a.status, a.requestedBy, a.error],
    ));
  },
  async decide(ctx, id, decision) {
    const { rows } = await ctx.run((db) => db.query<Row>(
      `update app.ai_actions set status = $3, decided_by = $4, decided_at = now()
        where org_id = $1 and id = $2 and status = 'awaiting_approval'
        returning *`,
      [ctx.orgId, id, decision, ctx.userId],
    ));
    return rows[0] ? toRecord(rows[0]) : null;
  },
  async finish(ctx, id, r) {
    await ctx.run((db) => db.query(
      `update app.ai_actions set status = $3, output = $4, error = $5, executed_at = case when $3 = 'executed' then now() end
        where org_id = $1 and id = $2`,
      [ctx.orgId, id, r.status, r.output === undefined ? null : JSON.stringify(r.output), r.error ?? null],
    ));
  },
  async list(ctx, f) {
    const { rows } = await ctx.run((db) => db.query<Row>(
      `select * from app.ai_actions where org_id = $1 and ($2::text is null or status = $2)
        order by created_at desc limit $3`,
      [ctx.orgId, f.status ?? null, f.limit],
    ));
    return rows.map(toRecord);
  },
};
