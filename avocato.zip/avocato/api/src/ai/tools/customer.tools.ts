import { z } from "zod";
import { CustomerService } from "../../modules/customers/customer.service.js";
import { defineTool } from "./tool.js";

export const createCustomerTool = defineTool({
  name: "create_customer",
  description:
    "Cadastra um novo cliente da empresa. Use quando o usuário pedir para cadastrar/registrar um cliente. " +
    "Telefone com DDD, só dígitos. Antes de criar, se houver risco de duplicidade, use search_customers.",
  permission: "customers.create",
  risk: "low",
  input: z.object({
    name: z.string().min(1).max(200).describe("Nome completo do cliente"),
    phone: z.string().max(40).optional().describe("Telefone com DDD"),
    email: z.email().optional(),
    notes: z.string().max(2000).optional(),
    customFields: z.record(z.string(), z.unknown()).optional().describe("Campos personalizados da empresa (ex.: nome do pet)"),
  }),
  summarize: (i) => `Cadastrar o cliente ${i.name}`,
  execute: async (ctx, i) => {
    const c = await CustomerService.create(ctx, {
      name: i.name, phone: i.phone ?? null, email: i.email ?? null, notes: i.notes ?? null,
      source: "ai_assistant", customFields: i.customFields ?? {},
    });
    return { id: c.id, name: c.name, phone: c.phone, email: c.email };
  },
});

export const searchCustomersTool = defineTool({
  name: "search_customers",
  description:
    "Busca clientes por nome, e-mail, telefone ou documento. Com inactive_days, lista clientes sem compra há X dias (clientes sumidos).",
  permission: "customers.read",
  risk: "low",
  input: z.object({
    query: z.string().max(100).optional(),
    inactive_days: z.number().int().min(1).max(3650).optional(),
    limit: z.number().int().min(1).max(50).default(10),
  }),
  summarize: (i) => (i.inactive_days ? `Listar clientes sem compra há ${i.inactive_days} dias` : `Buscar clientes "${i.query ?? ""}"`),
  execute: async (ctx, i) => {
    const r = await CustomerService.list(ctx, { q: i.query, inactiveDays: i.inactive_days, limit: i.limit });
    return {
      total: r.total,
      customers: r.data.map((c) => ({ id: c.id, name: c.name, phone: c.phone, email: c.email, lastPurchaseAt: c.lastPurchaseAt })),
    };
  },
});

export const deleteCustomerTool = defineTool({
  name: "delete_customer",
  description: "Remove um cliente. Exclusão é ação sensível.",
  permission: "customers.delete",
  risk: "sensitive",
  input: z.object({ customer_id: z.uuid(), reason: z.string().min(3).max(300) }),
  summarize: (i) => `Excluir o cliente ${i.customer_id} (motivo: ${i.reason})`,
  execute: async (ctx, i) => {
    await CustomerService.remove(ctx, i.customer_id);
    return { deleted: true, id: i.customer_id };
  },
});
