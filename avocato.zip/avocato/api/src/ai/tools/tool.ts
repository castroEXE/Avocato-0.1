import type { z } from "zod";
import type { TenantContext } from "../../core/context.js";
import type { Permission } from "../../core/rbac/permissions.js";

/**
 * Ferramenta que a IA pode chamar. É a ÚNICA porta da IA para o sistema:
 *   IA → Tool → Application Service → Repository → PostgreSQL
 * A tool nunca escreve SQL: ela chama um serviço, que aplica permissão,
 * validação, auditoria e eventos exatamente como numa chamada HTTP.
 */
export type ToolRisk = "low" | "sensitive";

export type ToolDefinition<I extends z.ZodType = z.ZodType, O = unknown> = {
  name: string;                  // snake_case, estável (o modelo usa este nome)
  description: string;           // instrução para o modelo
  input: I;
  permission: Permission;        // a IA nunca faz mais do que o usuário pode
  risk: ToolRisk;                // 'sensitive' sempre para em aprovação humana
  /** Frase curta para o usuário entender o que será feito (cartão de aprovação). */
  // sintaxe de método de propósito: permite guardar tools com entradas
  // diferentes no mesmo registro sem perder a tipagem de cada uma
  summarize(input: z.infer<I>): string;
  execute(ctx: TenantContext, input: z.infer<I>): Promise<O>;
};

export function defineTool<I extends z.ZodType, O>(def: ToolDefinition<I, O>): ToolDefinition<I, O> {
  if (!/^[a-z][a-z0-9_]{2,63}$/.test(def.name)) throw new Error(`nome de tool inválido: ${def.name}`);
  return def;
}
