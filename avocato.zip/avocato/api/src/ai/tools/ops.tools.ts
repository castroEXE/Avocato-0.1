import { z } from "zod";
import { DashboardService } from "../../modules/dashboard/dashboard.service.js";
import { FinanceService } from "../../modules/finance/finance.service.js";
import { AppointmentService } from "../../modules/appointments/appointment.service.js";
import { ServiceOrderService } from "../../modules/service-orders/service-order.service.js";
import { ServiceService } from "../../modules/services/service.service.js";
import { StaffService } from "../../modules/staff/staff.service.js";
import { defineTool } from "./tool.js";

/** A IA fala em reais; o sistema guarda centavos. */
const toCents = (reais: number) => Math.round(reais * 100);
const toReais = (cents: number | null | undefined) => (cents == null ? null : cents / 100);
const Reais = z.number().min(0).max(10_000_000);

export const listServicesTool = defineTool({
  name: "list_services",
  description: "Lista os serviços cadastrados (id, nome, preço em reais, duração). Use para achar o service_id antes de criar OS ou agendamento.",
  permission: "services.read",
  risk: "low",
  input: z.object({ query: z.string().max(100).optional() }),
  summarize: () => "Listar serviços",
  execute: async (ctx, i) => {
    const r = await ServiceService.list(ctx, { q: i.query });
    return r.data.map((s) => ({ id: s.id, name: s.name, price: toReais(s.priceCents), durationMinutes: s.durationMinutes, active: s.isActive }));
  },
});

export const createServiceTool = defineTool({
  name: "create_service",
  description: "Cadastra um serviço no catálogo. Valores em reais (ex.: 150.5). commission_percent de 0 a 100.",
  permission: "services.manage",
  risk: "low",
  input: z.object({
    name: z.string().min(1).max(160),
    price: Reais,
    cost: Reais.optional(),
    commission_percent: z.number().min(0).max(100).optional(),
    duration_minutes: z.number().int().min(5).max(1440).optional(),
    description: z.string().max(1000).optional(),
  }),
  summarize: (i) => `Cadastrar o serviço ${i.name}`,
  execute: async (ctx, i) => {
    const s = await ServiceService.create(ctx, {
      name: i.name, priceCents: toCents(i.price), costCents: toCents(i.cost ?? 0), commissionRate: (i.commission_percent ?? 0) / 100,
      durationMinutes: i.duration_minutes ?? null, description: i.description ?? null,
    });
    return { id: s.id, name: s.name, price: toReais(s.priceCents), margin: toReais(s.marginCents) };
  },
});

export const listStaffTool = defineTool({
  name: "list_staff",
  description: "Lista funcionários e prestadores ativos (id, nome, cargo). Use para atribuir um profissional.",
  permission: "staff.read",
  risk: "low",
  input: z.object({}),
  summarize: () => "Listar equipe",
  execute: async (ctx) => (await StaffService.list(ctx, {})).data.map((s) => ({ id: s.id, name: s.name, kind: s.kind, jobTitle: s.jobTitle })),
});

export const createServiceOrderTool = defineTool({
  name: "create_service_order",
  description:
    "Abre uma ordem de serviço (OS). Precisa do customer_id (use search_customers ou create_customer antes). " +
    "Itens: use service_id do catálogo (list_services) ou uma descrição livre com preço em reais.",
  permission: "service_orders.create",
  risk: "low",
  input: z.object({
    customer_id: z.uuid(),
    items: z.array(z.object({
      service_id: z.uuid().optional(),
      description: z.string().max(200).optional(),
      quantity: z.number().positive().max(1000).optional(),
      price: Reais.optional(),
    })).max(20).default([]),
    description: z.string().max(2000).optional(),
    staff_id: z.uuid().optional(),
    scheduled_for: z.iso.datetime({ offset: true }).optional().describe("Data e hora com fuso, ex.: 2026-10-05T14:00:00-03:00"),
  }),
  summarize: (i) => `Abrir OS para o cliente ${i.customer_id}`,
  execute: async (ctx, i) => {
    const o = await ServiceOrderService.create(ctx, {
      customerId: i.customer_id, staffId: i.staff_id ?? null, description: i.description ?? null, scheduledFor: i.scheduled_for ?? null,
      items: i.items.map((it) => ({
        serviceId: it.service_id ?? null, description: it.description ?? null, quantity: it.quantity ?? 1,
        unitPriceCents: it.price !== undefined ? toCents(it.price) : null,
      })),
    }, "ai");
    return { id: o.id, number: o.number, status: o.status, total: toReais(o.totalCents), customer: o.customer.name };
  },
});

export const listServiceOrdersTool = defineTool({
  name: "list_service_orders",
  description: "Lista ordens de serviço. status: requested (solicitadas), active (em aberto), open, scheduled, in_progress, done, canceled.",
  permission: "service_orders.read",
  risk: "low",
  input: z.object({
    status: z.enum(["requested", "active", "open", "scheduled", "in_progress", "done", "canceled"]).optional(),
    query: z.string().max(100).optional(),
    limit: z.number().int().min(1).max(30).default(10),
  }),
  summarize: () => "Listar ordens de serviço",
  execute: async (ctx, i) => {
    const r = await ServiceOrderService.list(ctx, { status: i.status, q: i.query, limit: i.limit });
    return {
      total: r.total,
      orders: r.data.map((o) => ({ id: o.id, number: o.number, title: o.title, status: o.status, customer: o.customer.name,
        staff: o.staff?.name ?? null, total: toReais(o.totalCents), scheduledFor: o.scheduledFor })),
    };
  },
});

export const updateServiceOrderStatusTool = defineTool({
  name: "update_service_order_status",
  description: "Muda o status de uma OS: open (aprovar solicitação), scheduled, in_progress (iniciar) ou done (concluir; gera a conta a receber). Para cancelar use cancel_service_order.",
  permission: "service_orders.update",
  risk: "low",
  input: z.object({ order_id: z.uuid(), status: z.enum(["open", "scheduled", "in_progress", "done"]), note: z.string().max(500).optional() }),
  summarize: (i) => `Mudar a OS ${i.order_id} para ${i.status}`,
  execute: async (ctx, i) => {
    const o = await ServiceOrderService.changeStatus(ctx, i.order_id, { status: i.status, note: i.note });
    return { id: o.id, number: o.number, status: o.status };
  },
});

export const cancelServiceOrderTool = defineTool({
  name: "cancel_service_order",
  description: "Cancela uma ordem de serviço (cancela também a conta a receber em aberto).",
  permission: "service_orders.update",
  risk: "sensitive",
  input: z.object({ order_id: z.uuid(), reason: z.string().min(3).max(500) }),
  summarize: (i) => `Cancelar a OS ${i.order_id} (motivo: ${i.reason})`,
  execute: async (ctx, i) => {
    const o = await ServiceOrderService.changeStatus(ctx, i.order_id, { status: "canceled", note: i.reason });
    return { id: o.id, number: o.number, status: o.status };
  },
});

export const createAppointmentTool = defineTool({
  name: "create_appointment",
  description: "Cria um agendamento. starts_at com fuso (ex.: 2026-10-05T14:00:00-03:00). Se o serviço tiver duração, ela é usada.",
  permission: "appointments.create",
  risk: "low",
  input: z.object({
    customer_id: z.uuid(),
    starts_at: z.iso.datetime({ offset: true }),
    service_id: z.uuid().optional(),
    staff_id: z.uuid().optional(),
    duration_minutes: z.number().int().min(5).max(1440).optional(),
    notes: z.string().max(1000).optional(),
  }),
  summarize: (i) => `Agendar para ${i.starts_at}`,
  execute: async (ctx, i) => {
    const a = await AppointmentService.create(ctx, {
      customerId: i.customer_id, startsAt: i.starts_at, serviceId: i.service_id ?? null, staffId: i.staff_id ?? null,
      durationMinutes: i.duration_minutes ?? null, notes: i.notes ?? null,
    });
    return { id: a.id, startsAt: a.startsAt, endsAt: a.endsAt, customer: a.customer.name, service: a.service?.name ?? null, staff: a.staff?.name ?? null };
  },
});

export const listAppointmentsTool = defineTool({
  name: "list_appointments",
  description: "Lista agendamentos num período (padrão: hoje até 7 dias). Datas com fuso.",
  permission: "appointments.read",
  risk: "low",
  input: z.object({ from: z.iso.datetime({ offset: true }).optional(), to: z.iso.datetime({ offset: true }).optional() }),
  summarize: () => "Listar agenda",
  execute: async (ctx, i) => {
    const from = i.from ?? new Date(new Date().setHours(0, 0, 0, 0)).toISOString();
    const to = i.to ?? new Date(Date.now() + 7 * 864e5).toISOString();
    return (await AppointmentService.list(ctx, { from, to })).data.map((a) => ({
      id: a.id, startsAt: a.startsAt, status: a.status, customer: a.customer.name, service: a.service?.name ?? null, staff: a.staff?.name ?? null,
    }));
  },
});

export const createFinancialEntryTool = defineTool({
  name: "create_financial_entry",
  description:
    "Registra uma conta a receber (type=receita) ou a pagar (type=despesa). Valor em reais, vencimento AAAA-MM-DD. " +
    "recurrence monthly para contas fixas (aluguel, internet). installments para parcelar.",
  permission: "finance.manage",
  risk: "low",
  input: z.object({
    type: z.enum(["receita", "despesa"]),
    description: z.string().min(1).max(200),
    amount: Reais.refine((v) => v > 0),
    due_date: z.iso.date(),
    recurrence: z.enum(["none", "weekly", "monthly", "yearly"]).default("none"),
    installments: z.number().int().min(1).max(48).default(1),
  }),
  summarize: (i) => `Lançar ${i.type} "${i.description}" de R$ ${i.amount.toFixed(2)}`,
  execute: async (ctx, i) => {
    const e = await FinanceService.create(ctx, {
      direction: i.type === "receita" ? "in" : "out", description: i.description, amountCents: toCents(i.amount),
      dueOn: i.due_date, recurrence: i.recurrence, installments: i.installments,
    });
    return { id: e.id, description: e.description, amount: toReais(e.amountCents), dueOn: e.dueOn };
  },
});

export const listFinancialEntriesTool = defineTool({
  name: "list_financial_entries",
  description: "Lista contas a receber/pagar. status: open, overdue (vencidas), paid.",
  permission: "finance.read",
  risk: "low",
  input: z.object({ type: z.enum(["receita", "despesa"]).optional(), status: z.enum(["open", "overdue", "paid"]).default("open") }),
  summarize: () => "Listar lançamentos financeiros",
  execute: async (ctx, i) => {
    const r = await FinanceService.list(ctx, { direction: i.type ? (i.type === "receita" ? "in" : "out") : undefined, status: i.status, limit: 30 });
    return r.data.map((e) => ({ id: e.id, type: e.direction === "in" ? "receita" : "despesa", description: e.description,
      amount: toReais(e.amountCents - e.paidAmountCents), dueOn: e.dueOn, overdue: e.isOverdue, customer: e.customer?.name ?? null }));
  },
});

export const markEntryPaidTool = defineTool({
  name: "mark_entry_paid",
  description: "Registra o pagamento/recebimento de um lançamento financeiro (baixa).",
  permission: "finance.manage",
  risk: "sensitive",
  input: z.object({ entry_id: z.uuid(), amount: Reais.optional() }),
  summarize: (i) => `Dar baixa no lançamento ${i.entry_id}${i.amount ? ` (R$ ${i.amount.toFixed(2)})` : ""}`,
  execute: async (ctx, i) => {
    const e = await FinanceService.pay(ctx, i.entry_id, { amountCents: i.amount !== undefined ? toCents(i.amount) : undefined });
    return { id: e.id, status: e.status, paid: toReais(e.paidAmountCents) };
  },
});

export const businessSummaryTool = defineTool({
  name: "business_summary",
  description: "Resumo do negócio: faturamento do mês, contas em aberto e vencidas, OS solicitadas/ativas, clientes, agenda de hoje e serviços mais vendidos.",
  permission: "reports.read",
  risk: "low",
  input: z.object({}),
  summarize: () => "Gerar resumo do negócio",
  execute: async (ctx) => {
    const d = await DashboardService.summary(ctx);
    return {
      recebidoNoMes: toReais(d.finance?.receivedMonthCents), pagoNoMes: toReais(d.finance?.paidMonthCents),
      aReceber: toReais(d.finance?.receivableOpenCents), aReceberVencido: toReais(d.finance?.receivableOverdueCents),
      aPagar: toReais(d.finance?.payableOpenCents), aPagarVencido: toReais(d.finance?.payableOverdueCents),
      osSolicitadas: d.orders.requested, osAtivas: d.orders.active, osConcluidasNoMes: d.orders.doneThisMonth,
      clientes: d.customers.total, clientesNovosNoMes: d.customers.newThisMonth, agendamentosHoje: d.todayAppointments,
      avaliacaoMedia: d.averageRating,
      servicosMaisVendidos: d.topServices.map((s) => ({ nome: s.name, quantidade: s.quantity, receita: toReais(s.revenueCents) })),
    };
  },
});

export const opsTools = [
  listServicesTool, createServiceTool, listStaffTool, createServiceOrderTool, listServiceOrdersTool, updateServiceOrderStatusTool,
  cancelServiceOrderTool, createAppointmentTool, listAppointmentsTool, createFinancialEntryTool, listFinancialEntriesTool,
  markEntryPaidTool, businessSummaryTool,
];
