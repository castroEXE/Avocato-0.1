import type { FastifyPluginAsyncZod } from "fastify-type-provider-zod";
import { z } from "zod";
import { tenantOf } from "../core/http/request.js";
import { ChatSchema, type Assistant } from "./assistant.js";
import type { AiActionStore } from "./tools/action-store.js";
import type { ToolRegistry } from "./tools/registry.js";

/** Chat com o assistente + governança (aprovação humana das ações sensíveis). */
export const aiRoutes = (registry: ToolRegistry, store: AiActionStore, assistant: Assistant): FastifyPluginAsyncZod => async (app) => {
  const config = { tenant: true };
  const IdParams = z.object({ id: z.uuid() });

  app.get("/ai/status", { config }, () => assistant.status());

  app.post("/ai/chat", { config: { ...config, rateLimit: { max: 20, timeWindow: "1 minute" } }, schema: { body: ChatSchema } },
    (req) => assistant.chat(tenantOf(req), req.body));

  app.get("/ai/conversations", { config }, (req) => assistant.conversations(tenantOf(req)));
  app.get("/ai/conversations/:id", { config, schema: { params: IdParams } }, (req) => assistant.messages(tenantOf(req), req.params.id));

  app.get("/ai/tools", { config }, (req) => ({ tools: registry.specsFor(tenantOf(req)) }));

  app.get("/ai/actions", {
    config,
    schema: {
      querystring: z.object({
        status: z.enum(["awaiting_approval", "approved", "rejected", "executed", "failed"]).optional(),
        limit: z.coerce.number().int().min(1).max(100).default(25),
      }),
    },
  }, async (req) => {
    const ctx = tenantOf(req);
    ctx.require("ai.use");
    const rows = await store.list(ctx, req.query);
    return { data: rows.map((r) => ({ ...r, summary: registry.describe(r.toolName, r.input) })) };
  });

  app.post("/ai/actions/:id/approve", { config, schema: { params: IdParams } }, (req) => registry.approve(tenantOf(req), req.params.id));

  app.post("/ai/actions/:id/reject", { config, schema: { params: IdParams } }, async (req, reply) => {
    await registry.reject(tenantOf(req), req.params.id);
    return reply.status(204).send();
  });
};
