import type { Env } from "../config/env.js";

/**
 * Cliente de chat no formato OpenAI (/chat/completions), que é aceito
 * pelos planos gratuitos do Groq e do Google Gemini. Trocar de provedor
 * é só mudar variáveis de ambiente.
 */
export type ToolCall = { id: string; type: "function"; function: { name: string; arguments: string } };

export type ChatMessage =
  | { role: "system" | "user"; content: string }
  | { role: "assistant"; content: string | null; tool_calls?: ToolCall[] }
  | { role: "tool"; tool_call_id: string; content: string };

export type ChatTool = { type: "function"; function: { name: string; description: string; parameters: Record<string, unknown> } };

export type LlmResponse = {
  message: { content: string | null; tool_calls?: ToolCall[] };
  usage: { inputTokens: number; outputTokens: number };
  model: string;
};

export type LlmClient = {
  provider: string;
  model: string;
  chat(req: { messages: ChatMessage[]; tools: ChatTool[] }): Promise<LlmResponse>;
};

const DEFAULTS = {
  groq: { baseUrl: "https://api.groq.com/openai/v1", model: "llama-3.3-70b-versatile" },
  gemini: { baseUrl: "https://generativelanguage.googleapis.com/v1beta/openai", model: "gemini-2.5-flash" },
  openai_compatible: { baseUrl: "", model: "" },
} as const;

export class LlmError extends Error {
  constructor(message: string, readonly status?: number) {
    super(message);
  }
}

export function createLlmClient(
  env: Pick<Env, "AI_PROVIDER" | "AI_API_KEY" | "AI_MODEL" | "AI_BASE_URL">,
  fetchImpl: typeof fetch = fetch,
): LlmClient | null {
  if (!env.AI_API_KEY) return null;
  const d = DEFAULTS[env.AI_PROVIDER];
  const baseUrl = (env.AI_BASE_URL ?? d.baseUrl).replace(/\/$/, "");
  const model = env.AI_MODEL ?? d.model;
  if (!baseUrl || !model) throw new Error("AI_BASE_URL e AI_MODEL são obrigatórios para openai_compatible");

  return {
    provider: env.AI_PROVIDER,
    model,
    async chat({ messages, tools }) {
      const res = await fetchImpl(`${baseUrl}/chat/completions`, {
        method: "POST",
        headers: { "content-type": "application/json", authorization: `Bearer ${env.AI_API_KEY}` },
        body: JSON.stringify({
          model,
          messages,
          ...(tools.length ? { tools, tool_choice: "auto" } : {}),
          temperature: 0.2,
          max_tokens: 1200,
        }),
        signal: AbortSignal.timeout(45_000),
      });
      if (!res.ok) {
        const text = await res.text().catch(() => "");
        throw new LlmError(`provedor de IA respondeu ${res.status}: ${text.slice(0, 300)}`, res.status);
      }
      const body = (await res.json()) as {
        model?: string;
        choices?: { message?: { content?: string | null; tool_calls?: ToolCall[] } }[];
        usage?: { prompt_tokens?: number; completion_tokens?: number };
      };
      const message = body.choices?.[0]?.message;
      if (!message) throw new LlmError("resposta do provedor sem mensagem");
      return {
        message: { content: message.content ?? null, tool_calls: message.tool_calls?.length ? message.tool_calls : undefined },
        usage: { inputTokens: body.usage?.prompt_tokens ?? 0, outputTokens: body.usage?.completion_tokens ?? 0 },
        model: body.model ?? model,
      };
    },
  };
}
