import { pgAiActionStore, type AiActionStore } from "./tools/action-store.js";
import { createCustomerTool, deleteCustomerTool, searchCustomersTool } from "./tools/customer.tools.js";
import { opsTools } from "./tools/ops.tools.js";
import { ToolRegistry } from "./tools/registry.js";

/** Registro central. Cada módulo novo adiciona suas tools aqui. */
export function createToolRegistry(store: AiActionStore = pgAiActionStore) {
  return new ToolRegistry(store).register(createCustomerTool, searchCustomersTool, deleteCustomerTool, ...opsTools);
}
