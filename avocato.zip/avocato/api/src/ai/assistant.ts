import { z } from "zod";
import type { TenantContext } from "../core/context.js";
import { AppError, Errors } from "../core/errors.js";
import { iso } from "../core/util/http-schemas.js";
import type { ChatMessage, ChatTool, LlmClient } from "./llm.js";
import type { ToolCallResult, ToolRegistry } from "./tools/registry.js";

export const ChatSchema = z.object({
  message: z.string().trim().min(1).max(4000),
  conversationId: z.uuid().nullish(),
}).strict();

export type ChatAction = { tool: string; status: ToolCallResult["status"]; actionId?: string; summary?: string; error?: string };

const MAX_STEPS = 6;

function systemPrompt(p: { org: string; terminology: Record<string, string>; now: string; timezone: string; userName: string }) {
  const terms = Object.entries(p.terminology).map(([k, v]) => `${k} = "${v}"`).join(", ");
  return [
    `Você é o assistente do Avocato, sistema de gestão da empresa "${p.org}". Está falando com ${p.userName || "um usuário da empresa"}.`,
    `Agora é ${p.now} (fuso ${p.timezone}). Use sempre esse fuso ao montar datas (ex.: 2026-10-05T14:00:00-03:00).`,
    terms ? `Termos que a empresa usa: ${terms}.` : "",
    "Regras:",
    "- Use as ferramentas para consultar e registrar dados. Nunca invente clientes, valores, IDs ou resultados.",
    "- Para criar OS ou agendamento, primeiro encontre o cliente com search_customers (crie se não existir) e o serviço com list_services.",
    "- Se faltar uma informação essencial (ex.: horário), pergunte antes de agir.",
    "- Algumas ações ficam pendentes de aprovação humana (status awaiting_approval). Nesse caso, avise que a ação aguarda aprovação no painel.",
    "- Valores em reais no formato brasileiro (R$ 1.234,56). Responda em português do Brasil, curto e direto.",
  ].filter(Boolean).join("\n");
}

export class Assistant {
  constructor(private readonly registry: ToolRegistry, private readonly llm: LlmClient | null) {}

  status() {
    return { configured: !!this.llm, provider: this.llm?.provider ?? null, model: this.llm?.model ?? null };
  }

  async chat(ctx: TenantContext, input: z.input<typeof ChatSchema>) {
    ctx.require("ai.use");
    ctx.requireModule("ai");
    if (!this.llm) {
      throw new AppError(503, "ai_not_configured", "O assistente ainda não foi configurado. Defina AI_API_KEY no servidor (Groq ou Gemini, ambos têm plano gratuito).");
    }
    const { message, conversationId } = ChatSchema.parse(input);

    const setup = await ctx.run(async (db) => {
      const limit = await db.query<{ limit: number | null; used: number; org: string; timezone: string; terminology: Record<string, string>; user_name: string }>(
        `select (p.limits ->> 'ai_requests_month')::int as limit,
                (select count(*) from app.ai_messages m where m.org_id = $1 and m.role = 'user'
                   and m.created_at >= date_trunc('month', now()))::int as used,
                o.name as org, o.timezone, st.terminology,
                (select full_name from app.profiles where id = $2) as user_name
           from app.subscriptions s join app.plans p on p.key = s.plan_key
           join app.organizations o on o.id = s.org_id
           join app.organization_settings st on st.org_id = s.org_id
          where s.org_id = $1`, [ctx.orgId, ctx.userId]);
      const info = limit.rows[0]!;
      if (info.limit !== null && info.used >= info.limit) {
        throw new AppError(429, "ai_quota", `O limite de ${info.limit} mensagens de IA do plano neste mês foi atingido.`);
      }

      let convId = conversationId ?? null;
      if (convId) {
        const own = await db.query(`select 1 from app.ai_conversations where org_id = $1 and id = $2 and user_id = $3`, [ctx.orgId, convId, ctx.userId]);
        if (!own.rowCount) throw Errors.notFound("Conversa");
      } else {
        const { rows } = await db.query<{ id: string }>(
          `insert into app.ai_conversations (org_id, user_id, kind, title) values ($1, $2, 'assistant', $3) returning id`,
          [ctx.orgId, ctx.userId, message.slice(0, 80)]);
        convId = rows[0]!.id;
      }
      const history = await db.query<{ role: "user" | "assistant"; content: { text?: string } }>(
        `select role, content from (
           select role, content, created_at from app.ai_messages
            where org_id = $1 and conversation_id = $2 and role in ('user','assistant')
            order by created_at desc limit 16) h order by created_at`, [ctx.orgId, convId]);
      return { info, convId, history: history.rows };
    });

    const now = new Intl.DateTimeFormat("pt-BR", {
      timeZone: setup.info.timezone, dateStyle: "full", timeStyle: "short",
    }).format(new Date());
    const messages: ChatMessage[] = [
      { role: "system", content: systemPrompt({ org: setup.info.org, terminology: setup.info.terminology ?? {}, now, timezone: setup.info.timezone, userName: setup.info.user_name }) },
      ...setup.history.filter((h) => h.content?.text).map((h) => ({ role: h.role, content: h.content.text! }) as ChatMessage),
      { role: "user", content: message },
    ];
    const tools: ChatTool[] = this.registry.specsFor(ctx).map((t) => ({
      type: "function", function: { name: t.name, description: t.description, parameters: t.input_schema },
    }));

    const actions: ChatAction[] = [];
    let reply = "";
    let inputTokens = 0, outputTokens = 0, model = this.llm.model;

    for (let step = 0; step < MAX_STEPS; step++) {
      let res;
      try {
        res = await this.llm.chat({ messages, tools });
      } catch (err) {
        throw new AppError(502, "ai_unavailable", "O assistente não respondeu agora. Tente de novo em instantes.", { reason: (err as Error).message.slice(0, 200) });
      }
      inputTokens += res.usage.inputTokens;
      outputTokens += res.usage.outputTokens;
      model = res.model;

      if (!res.message.tool_calls?.length) {
        reply = res.message.content?.trim() || "Pronto.";
        break;
      }
      messages.push({ role: "assistant", content: res.message.content, tool_calls: res.message.tool_calls });
      for (const call of res.message.tool_calls) {
        let result: ToolCallResult | { status: "failed"; error: string };
        try {
          const args = call.function.arguments ? JSON.parse(call.function.arguments) : {};
          result = await this.registry.invoke(ctx, call.function.name, args, { conversationId: setup.convId });
        } catch (err) {
          result = { status: "failed", error: err instanceof AppError ? err.message : "Falha ao executar a ferramenta." };
        }
        actions.push({
          tool: call.function.name, status: result.status,
          ...("actionId" in result ? { actionId: result.actionId } : {}),
          ...("summary" in result ? { summary: result.summary } : {}),
          ...("error" in result ? { error: result.error } : {}),
        });
        messages.push({ role: "tool", tool_call_id: call.id, content: JSON.stringify(result).slice(0, 12_000) });
      }
      if (step === MAX_STEPS - 1) reply = "Fiz o que consegui por aqui. Confira as ações abaixo e me diga se quer continuar.";
    }

    await ctx.run(async (db) => {
      await db.query(
        `insert into app.ai_messages (org_id, conversation_id, role, content) values ($1, $2, 'user', $3)`,
        [ctx.orgId, setup.convId, JSON.stringify({ text: message })]);
      await db.query(
        `insert into app.ai_messages (org_id, conversation_id, role, content, model, input_tokens, output_tokens)
         values ($1, $2, 'assistant', $3, $4, $5, $6)`,
        [ctx.orgId, setup.convId, JSON.stringify({ text: reply, actions }), model, inputTokens, outputTokens]);
      await db.query(`update app.ai_conversations set updated_at = now() where org_id = $1 and id = $2`, [ctx.orgId, setup.convId]);
    });

    return { conversationId: setup.convId, reply, actions };
  }

  async conversations(ctx: TenantContext) {
    ctx.require("ai.use");
    return ctx.run(async (db) => {
      const { rows } = await db.query(
        `select id, title, updated_at from app.ai_conversations where org_id = $1 and user_id = $2 order by updated_at desc limit 30`,
        [ctx.orgId, ctx.userId]);
      return { data: rows.map((r) => ({ id: r.id, title: r.title, updatedAt: iso(r.updated_at) })) };
    });
  }

  async messages(ctx: TenantContext, conversationId: string) {
    ctx.require("ai.use");
    return ctx.run(async (db) => {
      const own = await db.query(`select 1 from app.ai_conversations where org_id = $1 and id = $2 and user_id = $3`, [ctx.orgId, conversationId, ctx.userId]);
      if (!own.rowCount) throw Errors.notFound("Conversa");
      const { rows } = await db.query(
        `select id, role, content, created_at from app.ai_messages where org_id = $1 and conversation_id = $2 and role in ('user','assistant')
          order by created_at`, [ctx.orgId, conversationId]);
      return {
        data: rows.map((r) => ({ id: r.id, role: r.role, text: r.content?.text ?? "", actions: r.content?.actions ?? [], createdAt: iso(r.created_at) })),
      };
    });
  }
}
