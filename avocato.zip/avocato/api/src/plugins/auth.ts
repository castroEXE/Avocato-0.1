import fp from "fastify-plugin";
import type { FastifyInstance } from "fastify";
import { Errors } from "../core/errors.js";
import type { TokenVerifier } from "../infra/auth/jwt.js";
import "./types.js";

/** Exige Bearer token válido do Supabase Auth em toda rota não pública. */
export const authPlugin = fp(
  async (app: FastifyInstance, opts: { verify: TokenVerifier }) => {
    app.decorateRequest("auth", null);

    app.addHook("onRequest", async (request) => {
      if (request.routeOptions.config?.public) return;

      const header = request.headers.authorization;
      if (!header?.startsWith("Bearer ")) throw Errors.unauthenticated();

      try {
        request.auth = await opts.verify(header.slice(7).trim());
      } catch (err) {
        request.log.debug({ err }, "token rejeitado");
        throw Errors.unauthenticated();
      }
    });
  },
  { name: "avocato-auth" },
);
