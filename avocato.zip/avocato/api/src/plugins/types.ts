import type { AuthIdentity } from "../infra/auth/jwt.js";
import type { TenantContext } from "../core/context.js";

declare module "fastify" {
  interface FastifyRequest {
    /** Preenchido pelo plugin de auth em toda rota não pública. */
    auth: AuthIdentity | null;
    /** Preenchido pelo plugin de tenant em rotas com config.tenant = true. */
    tenant: TenantContext | null;
  }
  interface FastifyContextConfig {
    /** Rota sem login (health, webhooks assinados...). */
    public?: boolean;
    /** Rota exige X-Organization-Id e membership ativa. */
    tenant?: boolean;
  }
}

export {};
