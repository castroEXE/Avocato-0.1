import fp from "fastify-plugin";
import type { FastifyInstance } from "fastify";
import type pg from "pg";
import { TenantContext } from "../core/context.js";
import { Errors } from "../core/errors.js";
import { isPermission, MODULES, type ModuleKey, type Permission } from "../core/rbac/permissions.js";
import { withDbContext } from "../infra/db/context.js";
import "./types.js";

const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

/**
 * Resolve a empresa ativa a partir do header X-Organization-Id.
 * Quem decide se o usuário pertence à empresa é o BANCO
 * (app.current_org_id() checa a membership). A API não "confia" no header.
 */
export const tenantPlugin = fp(
  async (app: FastifyInstance, opts: { pool: pg.Pool }) => {
    app.decorateRequest("tenant", null);

    app.addHook("preHandler", async (request) => {
      if (!request.routeOptions.config?.tenant) return;
      if (!request.auth) throw Errors.unauthenticated();

      const header = request.headers["x-organization-id"];
      const orgId = Array.isArray(header) ? header[0] : header;
      if (!orgId) throw Errors.tenantRequired();
      if (!UUID.test(orgId)) throw Errors.noTenant();

      const resolved = await withDbContext(opts.pool, { userId: request.auth.userId, orgId }, async (db) => {
        const { rows } = await db.query<{ org_id: string | null; permissions: string[]; modules: Record<string, boolean> | null }>(
          `select app.current_org_id() as org_id,
                  coalesce(array(select app.current_permissions()), '{}') as permissions,
                  (select s.enabled_modules from app.organization_settings s
                    where s.org_id = app.current_org_id()) as modules`,
        );
        return rows[0];
      });

      if (!resolved?.org_id) throw Errors.noTenant();

      const permissions = new Set<Permission>(resolved.permissions.filter(isPermission));
      const enabled = new Set<ModuleKey>(MODULES.filter((m) => resolved.modules?.[m] === true));
      enabled.add("core");

      request.tenant = new TenantContext(opts.pool, request.auth.userId, resolved.org_id, permissions, enabled, "user", {
        requestId: request.id,
        ip: request.ip,
        userAgent: request.headers["user-agent"],
      });
    });
  },
  { name: "avocato-tenant", dependencies: ["avocato-auth"] },
);
