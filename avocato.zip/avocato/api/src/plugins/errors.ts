import type { FastifyError, FastifyInstance } from "fastify";
import { hasZodFastifySchemaValidationErrors } from "fastify-type-provider-zod";
import { AppError, fromPgError } from "../core/errors.js";

type ErrorBody = { error: { code: string; message: string; details?: unknown; requestId: string } };

/** Formato único de erro para web e mobile. Nunca vaza stack/SQL em produção. */
export function registerErrorHandler(app: FastifyInstance) {
  app.setErrorHandler((err: FastifyError, request, reply) => {
    const send = (status: number, code: string, message: string, details?: unknown) => {
      const body: ErrorBody = { error: { code, message, requestId: request.id } };
      if (details !== undefined) body.error.details = details;
      return reply.status(status).send(body);
    };

    if (hasZodFastifySchemaValidationErrors(err)) {
      return send(400, "validation_error", "Alguns campos estão inválidos.",
        err.validation.map((v) => ({ field: v.instancePath.replace(/^\//, "").replaceAll("/", "."), message: v.message })));
    }
    if (err instanceof AppError) return send(err.statusCode, err.code, err.message, err.details);

    const pg = fromPgError(err);
    if (pg) return send(pg.statusCode, pg.code, pg.message, pg.details);

    if (err.statusCode === 429) return send(429, "rate_limited", "Muitas requisições. Tente de novo em instantes.");
    if (err.statusCode && err.statusCode < 500) return send(err.statusCode, err.code ?? "bad_request", err.message);

    request.log.error({ err }, "erro não tratado");
    return send(500, "internal_error", "Algo deu errado do nosso lado. Já registramos o erro.");
  });

  app.setNotFoundHandler((request, reply) =>
    reply.status(404).send({ error: { code: "route_not_found", message: "Rota não encontrada.", requestId: request.id } }),
  );
}
