import cors from "@fastify/cors";
import helmet from "@fastify/helmet";
import rateLimit from "@fastify/rate-limit";
import Fastify, { type FastifyServerOptions } from "fastify";
import { serializerCompiler, validatorCompiler, type ZodTypeProvider } from "fastify-type-provider-zod";
import type pg from "pg";
import { createToolRegistry } from "./ai/index.js";
import { aiRoutes } from "./ai/ai.routes.js";
import { Assistant } from "./ai/assistant.js";
import type { LlmClient } from "./ai/llm.js";
import { pgAiActionStore, type AiActionStore } from "./ai/tools/action-store.js";
import type { Env } from "./config/env.js";
import type { TokenVerifier } from "./infra/auth/jwt.js";
import { adminRoutes } from "./modules/admin/admin.routes.js";
import { appointmentRoutes } from "./modules/appointments/appointment.routes.js";
import { dashboardRoutes } from "./modules/dashboard/dashboard.routes.js";
import { financeRoutes } from "./modules/finance/finance.routes.js";
import { notificationRoutes } from "./modules/notifications/notification.routes.js";
import { profileRoutes } from "./modules/profile/profile.routes.js";
import { publicRoutes } from "./modules/public/public.routes.js";
import { serviceOrderRoutes } from "./modules/service-orders/service-order.routes.js";
import { serviceRoutes } from "./modules/services/service.routes.js";
import { staffRoutes } from "./modules/staff/staff.routes.js";
import { customerRoutes } from "./modules/customers/customer.routes.js";
import { meRoutes } from "./modules/me/me.routes.js";
import { organizationRoutes } from "./modules/organizations/organization.routes.js";
import { authPlugin } from "./plugins/auth.js";
import { registerErrorHandler } from "./plugins/errors.js";
import { tenantPlugin } from "./plugins/tenant.js";

export type AppDeps = {
  env: Pick<Env, "NODE_ENV" | "LOG_LEVEL" | "CORS_ORIGINS" | "RATE_LIMIT_MAX">;
  pool: pg.Pool;
  verifyToken: TokenVerifier;
  aiActionStore?: AiActionStore;
  llm?: LlmClient | null;
};

export async function buildApp(deps: AppDeps) {
  const logger: FastifyServerOptions["logger"] =
    deps.env.NODE_ENV === "test"
      ? false
      : {
          level: deps.env.LOG_LEVEL,
          redact: ["req.headers.authorization", "req.headers.cookie"],
          ...(deps.env.NODE_ENV === "development" ? { transport: { target: "pino-pretty" } } : {}),
        };

  const app = Fastify({
    logger,
    bodyLimit: 1024 * 1024,
    trustProxy: true,
    genReqId: () => crypto.randomUUID(),
  }).withTypeProvider<ZodTypeProvider>();

  app.setValidatorCompiler(validatorCompiler);
  app.setSerializerCompiler(serializerCompiler);
  registerErrorHandler(app);

  await app.register(helmet);
  await app.register(cors, {
    origin: deps.env.CORS_ORIGINS.length ? deps.env.CORS_ORIGINS : false,
    allowedHeaders: ["authorization", "content-type", "x-organization-id"],
    methods: ["GET", "POST", "PATCH", "PUT", "DELETE"],
    maxAge: 600,
  });
  await app.register(rateLimit, { max: deps.env.RATE_LIMIT_MAX, timeWindow: "1 minute" });

  await app.register(authPlugin, { verify: deps.verifyToken });
  await app.register(tenantPlugin, { pool: deps.pool });

  app.get("/health", { config: { public: true } }, async () => {
    await deps.pool.query("select 1");
    return { status: "ok" };
  });

  const store = deps.aiActionStore ?? pgAiActionStore;
  const registry = createToolRegistry(store);
  const assistant = new Assistant(registry, deps.llm ?? null);

  await app.register(async (v1) => {
    await v1.register(meRoutes(deps.pool));
    await v1.register(organizationRoutes(deps.pool));
    await v1.register(profileRoutes(deps.pool));
    await v1.register(customerRoutes);
    await v1.register(serviceRoutes);
    await v1.register(staffRoutes);
    await v1.register(serviceOrderRoutes);
    await v1.register(appointmentRoutes);
    await v1.register(financeRoutes);
    await v1.register(dashboardRoutes);
    await v1.register(notificationRoutes);
    await v1.register(publicRoutes(deps.pool));
    await v1.register(aiRoutes(registry, store, assistant));
    await v1.register(adminRoutes(deps.pool));
  }, { prefix: "/v1" });

  return app;
}
