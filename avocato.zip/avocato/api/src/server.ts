import { buildApp } from "./app.js";
import { loadEnv } from "./config/env.js";
import { createLlmClient } from "./ai/llm.js";
import { createSupabaseVerifier } from "./infra/auth/jwt.js";
import { createPool } from "./infra/db/pool.js";

const env = loadEnv();
const pool = createPool(env.DATABASE_URL, env.DB_POOL_MAX);
const app = await buildApp({
  env,
  pool,
  verifyToken: createSupabaseVerifier({ supabaseUrl: env.SUPABASE_URL, jwtSecret: env.SUPABASE_JWT_SECRET }),
  llm: createLlmClient(env),
});
if (!env.AI_API_KEY) app.log.warn("AI_API_KEY não definida: o assistente de IA ficará desativado.");

const shutdown = async (signal: string) => {
  app.log.info({ signal }, "encerrando");
  await app.close();
  await pool.end();
  process.exit(0);
};
process.on("SIGINT", () => void shutdown("SIGINT"));
process.on("SIGTERM", () => void shutdown("SIGTERM"));

await app.listen({ host: env.HOST, port: env.PORT });
