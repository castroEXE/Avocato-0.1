import type { FastifyPluginAsyncZod } from "fastify-type-provider-zod";
import { tenantOf } from "../../core/http/request.js";
import { DashboardService } from "./dashboard.service.js";

export const dashboardRoutes: FastifyPluginAsyncZod = async (app) => {
  app.get("/dashboard", { config: { tenant: true } }, (r) => DashboardService.summary(tenantOf(r)));
};
