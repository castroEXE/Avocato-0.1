import type { TenantContext } from "../../core/context.js";
import { iso } from "../../core/util/http-schemas.js";
import { materializeRecurring } from "../finance/finance.service.js";

/** Indicadores do painel inicial, todos calculados de dados reais da empresa. */
export const DashboardService = {
  async summary(ctx: TenantContext) {
    return ctx.run(async (db) => {
      const finance = ctx.enabledModules.has("finance") && ctx.can("finance.read");
      if (finance) await materializeRecurring(db, ctx.orgId);

      const money = finance
        ? (await db.query<{
            received_month: number; received_prev: number; paid_month: number;
            receivable_open: number; receivable_overdue: number; payable_open: number; payable_overdue: number;
          }>(
            `select
               coalesce(sum(paid_amount_cents) filter (where direction='in' and paid_at >= date_trunc('month', now())), 0)::bigint as received_month,
               coalesce(sum(paid_amount_cents) filter (where direction='in' and paid_at >= date_trunc('month', now()) - interval '1 month'
                                                       and paid_at < date_trunc('month', now())), 0)::bigint as received_prev,
               coalesce(sum(paid_amount_cents) filter (where direction='out' and paid_at >= date_trunc('month', now())), 0)::bigint as paid_month,
               coalesce(sum(amount_cents - paid_amount_cents) filter (where direction='in' and status in ('open','partially_paid')), 0)::bigint as receivable_open,
               coalesce(sum(amount_cents - paid_amount_cents) filter (where direction='in' and status in ('open','partially_paid') and due_on < current_date), 0)::bigint as receivable_overdue,
               coalesce(sum(amount_cents - paid_amount_cents) filter (where direction='out' and status in ('open','partially_paid')), 0)::bigint as payable_open,
               coalesce(sum(amount_cents - paid_amount_cents) filter (where direction='out' and status in ('open','partially_paid') and due_on < current_date), 0)::bigint as payable_overdue
             from app.financial_entries where org_id = $1 and status <> 'canceled'`, [ctx.orgId])).rows[0]
        : null;

      const cashflow = finance
        ? (await db.query<{ month: string; income: number; expense: number }>(
            `select to_char(m, 'YYYY-MM') as month,
                    coalesce(sum(t.amount_cents) filter (where t.direction = 'in'), 0)::bigint as income,
                    coalesce(sum(t.amount_cents) filter (where t.direction = 'out'), 0)::bigint as expense
               from generate_series(date_trunc('month', now()) - interval '11 months', date_trunc('month', now()), interval '1 month') m
               left join app.transactions t on t.org_id = $1 and date_trunc('month', t.occurred_at) = m
              group by m order by m`, [ctx.orgId])).rows
        : [];

      const orders = ctx.can("service_orders.read")
        ? (await db.query<{ month: string; created: number; done: number }>(
            `select to_char(m, 'YYYY-MM') as month,
                    (select count(*) from app.service_orders o where o.org_id = $1 and date_trunc('month', o.created_at) = m)::int as created,
                    (select count(*) from app.service_orders o where o.org_id = $1 and date_trunc('month', o.completed_at) = m)::int as done
               from generate_series(date_trunc('month', now()) - interval '11 months', date_trunc('month', now()), interval '1 month') m
              order by m`, [ctx.orgId])).rows
        : [];

      const counts = (await db.query<{ requested: number; active: number; done_month: number; customers: number; customers_new: number; today_appointments: number; avg_rating: number | null }>(
        `select
           (select count(*) from app.service_orders where org_id = $1 and status = 'requested')::int as requested,
           (select count(*) from app.service_orders where org_id = $1 and status in ('open','scheduled','in_progress'))::int as active,
           (select count(*) from app.service_orders where org_id = $1 and status = 'done' and completed_at >= date_trunc('month', now()))::int as done_month,
           (select count(*) from app.customers where org_id = $1 and deleted_at is null)::int as customers,
           (select count(*) from app.customers where org_id = $1 and deleted_at is null and created_at >= date_trunc('month', now()))::int as customers_new,
           (select count(*) from app.appointments where org_id = $1 and status not in ('canceled','no_show')
              and starts_at >= date_trunc('day', now()) and starts_at < date_trunc('day', now()) + interval '1 day')::int as today_appointments,
           (select round(avg(rating)::numeric, 1) from app.service_orders where org_id = $1 and rating is not null) as avg_rating`,
        [ctx.orgId])).rows[0]!;

      const topServices = (await db.query<{ id: string; name: string; quantity: number; revenue: number; prev_revenue: number }>(
        `select s.id, s.name,
                coalesce(sum(i.quantity) filter (where o.completed_at >= now() - interval '90 days'), 0)::numeric as quantity,
                coalesce(sum(i.quantity * i.unit_price_cents) filter (where o.completed_at >= now() - interval '90 days'), 0)::bigint as revenue,
                coalesce(sum(i.quantity * i.unit_price_cents) filter (where o.completed_at >= now() - interval '180 days'
                                                                       and o.completed_at < now() - interval '90 days'), 0)::bigint as prev_revenue
           from app.services s
           join app.service_order_items i on i.org_id = s.org_id and i.service_id = s.id
           join app.service_orders o on o.org_id = i.org_id and o.id = i.service_order_id and o.status = 'done'
          where s.org_id = $1
          group by s.id, s.name
         having coalesce(sum(i.quantity) filter (where o.completed_at >= now() - interval '90 days'), 0) > 0
          order by revenue desc limit 6`, [ctx.orgId])).rows;

      const upcoming = ctx.can("appointments.read")
        ? (await db.query(
            `select a.id, a.starts_at, c.name as customer, sv.name as service, st.name as staff
               from app.appointments a
               join app.customers c on c.org_id = a.org_id and c.id = a.customer_id
               left join app.services sv on sv.org_id = a.org_id and sv.id = a.service_id
               left join app.staff_members st on st.org_id = a.org_id and st.id = a.staff_id
              where a.org_id = $1 and a.starts_at >= now() and a.status in ('scheduled','confirmed')
              order by a.starts_at limit 5`, [ctx.orgId])).rows.map((r) => ({
            id: r.id as string, startsAt: iso(r.starts_at)!, customer: r.customer as string,
            service: (r.service as string | null) ?? null, staff: (r.staff as string | null) ?? null,
          }))
        : [];

      return {
        finance: money && {
          receivedMonthCents: money.received_month, receivedPrevMonthCents: money.received_prev, paidMonthCents: money.paid_month,
          receivableOpenCents: money.receivable_open, receivableOverdueCents: money.receivable_overdue,
          payableOpenCents: money.payable_open, payableOverdueCents: money.payable_overdue,
        },
        cashflow: cashflow.map((c) => ({ month: c.month, incomeCents: c.income, expenseCents: c.expense })),
        orders: { requested: counts.requested, active: counts.active, doneThisMonth: counts.done_month, series: orders },
        customers: { total: counts.customers, newThisMonth: counts.customers_new },
        todayAppointments: counts.today_appointments,
        averageRating: counts.avg_rating,
        topServices: topServices.map((s) => ({ id: s.id, name: s.name, quantity: Number(s.quantity), revenueCents: s.revenue, previousRevenueCents: s.prev_revenue })),
        upcoming,
      };
    });
  },
};
