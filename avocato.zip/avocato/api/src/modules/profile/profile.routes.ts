import type { FastifyPluginAsyncZod } from "fastify-type-provider-zod";
import type pg from "pg";
import { z } from "zod";
import { authOf } from "../../core/http/request.js";
import { withDbContext } from "../../infra/db/context.js";

/** Avatar: estilo do DiceBear + semente + opções escolhidas pelo usuário. */
export const AvatarSchema = z.object({
  style: z.enum(["notionists", "lorelei", "adventurer", "big-smile", "micah", "avataaars"]),
  seed: z.string().min(1).max(64),
  options: z.record(z.string().regex(/^[a-zA-Z]{1,40}$/), z.union([z.string().max(40), z.number(), z.boolean(), z.array(z.string().max(40)).max(10)]))
    .refine((o) => Object.keys(o).length <= 40, "Opções demais.")
    .default({}),
}).strict();

export const profileRoutes = (pool: pg.Pool): FastifyPluginAsyncZod => async (app) => {
  app.patch("/profile", {
    schema: {
      body: z.object({ fullName: z.string().trim().min(1).max(120), avatar: AvatarSchema.nullable() }).partial().strict()
        .refine((v) => Object.keys(v).length > 0, { message: "Nada para atualizar." }),
    },
  }, async (req) => {
    const { userId } = authOf(req);
    return withDbContext(pool, { userId }, async (db) => {
      const { rows } = await db.query<{ full_name: string; avatar: unknown }>(
        `update app.profiles set full_name = coalesce($2, full_name),
                avatar = case when $3::boolean then $4::jsonb else avatar end
          where id = $1 returning full_name, avatar`,
        [userId, req.body.fullName ?? null, req.body.avatar !== undefined, req.body.avatar === undefined ? null : JSON.stringify(req.body.avatar)]);
      return { fullName: rows[0]?.full_name ?? "", avatar: rows[0]?.avatar ?? null };
    });
  });
};
