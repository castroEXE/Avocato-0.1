import type { FastifyPluginAsyncZod } from "fastify-type-provider-zod";
import type pg from "pg";
import { z } from "zod";
import { AppError, Errors } from "../../core/errors.js";
import { withDbContext } from "../../infra/db/context.js";

const Slug = z.object({ slug: z.string().regex(/^[a-z0-9]+(-[a-z0-9]+)*$/).max(60) });

/**
 * Formulário público de solicitação (sem login).
 * Tudo passa por duas funções do banco com superfície mínima; a API só
 * valida, limita a taxa e filtra robôs (campo "website" invisível).
 */
export const publicRoutes = (pool: pg.Pool): FastifyPluginAsyncZod => async (app) => {
  const config = { public: true };

  app.get("/public/request-form/:slug", { config, schema: { params: Slug } }, async (req) => {
    const form = await withDbContext(pool, { userId: null }, async (db) => {
      const { rows } = await db.query<{ form: unknown }>(`select app.public_request_form($1) as form`, [req.params.slug]);
      return rows[0]?.form ?? null;
    });
    if (!form) throw Errors.notFound("Empresa");
    return form;
  });

  app.post("/public/requests/:slug", {
    config: { ...config, rateLimit: { max: 5, timeWindow: "15 minutes" } },
    schema: {
      params: Slug,
      body: z.object({
        name: z.string().trim().min(2).max(120),
        phone: z.string().trim().max(40).optional(),
        email: z.email().optional().or(z.literal("")),
        serviceId: z.uuid().optional().or(z.literal("")),
        description: z.string().trim().max(2000).optional(),
        preferredDate: z.iso.date().optional().or(z.literal("")),
        website: z.string().max(0).optional(), // honeypot: humanos deixam vazio
      }).strict().refine((b) => (b.phone && b.phone.replace(/\D/g, "").length >= 8) || b.email, {
        message: "Informe um telefone ou e-mail para contato.",
      }),
    },
  }, async (req, reply) => {
    const b = req.body;
    try {
      const result = await withDbContext(pool, { userId: null }, async (db) => {
        const { rows } = await db.query<{ r: { number: number; organization: string } }>(
          `select app.submit_public_request($1, $2, $3, $4, $5, $6, $7) as r`,
          [req.params.slug, b.name, b.phone || null, b.email || null, b.serviceId || null, b.description || null, b.preferredDate || null]);
        return rows[0]!.r;
      });
      return reply.status(201).send(result);
    } catch (err) {
      if ((err as { code?: string }).code === "P0002") throw Errors.notFound("Empresa");
      if ((err as { code?: string }).code === "22023") throw new AppError(400, "validation_error", (err as Error).message);
      throw err;
    }
  });
};
