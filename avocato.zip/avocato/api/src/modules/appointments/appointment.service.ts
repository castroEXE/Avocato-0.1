import { z } from "zod";
import { audit } from "../../core/audit/audit.js";
import type { TenantContext } from "../../core/context.js";
import { AppError, Errors } from "../../core/errors.js";
import { emitEvent } from "../../core/events/outbox.js";
import { Cents, iso } from "../../core/util/http-schemas.js";
import type { Db } from "../../infra/db/context.js";

export const APPOINTMENT_STATUSES = ["scheduled", "confirmed", "in_progress", "done", "canceled", "no_show"] as const;

export const AppointmentCreateSchema = z.object({
  customerId: z.uuid(),
  serviceId: z.uuid().nullish(),
  staffId: z.uuid().nullish(),
  startsAt: z.iso.datetime({ offset: true }),
  durationMinutes: z.number().int().min(5).max(24 * 60).nullish(),
  priceCents: Cents.nullish(),
  notes: z.string().max(2000).nullish(),
}).strict();

export const AppointmentUpdateSchema = AppointmentCreateSchema.partial().extend({
  status: z.enum(APPOINTMENT_STATUSES).optional(),
}).strict().refine((v) => Object.keys(v).length > 0, { message: "Nada para atualizar." });

export const AppointmentListQuery = z.object({
  from: z.iso.datetime({ offset: true }).optional(),
  to: z.iso.datetime({ offset: true }).optional(),
  staffId: z.uuid().optional(),
  customerId: z.uuid().optional(),
  includeCanceled: z.enum(["true", "false"]).default("false"),
});

export type Appointment = {
  id: string; startsAt: string; endsAt: string; status: (typeof APPOINTMENT_STATUSES)[number];
  customer: { id: string; name: string; phone: string | null };
  service: { id: string; name: string } | null; staff: { id: string; name: string } | null;
  priceCents: number | null; notes: string | null; serviceOrderId: string | null;
};

const SELECT = `
  select a.id, a.starts_at, a.ends_at, a.status, a.price_cents, a.notes, a.service_order_id,
         c.id as customer_id, c.name as customer_name, c.phone as customer_phone,
         sv.id as service_id, sv.name as service_name, st.id as staff_id, st.name as staff_name
    from app.appointments a
    join app.customers c on c.org_id = a.org_id and c.id = a.customer_id
    left join app.services sv on sv.org_id = a.org_id and sv.id = a.service_id
    left join app.staff_members st on st.org_id = a.org_id and st.id = a.staff_id`;

// eslint-disable-next-line @typescript-eslint/no-explicit-any
const map = (r: any): Appointment => ({
  id: r.id, startsAt: iso(r.starts_at)!, endsAt: iso(r.ends_at)!, status: r.status,
  customer: { id: r.customer_id, name: r.customer_name, phone: r.customer_phone },
  service: r.service_id ? { id: r.service_id, name: r.service_name } : null,
  staff: r.staff_id ? { id: r.staff_id, name: r.staff_name } : null,
  priceCents: r.price_cents, notes: r.notes, serviceOrderId: r.service_order_id,
});

async function find(db: Db, orgId: string, id: string, lock = false) {
  const { rows } = await db.query(`${SELECT} where a.org_id = $1 and a.id = $2 ${lock ? "for update of a" : ""}`, [orgId, id]);
  return rows[0] ? map(rows[0]) : null;
}

async function serviceDefaults(db: Db, orgId: string, serviceId: string | null | undefined) {
  if (!serviceId) return null;
  const { rows } = await db.query<{ duration_minutes: number | null; price_cents: number; name: string }>(
    `select duration_minutes, price_cents, name from app.services where org_id = $1 and id = $2`, [orgId, serviceId]);
  if (!rows[0]) throw new AppError(422, "invalid_reference", "Serviço não encontrado nesta empresa.");
  return rows[0];
}

export const AppointmentService = {
  async list(ctx: TenantContext, query: z.input<typeof AppointmentListQuery>) {
    ctx.require("appointments.read");
    ctx.requireModule("appointments");
    const f = AppointmentListQuery.parse(query);
    return ctx.run(async (db) => {
      const params: unknown[] = [ctx.orgId, f.from ?? new Date(Date.now() - 7 * 864e5).toISOString(), f.to ?? new Date(Date.now() + 30 * 864e5).toISOString()];
      const where = ["a.org_id = $1", "a.starts_at < $3", "a.ends_at > $2"];
      if (f.includeCanceled === "false") where.push(`a.status not in ('canceled')`);
      if (f.staffId) { params.push(f.staffId); where.push(`a.staff_id = $${params.length}`); }
      if (f.customerId) { params.push(f.customerId); where.push(`a.customer_id = $${params.length}`); }
      const { rows } = await db.query(`${SELECT} where ${where.join(" and ")} order by a.starts_at limit 1000`, params);
      return { data: rows.map(map) };
    });
  },

  async create(ctx: TenantContext, input: z.input<typeof AppointmentCreateSchema>) {
    ctx.require("appointments.create");
    ctx.requireModule("appointments");
    const d = AppointmentCreateSchema.parse(input);
    return ctx.run(async (db) => {
      const svc = await serviceDefaults(db, ctx.orgId, d.serviceId);
      const minutes = d.durationMinutes ?? svc?.duration_minutes ?? 60;
      const starts = new Date(d.startsAt);
      const ends = new Date(starts.getTime() + minutes * 60_000);
      const { rows } = await db.query<{ id: string }>(
        `insert into app.appointments (org_id, customer_id, service_id, staff_id, starts_at, ends_at, price_cents, notes, created_by)
         values ($1,$2,$3,$4,$5,$6,$7,$8,$9) returning id`,
        [ctx.orgId, d.customerId, d.serviceId ?? null, d.staffId ?? null, starts, ends, d.priceCents ?? svc?.price_cents ?? null,
          d.notes ?? null, ctx.userId]);
      const a = (await find(db, ctx.orgId, rows[0]!.id))!;
      await audit(db, ctx, { action: "appointment.create", entityType: "appointment", entityId: a.id, after: a });
      await emitEvent(db, ctx, { type: "appointment.created", entityType: "appointment", entityId: a.id, payload: { startsAt: a.startsAt } });
      return a;
    });
  },

  async update(ctx: TenantContext, id: string, input: z.input<typeof AppointmentUpdateSchema>) {
    ctx.require("appointments.update");
    const p = AppointmentUpdateSchema.parse(input);
    return ctx.run(async (db) => {
      const cur = await find(db, ctx.orgId, id, true);
      if (!cur) throw Errors.notFound("Agendamento");
      const svc = p.serviceId !== undefined ? await serviceDefaults(db, ctx.orgId, p.serviceId) : null;
      const starts = p.startsAt ? new Date(p.startsAt) : new Date(cur.startsAt);
      const curMinutes = (new Date(cur.endsAt).getTime() - new Date(cur.startsAt).getTime()) / 60_000;
      const minutes = p.durationMinutes ?? (p.serviceId ? svc?.duration_minutes ?? curMinutes : curMinutes);
      const ends = new Date(starts.getTime() + minutes * 60_000);
      await db.query(
        `update app.appointments set
            customer_id = coalesce($3, customer_id),
            service_id = case when $4::boolean then $5::uuid else service_id end,
            staff_id = case when $6::boolean then $7::uuid else staff_id end,
            starts_at = $8, ends_at = $9,
            price_cents = case when $10::boolean then $11::bigint else price_cents end,
            notes = case when $12::boolean then $13 else notes end,
            status = coalesce($14, status)
          where org_id = $1 and id = $2`,
        [ctx.orgId, id, p.customerId ?? null, p.serviceId !== undefined, p.serviceId ?? null, p.staffId !== undefined,
          p.staffId ?? null, starts, ends, p.priceCents !== undefined || p.serviceId !== undefined,
          p.priceCents ?? svc?.price_cents ?? null, p.notes !== undefined, p.notes ?? null, p.status ?? null]);

      const upd = (await find(db, ctx.orgId, id))!;
      if (p.status === "done" && cur.status !== "done") {
        if (upd.priceCents && !upd.serviceOrderId && ctx.enabledModules.has("finance")) {
          await db.query(
            `insert into app.financial_entries (org_id, direction, description, category_id, customer_id, appointment_id, amount_cents, due_on, created_by)
             select $1, 'in', $3, (select id from app.financial_categories where org_id = $1 and direction = 'in' and name = 'Serviços' limit 1),
                    $4, $2, $5, current_date, $6
              where not exists (select 1 from app.financial_entries where org_id = $1 and appointment_id = $2 and status <> 'canceled')`,
            [ctx.orgId, id, `${upd.service?.name ?? "Atendimento"} · ${upd.customer.name}`, upd.customer.id, upd.priceCents, ctx.userId]);
        }
        await db.query(`update app.customers set last_purchase_at = now(), last_activity_at = now() where org_id = $1 and id = $2`, [ctx.orgId, upd.customer.id]);
      }
      if (p.status === "canceled") {
        await db.query(`update app.financial_entries set status = 'canceled' where org_id = $1 and appointment_id = $2 and status = 'open'`, [ctx.orgId, id]);
      }
      await audit(db, ctx, { action: "appointment.update", entityType: "appointment", entityId: id, metadata: { fields: Object.keys(p) } });
      if (p.status && p.status !== cur.status) {
        await emitEvent(db, ctx, { type: "appointment.status_changed", entityType: "appointment", entityId: id, payload: { from: cur.status, to: p.status } });
      }
      return upd;
    });
  },
};
