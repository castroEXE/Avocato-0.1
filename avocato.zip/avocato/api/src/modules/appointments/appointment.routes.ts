import type { FastifyPluginAsyncZod } from "fastify-type-provider-zod";
import { tenantOf } from "../../core/http/request.js";
import { IdParams } from "../../core/util/http-schemas.js";
import { AppointmentCreateSchema, AppointmentListQuery, AppointmentService, AppointmentUpdateSchema } from "./appointment.service.js";

export const appointmentRoutes: FastifyPluginAsyncZod = async (app) => {
  const config = { tenant: true };
  app.get("/appointments", { config, schema: { querystring: AppointmentListQuery } }, (r) => AppointmentService.list(tenantOf(r), r.query));
  app.post("/appointments", { config, schema: { body: AppointmentCreateSchema } },
    async (r, reply) => reply.status(201).send(await AppointmentService.create(tenantOf(r), r.body)));
  app.patch("/appointments/:id", { config, schema: { params: IdParams, body: AppointmentUpdateSchema } },
    (r) => AppointmentService.update(tenantOf(r), r.params.id, r.body));
};
