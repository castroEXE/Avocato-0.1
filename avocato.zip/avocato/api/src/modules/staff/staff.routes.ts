import type { FastifyPluginAsyncZod } from "fastify-type-provider-zod";
import { tenantOf } from "../../core/http/request.js";
import { IdParams } from "../../core/util/http-schemas.js";
import { StaffCreateSchema, StaffListQuery, StaffService, StaffUpdateSchema } from "./staff.service.js";

export const staffRoutes: FastifyPluginAsyncZod = async (app) => {
  const config = { tenant: true };
  app.get("/staff", { config, schema: { querystring: StaffListQuery } }, (r) => StaffService.list(tenantOf(r), r.query));
  app.post("/staff", { config, schema: { body: StaffCreateSchema } },
    async (r, reply) => reply.status(201).send(await StaffService.create(tenantOf(r), r.body)));
  app.patch("/staff/:id", { config, schema: { params: IdParams, body: StaffUpdateSchema } },
    (r) => StaffService.update(tenantOf(r), r.params.id, r.body));
};
