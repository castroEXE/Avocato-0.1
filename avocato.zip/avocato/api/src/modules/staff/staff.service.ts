import { z } from "zod";
import { audit, diff } from "../../core/audit/audit.js";
import type { TenantContext } from "../../core/context.js";
import { Errors } from "../../core/errors.js";
import { iso } from "../../core/util/http-schemas.js";
import type { Db } from "../../infra/db/context.js";

export const StaffCreateSchema = z.object({
  kind: z.enum(["employee", "freelancer", "contractor"]).default("employee"),
  name: z.string().trim().min(1).max(160),
  email: z.email().nullish(),
  phone: z.string().trim().max(40).nullish(),
  document: z.string().trim().max(30).nullish(),
  jobTitle: z.string().trim().max(80).nullish(),
  specialties: z.array(z.string().trim().min(1).max(60)).max(20).default([]),
  commissionRate: z.number().min(0).max(1).default(0),
  isExternal: z.boolean().default(false),
  status: z.enum(["active", "inactive"]).default("active"),
}).strict();

export const StaffUpdateSchema = StaffCreateSchema.partial().strict()
  .refine((v) => Object.keys(v).length > 0, { message: "Nada para atualizar." });

export const StaffListQuery = z.object({
  kind: z.enum(["employee", "freelancer", "contractor"]).optional(),
  status: z.enum(["active", "inactive", "all"]).default("active"),
  q: z.string().trim().max(100).optional(),
});

export type StaffMember = {
  id: string; kind: "employee" | "freelancer" | "contractor"; name: string; email: string | null; phone: string | null;
  document: string | null; jobTitle: string | null; specialties: string[]; commissionRate: number; isExternal: boolean;
  status: "active" | "inactive"; createdAt: string; openOrders?: number;
};

const COLS = `id, kind, name, email::text as email, phone, document, job_title, specialties, commission_rate, is_external, status, created_at`;
// eslint-disable-next-line @typescript-eslint/no-explicit-any
const map = (r: any): StaffMember => ({
  id: r.id, kind: r.kind, name: r.name, email: r.email, phone: r.phone, document: r.document, jobTitle: r.job_title,
  specialties: r.specialties, commissionRate: r.commission_rate, isExternal: r.is_external, status: r.status,
  createdAt: iso(r.created_at)!, ...(r.open_orders !== undefined ? { openOrders: r.open_orders } : {}),
});

async function find(db: Db, orgId: string, id: string) {
  const { rows } = await db.query(`select ${COLS} from app.staff_members where org_id = $1 and id = $2 for update`, [orgId, id]);
  return rows[0] ? map(rows[0]) : null;
}

export const StaffService = {
  async list(ctx: TenantContext, query: z.input<typeof StaffListQuery>) {
    ctx.require("staff.read");
    const f = StaffListQuery.parse(query);
    return ctx.run(async (db) => {
      const params: unknown[] = [ctx.orgId];
      const where = ["s.org_id = $1"];
      if (f.kind) { params.push(f.kind); where.push(`s.kind = $${params.length}`); }
      if (f.status !== "all") { params.push(f.status); where.push(`s.status = $${params.length}`); }
      if (f.q) { params.push(`%${f.q}%`); where.push(`(s.name ilike $${params.length} or s.job_title ilike $${params.length})`); }
      const { rows } = await db.query(
        `select s.id, s.kind, s.name, s.email::text as email, s.phone, s.document, s.job_title, s.specialties,
                s.commission_rate, s.is_external, s.status, s.created_at,
                (select count(*)::int from app.service_orders o
                  where o.org_id = s.org_id and o.staff_id = s.id and o.status in ('open','scheduled','in_progress')) as open_orders
           from app.staff_members s where ${where.join(" and ")} order by s.status, s.name`, params);
      return { data: rows.map(map) };
    });
  },

  async create(ctx: TenantContext, input: z.input<typeof StaffCreateSchema>) {
    ctx.require("staff.manage");
    ctx.requireModule("team");
    const d = StaffCreateSchema.parse(input);
    return ctx.run(async (db) => {
      const { rows } = await db.query(
        `insert into app.staff_members (org_id, kind, name, email, phone, document, job_title, specialties, commission_rate, is_external, status)
         values ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11) returning ${COLS}`,
        [ctx.orgId, d.kind, d.name, d.email?.toLowerCase() ?? null, d.phone ?? null, d.document ?? null, d.jobTitle ?? null,
          d.specialties, d.commissionRate, d.isExternal, d.status]);
      const s = map(rows[0]);
      await audit(db, ctx, { action: "staff.create", entityType: "staff_member", entityId: s.id, after: s });
      return s;
    });
  },

  async update(ctx: TenantContext, id: string, input: z.input<typeof StaffUpdateSchema>) {
    ctx.require("staff.manage");
    const p = StaffUpdateSchema.parse(input);
    return ctx.run(async (db) => {
      const cur = await find(db, ctx.orgId, id);
      if (!cur) throw Errors.notFound("Profissional");
      const n = { ...cur, ...Object.fromEntries(Object.entries(p).filter(([, v]) => v !== undefined)) } as StaffMember;
      const { rows } = await db.query(
        `update app.staff_members set kind=$3, name=$4, email=$5, phone=$6, document=$7, job_title=$8, specialties=$9,
            commission_rate=$10, is_external=$11, status=$12
          where org_id = $1 and id = $2 returning ${COLS}`,
        [ctx.orgId, id, n.kind, n.name, n.email?.toLowerCase() ?? null, n.phone, n.document, n.jobTitle, n.specialties,
          n.commissionRate, n.isExternal, n.status]);
      const upd = map(rows[0]);
      const ch = diff(cur, upd);
      if (Object.keys(ch.after).length) await audit(db, ctx, { action: "staff.update", entityType: "staff_member", entityId: id, ...ch });
      return upd;
    });
  },
};
