import type { FastifyPluginAsyncZod } from "fastify-type-provider-zod";
import type pg from "pg";
import { z } from "zod";
import { authOf } from "../../core/http/request.js";
import { withDbContext } from "../../infra/db/context.js";

const MeSchema = z.object({
  user: z.object({ id: z.string(), email: z.string().nullable(), fullName: z.string(), avatarUrl: z.string().nullable(), avatar: z.unknown() }),
  organizations: z.array(z.object({
    id: z.string(), name: z.string(), slug: z.string(), status: z.string(), roleKey: z.string(), roleName: z.string(),
  })),
  isPlatformAdmin: z.boolean(),
});

/** Quem sou eu e de quais empresas faço parte (tela de seleção de empresa). */
export const meRoutes = (pool: pg.Pool): FastifyPluginAsyncZod => async (app) => {
  app.get("/me", { schema: { tags: ["me"], response: { 200: MeSchema } } }, async (req) => {
    const { userId, email } = authOf(req);
    return withDbContext(pool, { userId }, async (db) => {
      const profile = await db.query<{ full_name: string; email: string | null; avatar_url: string | null; avatar: unknown }>(
        `select full_name, email::text as email, avatar_url, avatar from app.profiles where id = $1`, [userId]);
      const orgs = await db.query<{ id: string; name: string; slug: string; status: string; role_key: string; role_name: string }>(
        `select o.id, o.name, o.slug, o.status, r.key as role_key, r.name as role_name
           from app.memberships m
           join app.organizations o on o.id = m.org_id
           join app.roles r on r.id = m.role_id
          where m.user_id = $1 and m.status = 'active'
          order by o.name`, [userId]);
      const admin = await db.query<{ ok: boolean }>(`select app.am_i_platform_admin() as ok`);
      const p = profile.rows[0];
      return {
        user: { id: userId, email: p?.email ?? email, fullName: p?.full_name ?? "", avatarUrl: p?.avatar_url ?? null, avatar: p?.avatar ?? null },
        organizations: orgs.rows.map((o) => ({
          id: o.id, name: o.name, slug: o.slug, status: o.status, roleKey: o.role_key, roleName: o.role_name,
        })),
        isPlatformAdmin: admin.rows[0]?.ok ?? false,
      };
    });
  });
};
