import { randomUUID } from "node:crypto";
import { z } from "zod";
import { audit } from "../../core/audit/audit.js";
import type { TenantContext } from "../../core/context.js";
import { AppError, Errors } from "../../core/errors.js";
import { emitEvent } from "../../core/events/outbox.js";
import { Cents, iso, isoDate } from "../../core/util/http-schemas.js";
import type { Db } from "../../infra/db/context.js";

const DateOnly = z.iso.date();
const Method = z.enum(["pix", "boleto", "credit_card", "debit_card", "cash", "transfer", "other"]);

export const EntryCreateSchema = z.object({
  direction: z.enum(["in", "out"]),
  description: z.string().trim().min(1).max(200),
  amountCents: Cents.refine((v) => v > 0, "Valor precisa ser maior que zero."),
  dueOn: DateOnly,
  categoryId: z.uuid().nullish(),
  customerId: z.uuid().nullish(),
  supplierId: z.uuid().nullish(),
  staffId: z.uuid().nullish(),
  paymentMethod: Method.nullish(),
  notes: z.string().max(2000).nullish(),
  installments: z.number().int().min(1).max(48).default(1),
  recurrence: z.enum(["none", "weekly", "monthly", "yearly"]).default("none"),
  paidNow: z.boolean().default(false),
}).strict();

export const EntryUpdateSchema = z.object({
  description: z.string().trim().min(1).max(200),
  amountCents: Cents.refine((v) => v > 0),
  dueOn: DateOnly,
  categoryId: z.uuid().nullable(),
  paymentMethod: Method.nullable(),
  notes: z.string().max(2000).nullable(),
}).partial().strict().refine((v) => Object.keys(v).length > 0, { message: "Nada para atualizar." });

export const PaySchema = z.object({
  amountCents: Cents.optional(),
  paidAt: z.iso.datetime({ offset: true }).optional(),
  paymentMethod: Method.optional(),
}).strict();

export const EntryListQuery = z.object({
  direction: z.enum(["in", "out"]).optional(),
  status: z.enum(["open", "paid", "overdue", "canceled", "all"]).default("all"),
  from: DateOnly.optional(),
  to: DateOnly.optional(),
  q: z.string().trim().max(100).optional(),
  limit: z.coerce.number().int().min(1).max(500).default(200),
});

export type FinancialEntry = {
  id: string; direction: "in" | "out"; description: string; amountCents: number; paidAmountCents: number;
  dueOn: string; status: "open" | "partially_paid" | "paid" | "canceled"; isOverdue: boolean; paidAt: string | null;
  paymentMethod: string | null; notes: string | null; category: { id: string; name: string } | null;
  customer: { id: string; name: string } | null; serviceOrderId: string | null; recurringRuleId: string | null;
  installmentNumber: number | null; installmentCount: number | null;
};

const SELECT = `
  select e.id, e.direction, e.description, e.amount_cents, e.paid_amount_cents, e.due_on, e.status, e.paid_at, e.payment_method,
         e.notes, e.service_order_id, e.recurring_rule_id, e.installment_number, e.installment_count,
         (e.status in ('open','partially_paid') and e.due_on < current_date) as is_overdue,
         cat.id as category_id, cat.name as category_name, c.id as customer_id, c.name as customer_name
    from app.financial_entries e
    left join app.financial_categories cat on cat.org_id = e.org_id and cat.id = e.category_id
    left join app.customers c on c.org_id = e.org_id and c.id = e.customer_id`;

// eslint-disable-next-line @typescript-eslint/no-explicit-any
const map = (r: any): FinancialEntry => ({
  id: r.id, direction: r.direction, description: r.description, amountCents: r.amount_cents, paidAmountCents: r.paid_amount_cents,
  dueOn: isoDate(r.due_on)!, status: r.status, isOverdue: r.is_overdue, paidAt: iso(r.paid_at), paymentMethod: r.payment_method,
  notes: r.notes, category: r.category_id ? { id: r.category_id, name: r.category_name } : null,
  customer: r.customer_id ? { id: r.customer_id, name: r.customer_name } : null, serviceOrderId: r.service_order_id,
  recurringRuleId: r.recurring_rule_id, installmentNumber: r.installment_number, installmentCount: r.installment_count,
});

function addPeriod(date: string, freq: "weekly" | "monthly" | "yearly", n: number) {
  const [y, m, d] = date.split("-").map(Number) as [number, number, number];
  if (freq === "weekly") {
    const t = new Date(Date.UTC(y, m - 1, d + 7 * n));
    return t.toISOString().slice(0, 10);
  }
  const months = freq === "monthly" ? n : 12 * n;
  const target = new Date(Date.UTC(y, m - 1 + months, 1));
  const lastDay = new Date(Date.UTC(target.getUTCFullYear(), target.getUTCMonth() + 1, 0)).getUTCDate();
  target.setUTCDate(Math.min(d, lastDay));
  return target.toISOString().slice(0, 10);
}

/**
 * Automação financeira: gera os lançamentos das contas recorrentes que
 * vencem nos próximos dias. Idempotente (índice único por regra + data),
 * então pode rodar em toda consulta ou num agendador.
 */
export async function materializeRecurring(db: Db, orgId: string) {
  const { rows } = await db.query<{
    id: string; direction: "in" | "out"; description: string; amount_cents: number; category_id: string | null;
    customer_id: string | null; supplier_id: string | null; staff_id: string | null;
    frequency: "weekly" | "monthly" | "yearly"; interval_count: number; next_due_on: Date; ends_on: Date | null; generate_days_ahead: number;
  }>(
    `select * from app.recurring_rules
      where org_id = $1 and is_active and next_due_on <= current_date + generate_days_ahead
        and (ends_on is null or next_due_on <= ends_on)
      for update skip locked`, [orgId]);
  let created = 0;
  for (const r of rows) {
    let due = isoDate(r.next_due_on)!;
    const limit = new Date(Date.now() + r.generate_days_ahead * 864e5).toISOString().slice(0, 10);
    const ends = r.ends_on ? isoDate(r.ends_on)! : null;
    let guard = 0;
    while (due <= limit && (!ends || due <= ends) && guard++ < 60) {
      const res = await db.query(
        `insert into app.financial_entries (org_id, direction, description, category_id, customer_id, supplier_id, staff_id, amount_cents, due_on, recurring_rule_id)
         values ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10) on conflict do nothing`,
        [orgId, r.direction, r.description, r.category_id, r.customer_id, r.supplier_id, r.staff_id, r.amount_cents, due, r.id]);
      created += res.rowCount ?? 0;
      due = addPeriod(due, r.frequency, r.interval_count);
    }
    await db.query(`update app.recurring_rules set next_due_on = $3 where org_id = $1 and id = $2`, [orgId, r.id, due]);
  }
  return created;
}

async function defaultAccount(db: Db, orgId: string) {
  const found = await db.query<{ id: string }>(
    `select id from app.bank_accounts where org_id = $1 and is_active order by created_at limit 1`, [orgId]);
  if (found.rows[0]) return found.rows[0].id;
  const { rows } = await db.query<{ id: string }>(
    `insert into app.bank_accounts (org_id, name, kind) values ($1, 'Caixa', 'cash') returning id`, [orgId]);
  return rows[0]!.id;
}

async function findEntry(db: Db, orgId: string, id: string, lock = false) {
  const { rows } = await db.query(`${SELECT} where e.org_id = $1 and e.id = $2 ${lock ? "for update of e" : ""}`, [orgId, id]);
  return rows[0] ? map(rows[0]) : null;
}

export const FinanceService = {
  async list(ctx: TenantContext, query: z.input<typeof EntryListQuery>) {
    ctx.require("finance.read");
    ctx.requireModule("finance");
    const f = EntryListQuery.parse(query);
    return ctx.run(async (db) => {
      await materializeRecurring(db, ctx.orgId);
      const params: unknown[] = [ctx.orgId];
      const where = ["e.org_id = $1"];
      if (f.direction) { params.push(f.direction); where.push(`e.direction = $${params.length}`); }
      if (f.status === "open") where.push(`e.status in ('open','partially_paid')`);
      else if (f.status === "overdue") where.push(`e.status in ('open','partially_paid') and e.due_on < current_date`);
      else if (f.status === "paid") where.push(`e.status = 'paid'`);
      else if (f.status === "canceled") where.push(`e.status = 'canceled'`);
      else where.push(`e.status <> 'canceled'`);
      if (f.from) { params.push(f.from); where.push(`e.due_on >= $${params.length}`); }
      if (f.to) { params.push(f.to); where.push(`e.due_on <= $${params.length}`); }
      if (f.q) { params.push(`%${f.q}%`); where.push(`(e.description ilike $${params.length} or c.name ilike $${params.length})`); }
      params.push(f.limit);
      const { rows } = await db.query(
        `${SELECT} where ${where.join(" and ")}
          order by case when e.status in ('open','partially_paid') then 0 else 1 end, e.due_on asc limit $${params.length}`, params);
      const totals = await db.query<{ direction: "in" | "out"; open: number; overdue: number; paid_month: number }>(
        `select direction,
                coalesce(sum(amount_cents - paid_amount_cents) filter (where status in ('open','partially_paid')), 0)::bigint as open,
                coalesce(sum(amount_cents - paid_amount_cents) filter (where status in ('open','partially_paid') and due_on < current_date), 0)::bigint as overdue,
                coalesce(sum(paid_amount_cents) filter (where paid_at >= date_trunc('month', now())), 0)::bigint as paid_month
           from app.financial_entries where org_id = $1 and status <> 'canceled' group by direction`, [ctx.orgId]);
      const t = (d: "in" | "out") => totals.rows.find((r) => r.direction === d);
      return {
        data: rows.map(map),
        totals: {
          receivableOpenCents: t("in")?.open ?? 0, receivableOverdueCents: t("in")?.overdue ?? 0, receivedMonthCents: t("in")?.paid_month ?? 0,
          payableOpenCents: t("out")?.open ?? 0, payableOverdueCents: t("out")?.overdue ?? 0, paidMonthCents: t("out")?.paid_month ?? 0,
        },
      };
    });
  },

  async create(ctx: TenantContext, input: z.input<typeof EntryCreateSchema>) {
    ctx.require("finance.manage");
    ctx.requireModule("finance");
    const d = EntryCreateSchema.parse(input);
    if (d.installments > 1 && d.recurrence !== "none") {
      throw new AppError(400, "validation_error", "Escolha parcelamento OU recorrência, não os dois.");
    }
    return ctx.run(async (db) => {
      let ruleId: string | null = null;
      if (d.recurrence !== "none") {
        const { rows } = await db.query<{ id: string }>(
          `insert into app.recurring_rules (org_id, direction, description, amount_cents, category_id, customer_id, supplier_id, staff_id,
              frequency, day_of_month, next_due_on, created_by)
           values ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12) returning id`,
          [ctx.orgId, d.direction, d.description, d.amountCents, d.categoryId ?? null, d.customerId ?? null, d.supplierId ?? null,
            d.staffId ?? null, d.recurrence, Number(d.dueOn.slice(8, 10)), addPeriod(d.dueOn, d.recurrence, 1), ctx.userId]);
        ruleId = rows[0]!.id;
      }

      const group = d.installments > 1 ? randomUUID() : null;
      const base = Math.floor(d.amountCents / d.installments);
      const ids: string[] = [];
      for (let i = 0; i < d.installments; i++) {
        const amount = i === d.installments - 1 ? d.amountCents - base * (d.installments - 1) : base;
        const { rows } = await db.query<{ id: string }>(
          `insert into app.financial_entries (org_id, direction, description, category_id, customer_id, supplier_id, staff_id, amount_cents,
              due_on, payment_method, notes, installment_group_id, installment_number, installment_count, recurring_rule_id, created_by)
           values ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16) returning id`,
          [ctx.orgId, d.direction, d.installments > 1 ? `${d.description} (${i + 1}/${d.installments})` : d.description,
            d.categoryId ?? null, d.customerId ?? null, d.supplierId ?? null, d.staffId ?? null, amount,
            d.installments > 1 ? addPeriod(d.dueOn, "monthly", i) : d.dueOn, d.paymentMethod ?? null, d.notes ?? null,
            group, group ? i + 1 : null, group ? d.installments : null, ruleId, ctx.userId]);
        ids.push(rows[0]!.id);
      }
      await audit(db, ctx, { action: "financial_entry.create", entityType: "financial_entry", entityId: ids[0]!,
        after: { direction: d.direction, description: d.description, amountCents: d.amountCents, installments: d.installments, recurrence: d.recurrence } });
      await emitEvent(db, ctx, { type: "financial_entry.created", entityType: "financial_entry", entityId: ids[0]!, payload: { direction: d.direction } });
      if (d.paidNow) await payInTx(db, ctx, ids[0]!, { paymentMethod: d.paymentMethod ?? undefined });
      return (await findEntry(db, ctx.orgId, ids[0]!))!;
    });
  },

  async update(ctx: TenantContext, id: string, input: z.input<typeof EntryUpdateSchema>) {
    ctx.require("finance.manage");
    const p = EntryUpdateSchema.parse(input);
    return ctx.run(async (db) => {
      const cur = await findEntry(db, ctx.orgId, id, true);
      if (!cur) throw Errors.notFound("Lançamento");
      if (cur.status === "paid" || cur.status === "canceled") throw new AppError(409, "entry_closed", "Lançamentos pagos ou cancelados não podem ser editados.");
      if (p.amountCents !== undefined && p.amountCents < cur.paidAmountCents) throw new AppError(400, "invalid_value", "O valor não pode ser menor do que o já pago.");
      await db.query(
        `update app.financial_entries set description = coalesce($3, description), amount_cents = coalesce($4, amount_cents),
            due_on = coalesce($5::date, due_on), category_id = case when $6::boolean then $7::uuid else category_id end,
            payment_method = case when $8::boolean then $9 else payment_method end, notes = case when $10::boolean then $11 else notes end
          where org_id = $1 and id = $2`,
        [ctx.orgId, id, p.description ?? null, p.amountCents ?? null, p.dueOn ?? null, p.categoryId !== undefined, p.categoryId ?? null,
          p.paymentMethod !== undefined, p.paymentMethod ?? null, p.notes !== undefined, p.notes ?? null]);
      await audit(db, ctx, { action: "financial_entry.update", entityType: "financial_entry", entityId: id, before: { amountCents: cur.amountCents, dueOn: cur.dueOn }, after: p });
      return (await findEntry(db, ctx.orgId, id))!;
    });
  },

  async pay(ctx: TenantContext, id: string, input: z.input<typeof PaySchema>) {
    ctx.require("finance.manage");
    const p = PaySchema.parse(input);
    return ctx.run((db) => payInTx(db, ctx, id, p));
  },

  async cancel(ctx: TenantContext, id: string) {
    ctx.require("finance.manage");
    return ctx.run(async (db) => {
      const cur = await findEntry(db, ctx.orgId, id, true);
      if (!cur) throw Errors.notFound("Lançamento");
      if (cur.paidAmountCents > 0) throw new AppError(409, "entry_paid", "Este lançamento já tem pagamento registrado e não pode ser cancelado.");
      await db.query(`update app.financial_entries set status = 'canceled' where org_id = $1 and id = $2`, [ctx.orgId, id]);
      await audit(db, ctx, { action: "financial_entry.cancel", entityType: "financial_entry", entityId: id, before: cur });
      return { id, status: "canceled" };
    });
  },

  async categories(ctx: TenantContext) {
    ctx.require("finance.read");
    return ctx.run(async (db) => {
      const { rows } = await db.query(`select id, name, direction from app.financial_categories where org_id = $1 order by direction, name`, [ctx.orgId]);
      return { data: rows };
    });
  },

  async recurring(ctx: TenantContext) {
    ctx.require("finance.read");
    return ctx.run(async (db) => {
      const { rows } = await db.query(
        `select id, direction, description, amount_cents as "amountCents", frequency, next_due_on as "nextDueOn", is_active as "isActive"
           from app.recurring_rules where org_id = $1 order by is_active desc, description`, [ctx.orgId]);
      return { data: rows.map((r) => ({ ...r, nextDueOn: isoDate(r.nextDueOn) })) };
    });
  },

  async setRecurringActive(ctx: TenantContext, id: string, isActive: boolean) {
    ctx.require("finance.manage");
    return ctx.run(async (db) => {
      const { rowCount } = await db.query(`update app.recurring_rules set is_active = $3 where org_id = $1 and id = $2`, [ctx.orgId, id, isActive]);
      if (!rowCount) throw Errors.notFound("Recorrência");
      await audit(db, ctx, { action: "recurring_rule.update", entityType: "recurring_rule", entityId: id, after: { isActive } });
      return { id, isActive };
    });
  },
};

async function payInTx(db: Db, ctx: TenantContext, id: string, p: z.infer<typeof PaySchema>) {
  const cur = await findEntry(db, ctx.orgId, id, true);
  if (!cur) throw Errors.notFound("Lançamento");
  if (cur.status === "paid" || cur.status === "canceled") throw new AppError(409, "entry_closed", "Este lançamento já está quitado ou cancelado.");
  const remaining = cur.amountCents - cur.paidAmountCents;
  const amount = p.amountCents ?? remaining;
  if (amount <= 0 || amount > remaining) throw new AppError(400, "invalid_value", "Valor de pagamento inválido.");
  const paidAt = p.paidAt ? new Date(p.paidAt) : new Date();
  const newPaid = cur.paidAmountCents + amount;
  const status = newPaid >= cur.amountCents ? "paid" : "partially_paid";
  const account = await defaultAccount(db, ctx.orgId);
  await db.query(
    `update app.financial_entries set paid_amount_cents = $3, status = $4, paid_at = $5, payment_method = coalesce($6, payment_method), bank_account_id = $7
      where org_id = $1 and id = $2`,
    [ctx.orgId, id, newPaid, status, paidAt, p.paymentMethod ?? null, account]);
  await db.query(
    `insert into app.transactions (org_id, bank_account_id, direction, amount_cents, occurred_at, description, financial_entry_id, created_by)
     values ($1,$2,$3,$4,$5,$6,$7,$8)`,
    [ctx.orgId, account, cur.direction, amount, paidAt, cur.description, id, ctx.userId]);
  await audit(db, ctx, { action: "financial_entry.pay", entityType: "financial_entry", entityId: id,
    before: { status: cur.status, paidAmountCents: cur.paidAmountCents }, after: { status, paidAmountCents: newPaid } });
  await emitEvent(db, ctx, { type: cur.direction === "in" ? "finance.received" : "finance.paid", entityType: "financial_entry", entityId: id, payload: { amountCents: amount } });
  return (await findEntry(db, ctx.orgId, id))!;
}
