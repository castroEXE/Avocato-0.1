import type { FastifyPluginAsyncZod } from "fastify-type-provider-zod";
import { z } from "zod";
import { tenantOf } from "../../core/http/request.js";
import { IdParams } from "../../core/util/http-schemas.js";
import { EntryCreateSchema, EntryListQuery, EntryUpdateSchema, FinanceService, PaySchema } from "./finance.service.js";

export const financeRoutes: FastifyPluginAsyncZod = async (app) => {
  const config = { tenant: true };
  app.get("/finance/entries", { config, schema: { querystring: EntryListQuery } }, (r) => FinanceService.list(tenantOf(r), r.query));
  app.post("/finance/entries", { config, schema: { body: EntryCreateSchema } },
    async (r, reply) => reply.status(201).send(await FinanceService.create(tenantOf(r), r.body)));
  app.patch("/finance/entries/:id", { config, schema: { params: IdParams, body: EntryUpdateSchema } },
    (r) => FinanceService.update(tenantOf(r), r.params.id, r.body));
  app.post("/finance/entries/:id/pay", { config, schema: { params: IdParams, body: PaySchema } },
    (r) => FinanceService.pay(tenantOf(r), r.params.id, r.body));
  app.post("/finance/entries/:id/cancel", { config, schema: { params: IdParams } }, (r) => FinanceService.cancel(tenantOf(r), r.params.id));
  app.get("/finance/categories", { config }, (r) => FinanceService.categories(tenantOf(r)));
  app.get("/finance/recurring", { config }, (r) => FinanceService.recurring(tenantOf(r)));
  app.patch("/finance/recurring/:id", { config, schema: { params: IdParams, body: z.object({ isActive: z.boolean() }).strict() } },
    (r) => FinanceService.setRecurringActive(tenantOf(r), r.params.id, r.body.isActive));
};
