import type { FastifyPluginAsyncZod } from "fastify-type-provider-zod";
import type pg from "pg";
import { z } from "zod";
import { Errors } from "../../core/errors.js";
import { authOf } from "../../core/http/request.js";
import { withDbContext } from "../../infra/db/context.js";

/**
 * Super Admin (PLATFORM ADMIN ≠ TENANT USER).
 * 1) confirma no banco que o usuário está em app.platform_admins;
 * 2) só então consulta como avocato_platform (leitura cross-tenant).
 * Ações de escrita ficam auditadas com actor_type = 'platform_admin'.
 */
export const adminRoutes = (pool: pg.Pool): FastifyPluginAsyncZod => async (app) => {
  app.addHook("preHandler", async (req) => {
    const { userId } = authOf(req);
    const ok = await withDbContext(pool, { userId }, async (db) => {
      const { rows } = await db.query<{ ok: boolean }>(`select app.am_i_platform_admin() as ok`);
      return rows[0]?.ok === true;
    });
    if (!ok) throw Errors.forbidden();
  });

  app.get("/admin/organizations", {
    schema: {
      tags: ["admin"],
      querystring: z.object({
        status: z.enum(["active", "suspended", "closed"]).optional(),
        limit: z.coerce.number().int().min(1).max(200).default(50),
        offset: z.coerce.number().int().min(0).default(0),
      }),
    },
  }, async (req) => {
    const { userId } = authOf(req);
    return withDbContext(pool, { userId, role: "avocato_platform" }, async (db) => {
      const { rows } = await db.query(
        `select o.id, o.name, o.slug, o.status, o.created_at as "createdAt",
                sub.plan_key as "planKey", sub.status as "subscriptionStatus",
                (select count(*) from app.memberships m where m.org_id = o.id and m.status = 'active')::int as "activeUsers",
                (select count(*) from app.customers c where c.org_id = o.id and c.deleted_at is null)::int as "customers",
                count(*) over()::int as total
           from app.organizations o
           left join app.subscriptions sub on sub.org_id = o.id
          where ($1::text is null or o.status = $1)
          order by o.created_at desc
          limit $2 offset $3`,
        [req.query.status ?? null, req.query.limit, req.query.offset],
      );
      const total = (rows[0] as { total?: number } | undefined)?.total ?? 0;
      return { data: rows.map(({ total: _t, ...r }) => r), total };
    });
  });

  app.patch("/admin/organizations/:id/status", {
    schema: {
      tags: ["admin"],
      params: z.object({ id: z.uuid() }),
      body: z.object({ status: z.enum(["active", "suspended", "closed"]), reason: z.string().trim().min(3).max(500) }).strict(),
    },
  }, async (req) => {
    const { userId } = authOf(req);
    return withDbContext(pool, { userId, role: "avocato_platform" }, async (db) => {
      const before = await db.query<{ status: string }>(`select status from app.organizations where id = $1 for update`, [req.params.id]);
      if (!before.rows[0]) throw Errors.notFound("Empresa");
      await db.query(`update app.organizations set status = $2 where id = $1`, [req.params.id, req.body.status]);
      await db.query(
        `insert into app.audit_logs (org_id, actor_type, actor_user_id, action, entity_type, entity_id, before, after, metadata)
         values ($1, 'platform_admin', $2, 'organization.status_change', 'organization', $6, $3, $4, $5)`,
        [req.params.id, userId, { status: before.rows[0].status }, { status: req.body.status },
          { reason: req.body.reason, requestId: req.id, ip: req.ip }, req.params.id],
      );
      return { id: req.params.id, status: req.body.status };
    });
  });
};
