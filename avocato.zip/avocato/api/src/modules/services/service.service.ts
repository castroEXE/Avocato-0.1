import { z } from "zod";
import { audit, diff } from "../../core/audit/audit.js";
import type { TenantContext } from "../../core/context.js";
import { Errors } from "../../core/errors.js";
import { emitEvent } from "../../core/events/outbox.js";
import { Cents } from "../../core/util/http-schemas.js";
import { ServiceRepository, type ServiceWrite } from "./service.repository.js";

export const ServiceCreateSchema = z.object({
  name: z.string().trim().min(1).max(160),
  description: z.string().max(2000).nullish(),
  category: z.string().trim().max(80).nullish(),
  priceCents: Cents.default(0),
  costCents: Cents.default(0),
  commissionRate: z.number().min(0).max(1).default(0),
  durationMinutes: z.number().int().min(5).max(24 * 60).nullish(),
  requiresBooking: z.boolean().default(false),
  isRecurring: z.boolean().default(false),
  recurrenceDays: z.number().int().min(1).max(730).nullish(),
  defaultStaffId: z.uuid().nullish(),
  isActive: z.boolean().default(true),
}).strict();

export const ServiceUpdateSchema = ServiceCreateSchema.partial().strict()
  .refine((v) => Object.keys(v).length > 0, { message: "Nada para atualizar." });

export const ServiceListQuery = z.object({
  q: z.string().trim().max(100).optional(),
  active: z.enum(["true", "false", "all"]).default("true"),
});

export const ServiceService = {
  async list(ctx: TenantContext, query: z.input<typeof ServiceListQuery>) {
    ctx.require("services.read");
    ctx.requireModule("services");
    const q = ServiceListQuery.parse(query);
    return ctx.run(async (db) => ({ data: await ServiceRepository.list(db, ctx.orgId, q) }));
  },

  async create(ctx: TenantContext, input: z.input<typeof ServiceCreateSchema>) {
    ctx.require("services.manage");
    ctx.requireModule("services");
    const d = ServiceCreateSchema.parse(input);
    const write: ServiceWrite = {
      name: d.name, description: d.description ?? null, category: d.category ?? null, priceCents: d.priceCents,
      costCents: d.costCents, commissionRate: d.commissionRate, durationMinutes: d.durationMinutes ?? null,
      requiresBooking: d.requiresBooking, isRecurring: d.isRecurring, recurrenceDays: d.recurrenceDays ?? null,
      defaultStaffId: d.defaultStaffId ?? null, isActive: d.isActive,
    };
    return ctx.run(async (db) => {
      const s = await ServiceRepository.insert(db, ctx.orgId, write);
      await audit(db, ctx, { action: "service.create", entityType: "service", entityId: s.id, after: s });
      await emitEvent(db, ctx, { type: "service.created", entityType: "service", entityId: s.id });
      return s;
    });
  },

  async update(ctx: TenantContext, id: string, input: z.input<typeof ServiceUpdateSchema>) {
    ctx.require("services.manage");
    ctx.requireModule("services");
    const p = ServiceUpdateSchema.parse(input);
    return ctx.run(async (db) => {
      const cur = await ServiceRepository.find(db, ctx.orgId, id, true);
      if (!cur) throw Errors.notFound("Serviço");
      const next: ServiceWrite = {
        name: p.name ?? cur.name,
        description: p.description !== undefined ? p.description : cur.description,
        category: p.category !== undefined ? p.category : cur.category,
        priceCents: p.priceCents ?? cur.priceCents,
        costCents: p.costCents ?? cur.costCents,
        commissionRate: p.commissionRate ?? cur.commissionRate,
        durationMinutes: p.durationMinutes !== undefined ? p.durationMinutes : cur.durationMinutes,
        requiresBooking: p.requiresBooking ?? cur.requiresBooking,
        isRecurring: p.isRecurring ?? cur.isRecurring,
        recurrenceDays: p.recurrenceDays !== undefined ? p.recurrenceDays : cur.recurrenceDays,
        defaultStaffId: p.defaultStaffId !== undefined ? p.defaultStaffId : cur.defaultStaffId,
        isActive: p.isActive ?? cur.isActive,
      };
      const upd = (await ServiceRepository.update(db, ctx.orgId, id, next))!;
      const ch = diff(cur, upd);
      if (Object.keys(ch.after).length) {
        await audit(db, ctx, { action: "service.update", entityType: "service", entityId: id, ...ch });
      }
      return upd;
    });
  },

  /** Serviços já usados em OS não são apagados: são desativados. */
  async remove(ctx: TenantContext, id: string) {
    ctx.require("services.manage");
    return ctx.run(async (db) => {
      const cur = await ServiceRepository.find(db, ctx.orgId, id, true);
      if (!cur) throw Errors.notFound("Serviço");
      const mode = await ServiceRepository.removeOrDeactivate(db, ctx.orgId, id);
      await audit(db, ctx, { action: mode === "deleted" ? "service.delete" : "service.deactivate", entityType: "service", entityId: id, before: cur });
      return { mode };
    });
  },
};
