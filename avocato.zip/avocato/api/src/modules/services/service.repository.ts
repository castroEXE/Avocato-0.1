import type { Db } from "../../infra/db/context.js";
import { iso } from "../../core/util/http-schemas.js";

export type Service = {
  id: string; name: string; description: string | null; category: string | null;
  priceCents: number; costCents: number; commissionRate: number; marginCents: number;
  durationMinutes: number | null; requiresBooking: boolean; isRecurring: boolean; recurrenceDays: number | null;
  defaultStaffId: string | null; isActive: boolean; createdAt: string; updatedAt: string;
  ordersCount?: number;
};

export type ServiceWrite = Omit<Service, "id" | "marginCents" | "createdAt" | "updatedAt" | "ordersCount">;

const COLS = `s.id, s.name, s.description, s.category, s.price_cents, s.cost_cents, s.commission_rate, s.margin_cents,
  s.duration_minutes, s.requires_booking, s.is_recurring, s.recurrence_days, s.default_staff_id, s.is_active,
  s.created_at, s.updated_at`;

// eslint-disable-next-line @typescript-eslint/no-explicit-any
const map = (r: any): Service => ({
  id: r.id, name: r.name, description: r.description, category: r.category, priceCents: r.price_cents,
  costCents: r.cost_cents, commissionRate: r.commission_rate, marginCents: r.margin_cents,
  durationMinutes: r.duration_minutes, requiresBooking: r.requires_booking, isRecurring: r.is_recurring,
  recurrenceDays: r.recurrence_days, defaultStaffId: r.default_staff_id, isActive: r.is_active,
  createdAt: iso(r.created_at)!, updatedAt: iso(r.updated_at)!,
  ...(r.orders_count !== undefined ? { ordersCount: r.orders_count } : {}),
});

export const ServiceRepository = {
  async list(db: Db, orgId: string, f: { q?: string; active: "true" | "false" | "all" }) {
    const params: unknown[] = [orgId];
    const where = ["s.org_id = $1"];
    if (f.active !== "all") { params.push(f.active === "true"); where.push(`s.is_active = $${params.length}`); }
    if (f.q) { params.push(`%${f.q}%`); where.push(`(s.name ilike $${params.length} or s.category ilike $${params.length})`); }
    const { rows } = await db.query(
      `select ${COLS},
              (select count(distinct i.service_order_id)::int from app.service_order_items i
                where i.org_id = s.org_id and i.service_id = s.id) as orders_count
         from app.services s where ${where.join(" and ")} order by s.is_active desc, s.name`, params);
    return rows.map(map);
  },
  async find(db: Db, orgId: string, id: string, lock = false) {
    const { rows } = await db.query(`select ${COLS} from app.services s where s.org_id = $1 and s.id = $2 ${lock ? "for update" : ""}`, [orgId, id]);
    return rows[0] ? map(rows[0]) : null;
  },
  async insert(db: Db, orgId: string, s: ServiceWrite) {
    const { rows } = await db.query(
      `insert into app.services as s (org_id, name, description, category, price_cents, cost_cents, commission_rate,
          duration_minutes, requires_booking, is_recurring, recurrence_days, default_staff_id, is_active)
       values ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13) returning ${COLS}`,
      [orgId, s.name, s.description, s.category, s.priceCents, s.costCents, s.commissionRate, s.durationMinutes,
        s.requiresBooking, s.isRecurring, s.recurrenceDays, s.defaultStaffId, s.isActive]);
    return map(rows[0]);
  },
  async update(db: Db, orgId: string, id: string, s: ServiceWrite) {
    const { rows } = await db.query(
      `update app.services as s set name=$3, description=$4, category=$5, price_cents=$6, cost_cents=$7, commission_rate=$8,
          duration_minutes=$9, requires_booking=$10, is_recurring=$11, recurrence_days=$12, default_staff_id=$13, is_active=$14
        where s.org_id = $1 and s.id = $2 returning ${COLS}`,
      [orgId, id, s.name, s.description, s.category, s.priceCents, s.costCents, s.commissionRate, s.durationMinutes,
        s.requiresBooking, s.isRecurring, s.recurrenceDays, s.defaultStaffId, s.isActive]);
    return rows[0] ? map(rows[0]) : null;
  },
  async removeOrDeactivate(db: Db, orgId: string, id: string): Promise<"deleted" | "deactivated"> {
    const used = await db.query(
      `select 1 from app.service_order_items where org_id = $1 and service_id = $2
        union all select 1 from app.appointments where org_id = $1 and service_id = $2 limit 1`, [orgId, id]);
    if (used.rowCount) {
      await db.query(`update app.services set is_active = false where org_id = $1 and id = $2`, [orgId, id]);
      return "deactivated";
    }
    await db.query(`delete from app.services where org_id = $1 and id = $2`, [orgId, id]);
    return "deleted";
  },
};
