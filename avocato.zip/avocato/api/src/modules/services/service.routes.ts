import type { FastifyPluginAsyncZod } from "fastify-type-provider-zod";
import { tenantOf } from "../../core/http/request.js";
import { IdParams } from "../../core/util/http-schemas.js";
import { ServiceCreateSchema, ServiceListQuery, ServiceService, ServiceUpdateSchema } from "./service.service.js";

export const serviceRoutes: FastifyPluginAsyncZod = async (app) => {
  const config = { tenant: true };
  app.get("/services", { config, schema: { querystring: ServiceListQuery } }, (r) => ServiceService.list(tenantOf(r), r.query));
  app.post("/services", { config, schema: { body: ServiceCreateSchema } },
    async (r, reply) => reply.status(201).send(await ServiceService.create(tenantOf(r), r.body)));
  app.patch("/services/:id", { config, schema: { params: IdParams, body: ServiceUpdateSchema } },
    (r) => ServiceService.update(tenantOf(r), r.params.id, r.body));
  app.delete("/services/:id", { config, schema: { params: IdParams } }, (r) => ServiceService.remove(tenantOf(r), r.params.id));
};
