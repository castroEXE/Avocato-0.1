import type { FastifyPluginAsyncZod } from "fastify-type-provider-zod";
import type pg from "pg";
import { z } from "zod";
import { audit } from "../../core/audit/audit.js";
import { authOf, tenantOf } from "../../core/http/request.js";
import { CreateOrganizationSchema, OrganizationService, UpdateSettingsSchema } from "./organization.service.js";

export const organizationRoutes = (pool: pg.Pool): FastifyPluginAsyncZod => async (app) => {
  app.post("/organizations", {
    config: { rateLimit: { max: 10, timeWindow: "1 hour" } },
    schema: { tags: ["organizations"], body: CreateOrganizationSchema },
  }, async (req, reply) => {
    const org = await OrganizationService.create(pool, authOf(req).userId, req.body);
    return reply.status(201).send(org);
  });

  app.get("/organization/context", {
    config: { tenant: true },
    schema: { tags: ["organizations"] },
  }, (req) => OrganizationService.context(tenantOf(req)));

  app.patch("/organization", {
    config: { tenant: true },
    schema: {
      tags: ["organizations"],
      body: z.object({ name: z.string().trim().min(2).max(120), timezone: z.string().min(3).max(60) }).partial().strict()
        .refine((v) => Object.keys(v).length > 0, { message: "Nada para atualizar." }),
    },
  }, async (req) => {
    const ctx = tenantOf(req);
    ctx.require("settings.manage");
    if (req.body.timezone && !Intl.supportedValuesOf("timeZone").includes(req.body.timezone)) {
      throw Object.assign(new Error("Fuso horário inválido."), { statusCode: 400 });
    }
    return ctx.run(async (db) => {
      const { rows } = await db.query<{ name: string; timezone: string }>(
        `update app.organizations set name = coalesce($2, name), timezone = coalesce($3, timezone) where id = $1 returning name, timezone`,
        [ctx.orgId, req.body.name ?? null, req.body.timezone ?? null]);
      await audit(db, ctx, { action: "organization.update", entityType: "organization", entityId: ctx.orgId, after: req.body });
      return rows[0];
    });
  });

  app.patch("/organization/settings", {
    config: { tenant: true },
    schema: { tags: ["organizations"], body: UpdateSettingsSchema },
  }, (req) => OrganizationService.updateSettings(tenantOf(req), req.body));
};
