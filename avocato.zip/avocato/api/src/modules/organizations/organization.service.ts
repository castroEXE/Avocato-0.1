import { randomBytes } from "node:crypto";
import type pg from "pg";
import { z } from "zod";
import { audit, diff } from "../../core/audit/audit.js";
import type { TenantContext } from "../../core/context.js";
import { AppError, Errors } from "../../core/errors.js";
import { emitEvent } from "../../core/events/outbox.js";
import { MODULES, type ModuleKey } from "../../core/rbac/permissions.js";
import { withDbContext } from "../../infra/db/context.js";

export const CreateOrganizationSchema = z.object({
  name: z.string().trim().min(2).max(120),
  slug: z.string().trim().regex(/^[a-z0-9]+(-[a-z0-9]+)*$/).min(3).max(60).optional(),
  plan: z.enum(["starter", "pro", "business"]).default("starter"),
}).strict();

const JsonObject = z.record(z.string(), z.unknown());

export const UpdateSettingsSchema = z.object({
  onboardingStatus: z.enum(["pending", "in_progress", "completed"]),
  businessProfile: JsonObject,
  enabledModules: z.partialRecord(z.enum(MODULES), z.boolean()),
  terminology: z.record(z.string().regex(/^[a-z_]+$/), z.string().trim().min(1).max(60)),
  workflowConfiguration: JsonObject,
  dashboardConfiguration: JsonObject,
  aiConfiguration: JsonObject,
}).partial().strict().refine((v) => Object.keys(v).length > 0, { message: "Nada para atualizar." });

export type UpdateSettingsInput = z.infer<typeof UpdateSettingsSchema>;

function slugify(name: string) {
  const base = name.normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase()
    .replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, "").slice(0, 48) || "empresa";
  return `${base}-${randomBytes(3).toString("hex")}`;
}

type SettingsRow = {
  onboarding_status: string; business_profile: Record<string, unknown>; enabled_modules: Record<string, boolean>;
  terminology: Record<string, string>; workflow_configuration: Record<string, unknown>;
  dashboard_configuration: Record<string, unknown>; ai_configuration: Record<string, unknown>;
};

function toSettings(r: SettingsRow) {
  return {
    onboardingStatus: r.onboarding_status,
    businessProfile: r.business_profile,
    enabledModules: r.enabled_modules,
    terminology: r.terminology,
    workflowConfiguration: r.workflow_configuration,
    dashboardConfiguration: r.dashboard_configuration,
    aiConfiguration: r.ai_configuration,
  };
}

export const OrganizationService = {
  /** Cria a empresa e torna o usuário owner (tudo via app.create_organization). */
  async create(pool: pg.Pool, userId: string, input: z.input<typeof CreateOrganizationSchema>) {
    const data = CreateOrganizationSchema.parse(input);
    const slug = data.slug ?? slugify(data.name);
    return withDbContext(pool, { userId }, async (db) => {
      try {
        const { rows } = await db.query<{ id: string }>(
          `select app.create_organization($1, $2, $3) as id`, [data.name, slug, data.plan]);
        return { id: rows[0]!.id, name: data.name, slug };
      } catch (err) {
        if ((err as { code?: string }).code === "23505") throw Errors.conflict("Esse endereço (slug) já está em uso.");
        throw err;
      }
    });
  },

  /** Tudo que o frontend precisa para se adaptar à empresa: módulos, termos, permissões, plano. */
  async context(ctx: TenantContext) {
    return ctx.run(async (db) => {
      const { rows } = await db.query<SettingsRow & {
        id: string; name: string; slug: string; status: string; timezone: string; currency: string;
        role_key: string; role_name: string; plan_key: string; plan_name: string; sub_status: string;
        trial_ends_at: Date | null; limits: Record<string, number | null>;
      }>(
        `select o.id, o.name, o.slug, o.status, o.timezone, o.currency,
                r.key as role_key, r.name as role_name,
                s.*, sub.plan_key, p.name as plan_name, sub.status as sub_status, sub.trial_ends_at, p.limits
           from app.organizations o
           join app.memberships m on m.org_id = o.id and m.user_id = $2
           join app.roles r on r.id = m.role_id
           join app.organization_settings s on s.org_id = o.id
           join app.subscriptions sub on sub.org_id = o.id
           join app.plans p on p.key = sub.plan_key
          where o.id = $1`,
        [ctx.orgId, ctx.userId],
      );
      const r = rows[0];
      if (!r) throw Errors.noTenant();
      return {
        organization: { id: r.id, name: r.name, slug: r.slug, status: r.status, timezone: r.timezone, currency: r.currency },
        role: { key: r.role_key, name: r.role_name },
        permissions: [...ctx.permissions].sort(),
        enabledModules: [...ctx.enabledModules].sort(),
        settings: toSettings(r),
        subscription: {
          planKey: r.plan_key, planName: r.plan_name, status: r.sub_status,
          trialEndsAt: r.trial_ends_at?.toISOString() ?? null, limits: r.limits,
        },
      };
    });
  },

  /**
   * Atualiza a configuração dinâmica (usada pela tela de configurações e,
   * na Fase 4/5, pela IA do onboarding através de uma tool).
   * Faz merge raso por seção e valida dependências entre módulos.
   */
  async updateSettings(ctx: TenantContext, input: UpdateSettingsInput) {
    ctx.require("settings.manage");
    const patch = UpdateSettingsSchema.parse(input);

    return ctx.run(async (db) => {
      const cur = await db.query<SettingsRow>(
        `select * from app.organization_settings where org_id = $1 for update`, [ctx.orgId]);
      const current = cur.rows[0];
      if (!current) throw Errors.noTenant();

      let enabled = current.enabled_modules;
      if (patch.enabledModules) {
        const catalog = await db.query<{ key: ModuleKey; depends_on: ModuleKey[]; is_core: boolean }>(
          `select key, depends_on, is_core from app.modules`);
        enabled = { ...current.enabled_modules, ...patch.enabledModules };
        for (const m of catalog.rows) if (m.is_core) enabled[m.key] = true;
        const missing = catalog.rows.flatMap((m) =>
          enabled[m.key] ? m.depends_on.filter((d) => !enabled[d]).map((d) => ({ module: m.key, requires: d })) : []);
        if (missing.length) {
          throw new AppError(422, "module_dependency", "Alguns módulos dependem de outros que estão desligados.", missing);
        }
      }

      const { rows } = await db.query<SettingsRow>(
        `update app.organization_settings set
            onboarding_status = $2,
            business_profile = business_profile || $3::jsonb,
            enabled_modules = $4::jsonb,
            terminology = terminology || $5::jsonb,
            workflow_configuration = workflow_configuration || $6::jsonb,
            dashboard_configuration = dashboard_configuration || $7::jsonb,
            ai_configuration = ai_configuration || $8::jsonb
          where org_id = $1
          returning *`,
        [ctx.orgId, patch.onboardingStatus ?? current.onboarding_status, patch.businessProfile ?? {}, enabled,
          patch.terminology ?? {}, patch.workflowConfiguration ?? {}, patch.dashboardConfiguration ?? {},
          patch.aiConfiguration ?? {}],
      );
      const before = toSettings(current);
      const after = toSettings(rows[0]!);
      const changes = diff(before, after);
      if (Object.keys(changes.after).length) {
        await audit(db, ctx, { action: "organization_settings.update", entityType: "organization", entityId: ctx.orgId, ...changes });
        await emitEvent(db, ctx, {
          type: "organization.configured", entityType: "organization", entityId: ctx.orgId,
          payload: { sections: Object.keys(changes.after) },
        });
      }
      return after;
    });
  },
};
