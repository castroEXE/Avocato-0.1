import type { FastifyPluginAsyncZod } from "fastify-type-provider-zod";
import { tenantOf } from "../../core/http/request.js";
import { iso } from "../../core/util/http-schemas.js";

export const notificationRoutes: FastifyPluginAsyncZod = async (app) => {
  const config = { tenant: true };

  app.get("/notifications", { config }, async (req) => {
    const ctx = tenantOf(req);
    ctx.require("notifications.read");
    return ctx.run(async (db) => {
      const { rows } = await db.query(
        `select id, kind, severity, title, body, link, read_at, created_at from app.notifications
          where org_id = $1 and channel = 'in_app' and (user_id is null or user_id = $2)
          order by created_at desc limit 30`, [ctx.orgId, ctx.userId]);
      return {
        data: rows.map((r) => ({ id: r.id, kind: r.kind, severity: r.severity, title: r.title, body: r.body, link: r.link,
          read: !!r.read_at, createdAt: iso(r.created_at) })),
        unread: rows.filter((r) => !r.read_at).length,
      };
    });
  });

  app.post("/notifications/read-all", { config }, async (req) => {
    const ctx = tenantOf(req);
    ctx.require("notifications.read");
    await ctx.run((db) => db.query(
      `update app.notifications set read_at = now()
        where org_id = $1 and read_at is null and (user_id is null or user_id = $2)`, [ctx.orgId, ctx.userId]));
    return { ok: true };
  });
};
