import type { FastifyPluginAsyncZod } from "fastify-type-provider-zod";
import { tenantOf } from "../../core/http/request.js";
import { IdParams } from "../../core/util/http-schemas.js";
import {
  OrderCreateSchema, OrderListQuery, OrderRatingSchema, OrderStatusSchema, OrderUpdateSchema, ServiceOrderService,
} from "./service-order.service.js";

export const serviceOrderRoutes: FastifyPluginAsyncZod = async (app) => {
  const config = { tenant: true };
  app.get("/service-orders", { config, schema: { querystring: OrderListQuery } }, (r) => ServiceOrderService.list(tenantOf(r), r.query));
  app.get("/service-orders/:id", { config, schema: { params: IdParams } }, (r) => ServiceOrderService.get(tenantOf(r), r.params.id));
  app.post("/service-orders", { config, schema: { body: OrderCreateSchema } },
    async (r, reply) => reply.status(201).send(await ServiceOrderService.create(tenantOf(r), r.body)));
  app.patch("/service-orders/:id", { config, schema: { params: IdParams, body: OrderUpdateSchema } },
    (r) => ServiceOrderService.update(tenantOf(r), r.params.id, r.body));
  app.post("/service-orders/:id/status", { config, schema: { params: IdParams, body: OrderStatusSchema } },
    (r) => ServiceOrderService.changeStatus(tenantOf(r), r.params.id, r.body));
  app.post("/service-orders/:id/rating", { config, schema: { params: IdParams, body: OrderRatingSchema } },
    (r) => ServiceOrderService.rate(tenantOf(r), r.params.id, r.body));
};
