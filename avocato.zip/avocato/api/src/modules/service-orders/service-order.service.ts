import { z } from "zod";
import { audit } from "../../core/audit/audit.js";
import type { TenantContext } from "../../core/context.js";
import { AppError, Errors } from "../../core/errors.js";
import { emitEvent } from "../../core/events/outbox.js";
import { Cents, Paging } from "../../core/util/http-schemas.js";
import type { Db } from "../../infra/db/context.js";
import { ORDER_STATUSES, ServiceOrderRepository, type OrderStatus } from "./service-order.repository.js";

const ItemInput = z.object({
  serviceId: z.uuid().nullish(),
  description: z.string().trim().min(1).max(200).nullish(),
  quantity: z.number().positive().max(100000).default(1),
  unitPriceCents: Cents.nullish(),
}).strict().refine((i) => i.serviceId || i.description, { message: "Informe o serviço ou uma descrição." });

export const OrderCreateSchema = z.object({
  customerId: z.uuid(),
  staffId: z.uuid().nullish(),
  title: z.string().trim().max(160).nullish(),
  description: z.string().max(4000).nullish(),
  scheduledFor: z.iso.datetime({ offset: true }).nullish(),
  address: z.record(z.string(), z.string().max(200)).default({}),
  items: z.array(ItemInput).max(100).default([]),
}).strict();

export const OrderUpdateSchema = OrderCreateSchema.partial().strict()
  .refine((v) => Object.keys(v).length > 0, { message: "Nada para atualizar." });

export const OrderStatusSchema = z.object({
  status: z.enum(ORDER_STATUSES),
  note: z.string().max(500).optional(),
}).strict();

export const OrderRatingSchema = z.object({
  rating: z.number().int().min(1).max(5),
  comment: z.string().max(1000).nullish(),
}).strict();

export const OrderListQuery = z.object({
  status: z.enum([...ORDER_STATUSES, "active"]).optional(),
  q: z.string().trim().max(100).optional(),
  customerId: z.uuid().optional(),
  staffId: z.uuid().optional(),
  ...Paging,
});

/** Transições permitidas. Tudo fora daqui é recusado. */
const TRANSITIONS: Record<OrderStatus, OrderStatus[]> = {
  requested: ["open", "scheduled", "canceled"],
  open: ["scheduled", "in_progress", "done", "canceled"],
  scheduled: ["open", "in_progress", "done", "canceled"],
  in_progress: ["done", "canceled"],
  done: ["in_progress"],
  canceled: ["open"],
};

export const STATUS_LABEL: Record<OrderStatus, string> = {
  requested: "Solicitada", open: "Aberta", scheduled: "Agendada", in_progress: "Em andamento", done: "Concluída", canceled: "Cancelada",
};

type ResolvedItem = { serviceId: string | null; description: string; quantity: number; unitPriceCents: number; unitCostCents: number; commissionRate: number };

async function resolveItems(db: Db, orgId: string, items: z.infer<typeof ItemInput>[]): Promise<ResolvedItem[]> {
  const ids = items.map((i) => i.serviceId).filter((v): v is string => !!v);
  const services = ids.length
    ? (await db.query<{ id: string; name: string; price_cents: number; cost_cents: number; commission_rate: number }>(
        `select id, name, price_cents, cost_cents, commission_rate from app.services where org_id = $1 and id = any($2::uuid[])`,
        [orgId, ids])).rows
    : [];
  return items.map((i) => {
    const s = i.serviceId ? services.find((x) => x.id === i.serviceId) : undefined;
    if (i.serviceId && !s) throw new AppError(422, "invalid_reference", "Um dos serviços não existe nesta empresa.");
    return {
      serviceId: s?.id ?? null,
      description: i.description ?? s!.name,
      quantity: i.quantity,
      unitPriceCents: i.unitPriceCents ?? s?.price_cents ?? 0,
      unitCostCents: s?.cost_cents ?? 0,
      commissionRate: s?.commission_rate ?? 0,
    };
  });
}

async function writeItems(db: Db, orgId: string, orderId: string, items: ResolvedItem[]) {
  await db.query(`delete from app.service_order_items where org_id = $1 and service_order_id = $2`, [orgId, orderId]);
  for (const i of items) {
    await db.query(
      `insert into app.service_order_items (org_id, service_order_id, service_id, description, quantity, unit_price_cents, unit_cost_cents, commission_rate)
       values ($1,$2,$3,$4,$5,$6,$7,$8)`,
      [orgId, orderId, i.serviceId, i.description, i.quantity, i.unitPriceCents, i.unitCostCents, i.commissionRate]);
  }
  const total = items.reduce((a, i) => a + Math.round(i.quantity * i.unitPriceCents), 0);
  const cost = items.reduce((a, i) => a + Math.round(i.quantity * i.unitCostCents), 0);
  await db.query(`update app.service_orders set total_cents = $3, cost_cents = $4 where org_id = $1 and id = $2`, [orgId, orderId, total, cost]);
}

export const ServiceOrderService = {
  async list(ctx: TenantContext, query: z.input<typeof OrderListQuery>) {
    ctx.require("service_orders.read");
    ctx.requireModule("service_orders");
    const f = OrderListQuery.parse(query);
    return ctx.run((db) => ServiceOrderRepository.list(db, ctx.orgId, f));
  },

  async get(ctx: TenantContext, id: string) {
    ctx.require("service_orders.read");
    const o = await ctx.run((db) => ServiceOrderRepository.find(db, ctx.orgId, id));
    if (!o) throw Errors.notFound("Ordem de serviço");
    return o;
  },

  async create(ctx: TenantContext, input: z.input<typeof OrderCreateSchema>, source: "internal" | "ai" = "internal") {
    ctx.require("service_orders.create");
    ctx.requireModule("service_orders");
    const d = OrderCreateSchema.parse(input);
    return ctx.run(async (db) => {
      const items = await resolveItems(db, ctx.orgId, d.items);
      const { rows: n } = await db.query<{ n: number }>(`select app.next_number('service_order') as n`);
      const status: OrderStatus = d.scheduledFor ? "scheduled" : "open";
      const title = d.title ?? (items[0]?.description ?? "Ordem de serviço");
      const { rows } = await db.query<{ id: string }>(
        `insert into app.service_orders (org_id, number, customer_id, staff_id, status, source, title, description, scheduled_for, address, created_by)
         values ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11) returning id`,
        [ctx.orgId, n[0]!.n, d.customerId, d.staffId ?? null, status, source, title, d.description ?? null,
          d.scheduledFor ?? null, d.address, ctx.userId]);
      const id = rows[0]!.id;
      await writeItems(db, ctx.orgId, id, items);
      const order = (await ServiceOrderRepository.find(db, ctx.orgId, id))!;
      await audit(db, ctx, { action: "service_order.create", entityType: "service_order", entityId: id, after: { number: order.number, title, totalCents: order.totalCents } });
      await emitEvent(db, ctx, { type: "service_order.created", entityType: "service_order", entityId: id, payload: { number: order.number } });
      return order;
    });
  },

  async update(ctx: TenantContext, id: string, input: z.input<typeof OrderUpdateSchema>) {
    ctx.require("service_orders.update");
    const p = OrderUpdateSchema.parse(input);
    return ctx.run(async (db) => {
      const cur = await ServiceOrderRepository.find(db, ctx.orgId, id, true);
      if (!cur) throw Errors.notFound("Ordem de serviço");
      if (cur.status === "canceled") throw new AppError(409, "order_closed", "Reabra a OS cancelada antes de editar.");
      if (p.items && cur.status === "done") throw new AppError(409, "order_closed", "Itens de uma OS concluída não podem mudar. Reabra a OS primeiro.");
      await db.query(
        `update app.service_orders set
           customer_id = coalesce($3, customer_id),
           staff_id = case when $4::boolean then $5::uuid else staff_id end,
           title = coalesce($6, title),
           description = case when $7::boolean then $8 else description end,
           scheduled_for = case when $9::boolean then $10::timestamptz else scheduled_for end,
           address = coalesce($11, address),
           status = case when $9::boolean and $10::timestamptz is not null and status in ('open','requested') then 'scheduled' else status end
         where org_id = $1 and id = $2`,
        [ctx.orgId, id, p.customerId ?? null, p.staffId !== undefined, p.staffId ?? null, p.title ?? null,
          p.description !== undefined, p.description ?? null, p.scheduledFor !== undefined, p.scheduledFor ?? null, p.address ?? null]);
      if (p.items) await writeItems(db, ctx.orgId, id, await resolveItems(db, ctx.orgId, p.items));
      const upd = (await ServiceOrderRepository.find(db, ctx.orgId, id))!;
      await audit(db, ctx, { action: "service_order.update", entityType: "service_order", entityId: id, metadata: { fields: Object.keys(p) } });
      return upd;
    });
  },

  /**
   * Muda o status com efeitos colaterais:
   *  • em andamento → marca início
   *  • concluída → marca fim, gera conta a receber, atualiza última compra do cliente
   *  • cancelada → cancela o recebível em aberto
   */
  async changeStatus(ctx: TenantContext, id: string, input: z.input<typeof OrderStatusSchema>) {
    ctx.require("service_orders.update");
    const { status, note } = OrderStatusSchema.parse(input);
    return ctx.run(async (db) => {
      const cur = await ServiceOrderRepository.find(db, ctx.orgId, id, true);
      if (!cur) throw Errors.notFound("Ordem de serviço");
      if (cur.status === status) return cur;
      if (!TRANSITIONS[cur.status].includes(status)) {
        throw new AppError(409, "invalid_transition",
          `Não é possível passar de "${STATUS_LABEL[cur.status]}" para "${STATUS_LABEL[status]}".`);
      }

      await db.query(
        `update app.service_orders set status = $3,
            started_at = case when $3 = 'in_progress' and started_at is null then now() else started_at end,
            completed_at = case when $3 = 'done' then now() when $3 <> 'done' then null else completed_at end
          where org_id = $1 and id = $2`, [ctx.orgId, id, status]);

      if (status === "done") {
        if (cur.totalCents > 0 && ctx.enabledModules.has("finance")) {
          await db.query(
            `insert into app.financial_entries (org_id, direction, description, category_id, customer_id, service_order_id, amount_cents, due_on, created_by)
             select $1, 'in', $3, (select id from app.financial_categories where org_id = $1 and direction = 'in' and name = 'Serviços' limit 1),
                    $4, $2, $5, current_date, $6
              where not exists (select 1 from app.financial_entries where org_id = $1 and service_order_id = $2 and direction = 'in' and status <> 'canceled')`,
            [ctx.orgId, id, `OS #${String(cur.number).padStart(4, "0")} · ${cur.title ?? "Serviço"}`, cur.customer.id, cur.totalCents, ctx.userId]);
        }
        await db.query(`update app.customers set last_purchase_at = now(), last_activity_at = now() where org_id = $1 and id = $2`,
          [ctx.orgId, cur.customer.id]);
      }
      if (status === "canceled") {
        await db.query(
          `update app.financial_entries set status = 'canceled'
            where org_id = $1 and service_order_id = $2 and direction = 'in' and status = 'open'`, [ctx.orgId, id]);
      }

      await db.query(
        `insert into app.activities (org_id, type, subject_type, subject_id, title, body, actor_type, actor_user_id)
         values ($1, 'system', 'customer', $2, $3, $4, $5, $6)`,
        [ctx.orgId, cur.customer.id, `OS #${String(cur.number).padStart(4, "0")}: ${STATUS_LABEL[status]}`, note ?? null, ctx.actor === "ai" ? "ai" : "user", ctx.userId]);
      await audit(db, ctx, {
        action: "service_order.status_change", entityType: "service_order", entityId: id,
        before: { status: cur.status }, after: { status }, metadata: note ? { note } : {},
      });
      await emitEvent(db, ctx, {
        type: status === "done" ? "service_order.completed" : "service_order.status_changed",
        entityType: "service_order", entityId: id, payload: { from: cur.status, to: status, number: cur.number },
      });
      return (await ServiceOrderRepository.find(db, ctx.orgId, id))!;
    });
  },

  async rate(ctx: TenantContext, id: string, input: z.input<typeof OrderRatingSchema>) {
    ctx.require("service_orders.update");
    const r = OrderRatingSchema.parse(input);
    return ctx.run(async (db) => {
      const cur = await ServiceOrderRepository.find(db, ctx.orgId, id, true);
      if (!cur) throw Errors.notFound("Ordem de serviço");
      if (cur.status !== "done") throw new AppError(409, "order_not_done", "Só dá para avaliar uma OS concluída.");
      await db.query(`update app.service_orders set rating = $3, rating_comment = $4 where org_id = $1 and id = $2`,
        [ctx.orgId, id, r.rating, r.comment ?? null]);
      await audit(db, ctx, { action: "service_order.rate", entityType: "service_order", entityId: id, after: r });
      return (await ServiceOrderRepository.find(db, ctx.orgId, id))!;
    });
  },
};
