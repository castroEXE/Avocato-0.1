import type { Db } from "../../infra/db/context.js";
import { iso, isoDate } from "../../core/util/http-schemas.js";

export const ORDER_STATUSES = ["requested", "open", "scheduled", "in_progress", "done", "canceled"] as const;
export type OrderStatus = (typeof ORDER_STATUSES)[number];

export type OrderItem = {
  id: string; serviceId: string | null; productId: string | null; description: string; quantity: number;
  unitPriceCents: number; unitCostCents: number; commissionRate: number; totalCents: number;
};

export type ServiceOrder = {
  id: string; number: number; title: string | null; status: OrderStatus; source: "internal" | "public_request" | "ai";
  customer: { id: string; name: string; phone: string | null; email: string | null };
  staff: { id: string; name: string } | null;
  description: string | null; address: Record<string, unknown>;
  scheduledFor: string | null; preferredDate: string | null; startedAt: string | null; completedAt: string | null;
  totalCents: number; costCents: number; rating: number | null; ratingComment: string | null;
  createdAt: string; updatedAt: string;
  items?: OrderItem[];
  receivable?: { id: string; status: string; amountCents: number; paidAmountCents: number } | null;
};

const SELECT = `
  select o.id, o.number, o.title, o.status, o.source, o.description, o.address, o.scheduled_for, o.preferred_date,
         o.started_at, o.completed_at, o.total_cents, o.cost_cents, o.rating, o.rating_comment, o.created_at, o.updated_at,
         c.id as customer_id, c.name as customer_name, c.phone as customer_phone, c.email::text as customer_email,
         s.id as staff_id, s.name as staff_name
    from app.service_orders o
    join app.customers c on c.org_id = o.org_id and c.id = o.customer_id
    left join app.staff_members s on s.org_id = o.org_id and s.id = o.staff_id`;

// eslint-disable-next-line @typescript-eslint/no-explicit-any
const map = (r: any): ServiceOrder => ({
  id: r.id, number: r.number, title: r.title, status: r.status, source: r.source,
  customer: { id: r.customer_id, name: r.customer_name, phone: r.customer_phone, email: r.customer_email },
  staff: r.staff_id ? { id: r.staff_id, name: r.staff_name } : null,
  description: r.description, address: r.address, scheduledFor: iso(r.scheduled_for), preferredDate: isoDate(r.preferred_date),
  startedAt: iso(r.started_at), completedAt: iso(r.completed_at), totalCents: r.total_cents, costCents: r.cost_cents,
  rating: r.rating, ratingComment: r.rating_comment, createdAt: iso(r.created_at)!, updatedAt: iso(r.updated_at)!,
});

export const ServiceOrderRepository = {
  async list(db: Db, orgId: string, f: { status?: string; q?: string; customerId?: string; staffId?: string; limit: number; offset: number }) {
    const params: unknown[] = [orgId];
    const where = ["o.org_id = $1"];
    if (f.status === "active") where.push(`o.status in ('open','scheduled','in_progress')`);
    else if (f.status) { params.push(f.status); where.push(`o.status = $${params.length}`); }
    if (f.customerId) { params.push(f.customerId); where.push(`o.customer_id = $${params.length}`); }
    if (f.staffId) { params.push(f.staffId); where.push(`o.staff_id = $${params.length}`); }
    if (f.q) {
      params.push(`%${f.q}%`);
      const i = params.length;
      where.push(`(o.title ilike $${i} or c.name ilike $${i} or o.description ilike $${i} or o.number::text = replace($${i}, '%', ''))`);
    }
    params.push(f.limit, f.offset);
    const { rows } = await db.query(
      `${SELECT} where ${where.join(" and ")}
        order by case o.status when 'requested' then 0 when 'in_progress' then 1 when 'scheduled' then 2 when 'open' then 3 else 4 end,
                 coalesce(o.scheduled_for, o.created_at) desc
        limit $${params.length - 1} offset $${params.length}`, params);
    const total = await db.query<{ n: number }>(
      `select count(*)::int as n from app.service_orders o join app.customers c on c.org_id = o.org_id and c.id = o.customer_id
        where ${where.join(" and ")}`, params.slice(0, -2));
    const counts = await db.query<{ status: OrderStatus; n: number }>(
      `select status, count(*)::int as n from app.service_orders where org_id = $1 group by status`, [orgId]);
    return {
      data: rows.map(map),
      total: total.rows[0]?.n ?? 0,
      counts: Object.fromEntries(ORDER_STATUSES.map((s) => [s, counts.rows.find((c) => c.status === s)?.n ?? 0])) as Record<OrderStatus, number>,
    };
  },

  async find(db: Db, orgId: string, id: string, lock = false) {
    const { rows } = await db.query(`${SELECT} where o.org_id = $1 and o.id = $2 ${lock ? "for update of o" : ""}`, [orgId, id]);
    if (!rows[0]) return null;
    const order = map(rows[0]);
    const items = await db.query(
      `select id, service_id, product_id, description, quantity, unit_price_cents, unit_cost_cents, commission_rate
         from app.service_order_items where org_id = $1 and service_order_id = $2 order by description`, [orgId, id]);
    order.items = items.rows.map((i) => ({
      id: i.id, serviceId: i.service_id, productId: i.product_id, description: i.description, quantity: i.quantity,
      unitPriceCents: i.unit_price_cents, unitCostCents: i.unit_cost_cents, commissionRate: i.commission_rate,
      totalCents: Math.round(i.quantity * i.unit_price_cents),
    }));
    const rec = await db.query(
      `select id, status, amount_cents, paid_amount_cents from app.financial_entries
        where org_id = $1 and service_order_id = $2 and direction = 'in' and status <> 'canceled' limit 1`, [orgId, id]);
    order.receivable = rec.rows[0]
      ? { id: rec.rows[0].id, status: rec.rows[0].status, amountCents: rec.rows[0].amount_cents, paidAmountCents: rec.rows[0].paid_amount_cents }
      : null;
    return order;
  },
};
