import { z } from "zod";

const Address = z
  .object({
    street: z.string().max(200).optional(),
    number: z.string().max(20).optional(),
    complement: z.string().max(100).optional(),
    district: z.string().max(100).optional(),
    city: z.string().max(100).optional(),
    state: z.string().max(50).optional(),
    zip: z.string().max(20).optional(),
    country: z.string().max(2).optional(),
  })
  .strict();

export const CustomerCreateSchema = z
  .object({
    kind: z.enum(["person", "company"]).default("person"),
    name: z.string().trim().min(1).max(200),
    email: z.email().max(254).nullish(),
    phone: z.string().trim().max(40).nullish(),
    document: z.string().trim().max(30).nullish(),
    address: Address.default({}),
    status: z.enum(["active", "inactive", "blocked"]).default("active"),
    source: z.string().trim().max(80).nullish(),
    tags: z.array(z.string().trim().min(1).max(40)).max(30).default([]),
    ownerUserId: z.uuid().nullish(),
    notes: z.string().max(5000).nullish(),
    customFields: z.record(z.string(), z.unknown()).default({}),
  })
  .strict();

export const CustomerUpdateSchema = z
  .object({
    kind: z.enum(["person", "company"]),
    name: z.string().trim().min(1).max(200),
    email: z.email().max(254).nullable(),
    phone: z.string().trim().max(40).nullable(),
    document: z.string().trim().max(30).nullable(),
    address: Address,
    status: z.enum(["active", "inactive", "blocked"]),
    source: z.string().trim().max(80).nullable(),
    tags: z.array(z.string().trim().min(1).max(40)).max(30),
    ownerUserId: z.uuid().nullable(),
    notes: z.string().max(5000).nullable(),
    customFields: z.record(z.string(), z.unknown()),
  })
  .partial()
  .strict()
  .refine((v) => Object.keys(v).length > 0, { message: "Envie pelo menos um campo para atualizar." });

export const CustomerListQuerySchema = z.object({
  q: z.string().trim().max(100).optional(),
  status: z.enum(["active", "inactive", "blocked"]).optional(),
  inactiveDays: z.coerce.number().int().min(1).max(3650).optional(), // "clientes sumidos"
  limit: z.coerce.number().int().min(1).max(100).default(25),
  offset: z.coerce.number().int().min(0).default(0),
});

export const CustomerSchema = z.object({
  id: z.uuid(),
  kind: z.enum(["person", "company"]),
  name: z.string(),
  email: z.string().nullable(),
  phone: z.string().nullable(),
  document: z.string().nullable(),
  address: z.record(z.string(), z.unknown()),
  status: z.enum(["active", "inactive", "blocked"]),
  source: z.string().nullable(),
  tags: z.array(z.string()),
  ownerUserId: z.string().nullable(),
  notes: z.string().nullable(),
  customFields: z.record(z.string(), z.unknown()),
  lastActivityAt: z.string().nullable(),
  lastPurchaseAt: z.string().nullable(),
  createdAt: z.string(),
  updatedAt: z.string(),
});

export const CustomerListSchema = z.object({
  data: z.array(CustomerSchema),
  total: z.number().int(),
  limit: z.number().int(),
  offset: z.number().int(),
});

export type CustomerCreateInput = z.input<typeof CustomerCreateSchema>;
export type CustomerUpdateInput = z.infer<typeof CustomerUpdateSchema>;
export type CustomerListQuery = z.input<typeof CustomerListQuerySchema>;
export type Customer = z.infer<typeof CustomerSchema>;
