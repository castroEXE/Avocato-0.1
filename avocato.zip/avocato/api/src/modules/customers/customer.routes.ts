import { z } from "zod";
import type { FastifyPluginAsyncZod } from "fastify-type-provider-zod";
import { tenantOf } from "../../core/http/request.js";
import {
  CustomerCreateSchema,
  CustomerListQuerySchema,
  CustomerListSchema,
  CustomerSchema,
  CustomerUpdateSchema,
} from "./customer.schemas.js";
import { CustomerService } from "./customer.service.js";

const IdParams = z.object({ id: z.uuid() });

/** HTTP é só transporte: valida o formato e delega ao serviço. */
export const customerRoutes: FastifyPluginAsyncZod = async (app) => {
  const config = { tenant: true };

  app.get("/customers", {
    config,
    schema: { tags: ["customers"], querystring: CustomerListQuerySchema, response: { 200: CustomerListSchema } },
  }, (req) => CustomerService.list(tenantOf(req), req.query));

  app.get("/customers/:id", {
    config,
    schema: { tags: ["customers"], params: IdParams, response: { 200: CustomerSchema } },
  }, (req) => CustomerService.get(tenantOf(req), req.params.id));

  app.post("/customers", {
    config,
    schema: { tags: ["customers"], body: CustomerCreateSchema, response: { 201: CustomerSchema } },
  }, async (req, reply) => reply.status(201).send(await CustomerService.create(tenantOf(req), req.body)));

  app.patch("/customers/:id", {
    config,
    schema: { tags: ["customers"], params: IdParams, body: CustomerUpdateSchema, response: { 200: CustomerSchema } },
  }, (req) => CustomerService.update(tenantOf(req), req.params.id, req.body));

  app.delete("/customers/:id", {
    config,
    schema: { tags: ["customers"], params: IdParams },
  }, async (req, reply) => {
    await CustomerService.remove(tenantOf(req), req.params.id);
    return reply.status(204).send();
  });
};
