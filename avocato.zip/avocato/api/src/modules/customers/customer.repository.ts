import type { Db } from "../../infra/db/context.js";
import type { Customer } from "./customer.schemas.js";

type CustomerRow = {
  id: string; kind: Customer["kind"]; name: string; email: string | null; phone: string | null;
  document: string | null; address: Record<string, unknown>; status: Customer["status"]; source: string | null;
  tags: string[]; owner_user_id: string | null; notes: string | null; custom_fields: Record<string, unknown>;
  last_activity_at: Date | null; last_purchase_at: Date | null; created_at: Date; updated_at: Date;
};

const COLUMNS = `id, kind, name, email, phone, document, address, status, source, tags, owner_user_id, notes,
  custom_fields, last_activity_at, last_purchase_at, created_at, updated_at`;

export function toCustomer(r: CustomerRow): Customer {
  return {
    id: r.id, kind: r.kind, name: r.name, email: r.email, phone: r.phone, document: r.document,
    address: r.address, status: r.status, source: r.source, tags: r.tags, ownerUserId: r.owner_user_id,
    notes: r.notes, customFields: r.custom_fields,
    lastActivityAt: r.last_activity_at?.toISOString() ?? null,
    lastPurchaseAt: r.last_purchase_at?.toISOString() ?? null,
    createdAt: r.created_at.toISOString(), updatedAt: r.updated_at.toISOString(),
  };
}

export type CustomerWrite = {
  kind: Customer["kind"]; name: string; email: string | null; phone: string | null; document: string | null;
  address: Record<string, unknown>; status: Customer["status"]; source: string | null; tags: string[];
  ownerUserId: string | null; notes: string | null; customFields: Record<string, unknown>;
};

/**
 * Repositório = só SQL parametrizado. Sem regra de negócio, sem permissão.
 * Toda consulta filtra org_id explicitamente; o RLS é a segunda barreira.
 */
export const CustomerRepository = {
  async list(db: Db, orgId: string, f: { q?: string; status?: string; inactiveDays?: number; limit: number; offset: number }) {
    const where = ["org_id = $1", "deleted_at is null"];
    const params: unknown[] = [orgId];
    if (f.q) {
      params.push(`%${f.q.replace(/[\\%_]/g, (c) => `\\${c}`)}%`);
      const i = params.length;
      where.push(`(name ilike $${i} or email::text ilike $${i} or phone ilike $${i} or document ilike $${i})`);
    }
    if (f.status) {
      params.push(f.status);
      where.push(`status = $${params.length}`);
    }
    if (f.inactiveDays) {
      params.push(f.inactiveDays);
      where.push(`coalesce(last_purchase_at, created_at) < now() - make_interval(days => $${params.length})`);
    }
    params.push(f.limit, f.offset);
    const { rows } = await db.query<CustomerRow & { total: number }>(
      `select ${COLUMNS}, count(*) over() as total
         from app.customers
        where ${where.join(" and ")}
        order by name asc, id asc
        limit $${params.length - 1} offset $${params.length}`,
      params,
    );
    return { rows: rows.map(toCustomer), total: rows[0]?.total ?? 0 };
  },

  async findById(db: Db, orgId: string, id: string, opts: { forUpdate?: boolean } = {}) {
    const { rows } = await db.query<CustomerRow>(
      `select ${COLUMNS} from app.customers
        where org_id = $1 and id = $2 and deleted_at is null
        ${opts.forUpdate ? "for update" : ""}`,
      [orgId, id],
    );
    return rows[0] ? toCustomer(rows[0]) : null;
  },

  async insert(db: Db, orgId: string, createdBy: string, c: CustomerWrite) {
    const { rows } = await db.query<CustomerRow>(
      `insert into app.customers
         (org_id, kind, name, email, phone, document, address, status, source, tags, owner_user_id, notes, custom_fields, created_by)
       values ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14)
       returning ${COLUMNS}`,
      [orgId, c.kind, c.name, c.email, c.phone, c.document, c.address, c.status, c.source, c.tags,
        c.ownerUserId, c.notes, c.customFields, createdBy],
    );
    return toCustomer(rows[0]!);
  },

  async update(db: Db, orgId: string, id: string, c: CustomerWrite) {
    const { rows } = await db.query<CustomerRow>(
      `update app.customers set
          kind = $3, name = $4, email = $5, phone = $6, document = $7, address = $8, status = $9,
          source = $10, tags = $11, owner_user_id = $12, notes = $13, custom_fields = $14
        where org_id = $1 and id = $2 and deleted_at is null
        returning ${COLUMNS}`,
      [orgId, id, c.kind, c.name, c.email, c.phone, c.document, c.address, c.status, c.source, c.tags,
        c.ownerUserId, c.notes, c.customFields],
    );
    return rows[0] ? toCustomer(rows[0]) : null;
  },

  async softDelete(db: Db, orgId: string, id: string) {
    const { rowCount } = await db.query(
      `update app.customers set deleted_at = now() where org_id = $1 and id = $2 and deleted_at is null`,
      [orgId, id],
    );
    return (rowCount ?? 0) > 0;
  },
};
