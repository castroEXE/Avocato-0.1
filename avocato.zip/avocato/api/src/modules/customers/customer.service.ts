import { audit, diff } from "../../core/audit/audit.js";
import type { TenantContext } from "../../core/context.js";
import { loadCustomFieldDefinitions, validateCustomFields } from "../../core/custom-fields/custom-fields.js";
import { Errors } from "../../core/errors.js";
import { emitEvent } from "../../core/events/outbox.js";
import { CustomerRepository, type CustomerWrite } from "./customer.repository.js";
import {
  CustomerCreateSchema,
  CustomerListQuerySchema,
  CustomerUpdateSchema,
  type Customer,
  type CustomerCreateInput,
  type CustomerListQuery,
  type CustomerUpdateInput,
} from "./customer.schemas.js";

/**
 * Application Service de clientes.
 * É o ÚNICO caminho para ler/escrever clientes — usado pelas rotas HTTP,
 * pelas ferramentas da IA e (Fase 12) pelas automações.
 * Permissão, módulo, validação, auditoria e evento ficam aqui.
 */
export const CustomerService = {
  async list(ctx: TenantContext, query: CustomerListQuery) {
    ctx.require("customers.read");
    const q = CustomerListQuerySchema.parse(query);
    return ctx.run(async (db) => {
      const { rows, total } = await CustomerRepository.list(db, ctx.orgId, q);
      return { data: rows, total, limit: q.limit, offset: q.offset };
    });
  },

  async get(ctx: TenantContext, id: string): Promise<Customer> {
    ctx.require("customers.read");
    const found = await ctx.run((db) => CustomerRepository.findById(db, ctx.orgId, id));
    if (!found) throw Errors.notFound("Cliente");
    return found;
  },

  async create(ctx: TenantContext, input: CustomerCreateInput): Promise<Customer> {
    ctx.require("customers.create");
    const data = CustomerCreateSchema.parse(input);
    if (data.ownerUserId) ctx.require("members.read");

    return ctx.run(async (db) => {
      const defs = await loadCustomFieldDefinitions(db, ctx.orgId, "customer");
      const write: CustomerWrite = {
        kind: data.kind,
        name: data.name,
        email: data.email?.toLowerCase() ?? null,
        phone: data.phone ?? null,
        document: data.document ?? null,
        address: data.address,
        status: data.status,
        source: data.source ?? null,
        tags: [...new Set(data.tags)],
        ownerUserId: data.ownerUserId ?? null,
        notes: data.notes ?? null,
        customFields: validateCustomFields(defs, data.customFields, "create"),
      };
      const customer = await CustomerRepository.insert(db, ctx.orgId, ctx.userId, write);
      await audit(db, ctx, {
        action: "customer.create", entityType: "customer", entityId: customer.id, after: customer,
      });
      await emitEvent(db, ctx, {
        type: "customer.created", entityType: "customer", entityId: customer.id,
        payload: { name: customer.name, source: customer.source },
      });
      return customer;
    });
  },

  async update(ctx: TenantContext, id: string, input: CustomerUpdateInput): Promise<Customer> {
    ctx.require("customers.update");
    const patch = CustomerUpdateSchema.parse(input);

    return ctx.run(async (db) => {
      const current = await CustomerRepository.findById(db, ctx.orgId, id, { forUpdate: true });
      if (!current) throw Errors.notFound("Cliente");

      let customFields = current.customFields;
      if (patch.customFields) {
        const defs = await loadCustomFieldDefinitions(db, ctx.orgId, "customer");
        customFields = { ...current.customFields, ...validateCustomFields(defs, patch.customFields, "patch") };
      }

      const next: CustomerWrite = {
        kind: patch.kind ?? current.kind,
        name: patch.name ?? current.name,
        email: patch.email !== undefined ? (patch.email?.toLowerCase() ?? null) : current.email,
        phone: patch.phone !== undefined ? patch.phone : current.phone,
        document: patch.document !== undefined ? patch.document : current.document,
        address: patch.address ?? current.address,
        status: patch.status ?? current.status,
        source: patch.source !== undefined ? patch.source : current.source,
        tags: patch.tags ? [...new Set(patch.tags)] : current.tags,
        ownerUserId: patch.ownerUserId !== undefined ? patch.ownerUserId : current.ownerUserId,
        notes: patch.notes !== undefined ? patch.notes : current.notes,
        customFields,
      };

      const updated = await CustomerRepository.update(db, ctx.orgId, id, next);
      if (!updated) throw Errors.notFound("Cliente");

      const changes = diff(current, updated);
      if (Object.keys(changes.after).length > 0) {
        await audit(db, ctx, { action: "customer.update", entityType: "customer", entityId: id, ...changes });
        await emitEvent(db, ctx, {
          type: "customer.updated", entityType: "customer", entityId: id,
          payload: { changed: Object.keys(changes.after) },
        });
      }
      return updated;
    });
  },

  async remove(ctx: TenantContext, id: string): Promise<void> {
    ctx.require("customers.delete");
    await ctx.run(async (db) => {
      const current = await CustomerRepository.findById(db, ctx.orgId, id, { forUpdate: true });
      if (!current) throw Errors.notFound("Cliente");
      await CustomerRepository.softDelete(db, ctx.orgId, id);
      await audit(db, ctx, { action: "customer.delete", entityType: "customer", entityId: id, before: current });
      await emitEvent(db, ctx, { type: "customer.deleted", entityType: "customer", entityId: id });
    });
  },
};
