/**
 * Teste ponta a ponta: Fastify + Postgres real com as migrations aplicadas.
 * Precisa de:
 *   TEST_DATABASE_URL        → conexão como o usuário da API (avocato_api)
 *   TEST_ADMIN_DATABASE_URL  → conexão do dono do schema (simula o Supabase Auth)
 * Sem essas variáveis, o arquivo é pulado.
 */
import { randomUUID } from "node:crypto";
import { SignJWT } from "jose";
import pg from "pg";
import { afterAll, beforeAll, describe, expect, it } from "vitest";
import { buildApp } from "../src/app.js";
import { createToolRegistry } from "../src/ai/index.js";
import { TenantContext } from "../src/core/context.js";
import { PERMISSIONS, isPermission, type ModuleKey } from "../src/core/rbac/permissions.js";
import { createSupabaseVerifier } from "../src/infra/auth/jwt.js";
import { createPool } from "../src/infra/db/pool.js";

const API_URL = process.env.TEST_DATABASE_URL;
const ADMIN_URL = process.env.TEST_ADMIN_DATABASE_URL;
const SUPABASE_URL = "https://local.supabase.test";
const SECRET = "test-secret-with-at-least-32-characters!!";

describe.skipIf(!API_URL || !ADMIN_URL)("API Avocato (integração)", () => {
  let app: Awaited<ReturnType<typeof buildApp>>;
  let pool: pg.Pool;
  let admin: pg.Pool;
  const ana = randomUUID(), bruno = randomUUID(), carla = randomUUID();
  let orgA = "", orgB = "", customerA = "";

  const token = (sub: string) =>
    new SignJWT({ email: `${sub}@t.test`, role: "authenticated" })
      .setProtectedHeader({ alg: "HS256" })
      .setSubject(sub).setIssuer(`${SUPABASE_URL}/auth/v1`).setAudience("authenticated")
      .setIssuedAt().setExpirationTime("10m")
      .sign(new TextEncoder().encode(SECRET));

  async function call(method: "GET" | "POST" | "PATCH" | "DELETE", url: string, user: string, opts: { org?: string; body?: unknown } = {}) {
    const headers: Record<string, string> = { authorization: `Bearer ${await token(user)}` };
    if (opts.org) headers["x-organization-id"] = opts.org;
    const res = await app.inject({ method, url, headers, ...(opts.body !== undefined ? { payload: opts.body as object } : {}) });
    return { status: res.statusCode, body: res.body ? JSON.parse(res.body) : null };
  }

  /** Executa SQL como um usuário dentro da empresa (FORCE RLS vale até para o dono das tabelas). */
  async function asTenant(user: string, org: string, sql: string, params: unknown[]) {
    const c = await admin.connect();
    try {
      await c.query("begin");
      await c.query("set local role avocato_app");
      await c.query("select set_config('app.user_id', $1, true), set_config('app.org_id', $2, true)", [user, org]);
      await c.query(sql, params);
      await c.query("commit");
    } catch (e) {
      await c.query("rollback");
      throw e;
    } finally {
      c.release();
    }
  }

  beforeAll(async () => {
    pool = createPool(API_URL!, 5);
    admin = new pg.Pool({ connectionString: ADMIN_URL });
    for (const [id, name] of [[ana, "Ana"], [bruno, "Bruno"], [carla, "Carla"]] as const) {
      await admin.query(`insert into auth.users (id, email, raw_user_meta_data) values ($1, $2, $3)`,
        [id, `${id}@t.test`, { full_name: name }]);
    }
    app = await buildApp({
      env: { NODE_ENV: "test", LOG_LEVEL: "silent", CORS_ORIGINS: [], RATE_LIMIT_MAX: 1000 },
      pool,
      verifyToken: createSupabaseVerifier({ supabaseUrl: SUPABASE_URL, jwtSecret: SECRET }),
    });
  });

  afterAll(async () => {
    await app?.close();
    await pool?.end();
    await admin?.end();
  });

  it("health é público; o resto exige token válido", async () => {
    expect((await app.inject({ method: "GET", url: "/health" })).statusCode).toBe(200);
    expect((await app.inject({ method: "GET", url: "/v1/me" })).statusCode).toBe(401);
    const forged = await app.inject({ method: "GET", url: "/v1/me", headers: { authorization: "Bearer abc.def.ghi" } });
    expect(forged.statusCode).toBe(401);
  });

  it("catálogo de permissões do código bate com o banco", async () => {
    const { rows } = await admin.query<{ key: string }>(`select key from app.permissions order by key`);
    expect(rows.map((r) => r.key)).toEqual([...PERMISSIONS].sort());
  });

  it("cria empresas e o criador vira owner", async () => {
    const a = await call("POST", "/v1/organizations", ana, { body: { name: "Pet Shop Patas" } });
    expect(a.status).toBe(201);
    orgA = a.body.id;
    const b = await call("POST", "/v1/organizations", bruno, { body: { name: "Elétrica Bruno" } });
    orgB = b.body.id;

    const me = await call("GET", "/v1/me", ana);
    expect(me.body.organizations).toEqual([expect.objectContaining({ id: orgA, roleKey: "owner" })]);
    expect(me.body.isPlatformAdmin).toBe(false);
  });

  it("contexto da empresa traz o que o frontend precisa para se adaptar", async () => {
    const ctx = await call("GET", "/v1/organization/context", ana, { org: orgA });
    expect(ctx.status).toBe(200);
    expect(ctx.body.role.key).toBe("owner");
    expect(ctx.body.permissions).toContain("finance.authorize_payment");
    expect(ctx.body.enabledModules).toEqual(
      ["ai", "appointments", "core", "crm", "customers", "finance", "reports", "service_orders", "services", "team"]);
    expect(ctx.body.subscription).toMatchObject({ planKey: "starter", status: "trialing" });
  });

  it("configuração dinâmica valida dependências entre módulos", async () => {
    const bad = await call("PATCH", "/v1/organization/settings", ana, {
      org: orgA, body: { enabledModules: { banking: true, finance: false } },
    });
    expect(bad.status).toBe(422);
    expect(bad.body.error.code).toBe("module_dependency");

    const ok = await call("PATCH", "/v1/organization/settings", ana, {
      org: orgA,
      body: {
        enabledModules: { crm: true, appointments: true, finance: true, banking: true, fleet: false },
        terminology: { customer: "Tutor" },
        businessProfile: { segment: "pet_shop", employees: 5, hasExternalStaff: false },
      },
    });
    expect(ok.status).toBe(200);
    expect(ok.body.terminology).toEqual({ customer: "Tutor" });
    const ctx = await call("GET", "/v1/organization/context", ana, { org: orgA });
    expect(ctx.body.enabledModules).toEqual(expect.arrayContaining(["appointments", "banking", "finance"]));
    expect(ctx.body.enabledModules).not.toContain("fleet");
  });

  it("CRUD de clientes com auditoria e evento", async () => {
    const created = await call("POST", "/v1/customers", ana, {
      org: orgA, body: { name: "João Silva", phone: "21999999999", email: "JOAO@exemplo.com", tags: ["vip", "vip"] },
    });
    expect(created.status).toBe(201);
    expect(created.body).toMatchObject({ name: "João Silva", email: "joao@exemplo.com", tags: ["vip"] });
    customerA = created.body.id;

    const upd = await call("PATCH", `/v1/customers/${customerA}`, ana, { org: orgA, body: { phone: "21988887777" } });
    expect(upd.body.phone).toBe("21988887777");

    const list = await call("GET", "/v1/customers?q=jo%C3%A3o", ana, { org: orgA });
    expect(list.body.total).toBe(1);

    const { rows: logs } = await admin.query(
      `select action, actor_type, before, after from app.audit_logs where org_id = $1 and entity_id = $2 order by id`,
      [orgA, customerA]);
    expect(logs.map((l) => l.action)).toEqual(["customer.create", "customer.update"]);
    expect(logs[1]).toMatchObject({ actor_type: "user", before: { phone: "21999999999" }, after: { phone: "21988887777" } });

    const { rows: ev } = await admin.query(`select type from app.domain_events where org_id = $1 order by id`, [orgA]);
    expect(ev.map((e) => e.type)).toEqual(
      expect.arrayContaining(["organization.configured", "customer.created", "customer.updated"]));
  });

  it("validação de entrada devolve erro legível", async () => {
    const r = await call("POST", "/v1/customers", ana, { org: orgA, body: { name: "", email: "x" } });
    expect(r.status).toBe(400);
    expect(r.body.error.code).toBe("validation_error");
  });

  it("isolamento: outra empresa não vê, não acessa e não adivinha", async () => {
    const asB = await call("GET", "/v1/customers", bruno, { org: orgB });
    expect(asB.body.total).toBe(0);

    const intoA = await call("GET", "/v1/customers", bruno, { org: orgA });
    expect(intoA.status).toBe(403);
    expect(intoA.body.error.code).toBe("tenant_forbidden");

    const byId = await call("GET", `/v1/customers/${customerA}`, bruno, { org: orgB });
    expect(byId.status).toBe(404);

    const noHeader = await call("GET", "/v1/customers", ana);
    expect(noHeader.body.error.code).toBe("tenant_required");
  });

  it("campos personalizados definidos pela empresa são validados", async () => {
    // Sem contexto de tenant, nem o dono das tabelas consegue gravar (FORCE RLS)
    await expect(admin.query(
      `insert into app.custom_field_definitions (org_id, entity, key, label, field_type) values ($1, 'customer', 'x', 'X', 'text')`,
      [orgA])).rejects.toThrow(/row-level security/);
    await asTenant(ana, orgA,
      `insert into app.custom_field_definitions (org_id, entity, key, label, field_type, is_required)
       values ($1, 'customer', 'pet_name', 'Nome do pet', 'text', true)`, [orgA]);
    const missing = await call("POST", "/v1/customers", ana, { org: orgA, body: { name: "Maria" } });
    expect(missing.status).toBe(400);
    const ok = await call("POST", "/v1/customers", ana, { org: orgA, body: { name: "Maria", customFields: { pet_name: "Thor" } } });
    expect(ok.status).toBe(201);
    expect(ok.body.customFields).toEqual({ pet_name: "Thor" });
    // empresa B não herda os campos da A
    const inB = await call("POST", "/v1/customers", bruno, { org: orgB, body: { name: "Pedro" } });
    expect(inB.status).toBe(201);
  });

  it("RBAC: papel de leitura não escreve e não usa IA", async () => {
    await admin.query(
      `insert into app.memberships (org_id, user_id, role_id)
       select $1, $2, id from app.roles where org_id = $1 and key = 'viewer'`, [orgA, carla]);
    expect((await call("GET", "/v1/customers", carla, { org: orgA })).status).toBe(200);
    const w = await call("POST", "/v1/customers", carla, { org: orgA, body: { name: "X" } });
    expect(w.status).toBe(403);
    expect(w.body.error.details).toEqual({ permission: "customers.create" });
    expect((await call("GET", "/v1/ai/tools", carla, { org: orgA })).body.tools).toEqual([]);
  });

  it("IA: exclusão proposta pela IA fica pendente até um humano aprovar", async () => {
    const tools = await call("GET", "/v1/ai/tools", ana, { org: orgA });
    expect(tools.body.tools.map((t: { name: string }) => t.name))
      .toEqual(expect.arrayContaining(["create_customer", "delete_customer", "search_customers", "create_service_order", "business_summary"]));

    // Simula o loop do modelo (Fase 13) chamando a tool diretamente
    const perms = (await call("GET", "/v1/organization/context", ana, { org: orgA })).body.permissions as string[];
    const ctx = new TenantContext(pool, ana, orgA, new Set(perms.filter(isPermission)), new Set<ModuleKey>(["core", "customers", "ai"]));
    const registry = createToolRegistry();

    const made = await registry.invoke(ctx, "create_customer", { name: "Cliente via IA", customFields: { pet_name: "Bob" } });
    expect(made.status).toBe("executed");
    const viaAi = (made as { output: { id: string } }).output.id;

    const proposed = await registry.invoke(ctx, "delete_customer", { customer_id: viaAi, reason: "duplicado" });
    expect(proposed.status).toBe("awaiting_approval");
    expect((await call("GET", `/v1/customers/${viaAi}`, ana, { org: orgA })).status).toBe(200);

    const pending = await call("GET", "/v1/ai/actions?status=awaiting_approval", ana, { org: orgA });
    expect(pending.body.data).toHaveLength(1);

    const approved = await call("POST", `/v1/ai/actions/${(proposed as { actionId: string }).actionId}/approve`, ana, { org: orgA });
    expect(approved.body.status).toBe("executed");
    expect((await call("GET", `/v1/customers/${viaAi}`, ana, { org: orgA })).status).toBe(404);

    const { rows } = await admin.query(
      `select action, actor_type, metadata->>'aiActionId' as ai from app.audit_logs where org_id = $1 and entity_id = $2 order by id`,
      [orgA, viaAi]);
    expect(rows).toEqual([
      { action: "customer.create", actor_type: "ai", ai: expect.any(String) },
      { action: "customer.delete", actor_type: "ai", ai: (proposed as { actionId: string }).actionId },
    ]);
  });

  it("Super Admin é separado de usuário de empresa", async () => {
    expect((await call("GET", "/v1/admin/organizations", ana)).status).toBe(403);
    await admin.query(`insert into app.platform_admins (user_id, note) values ($1, 'teste')`, [ana]);
    const list = await call("GET", "/v1/admin/organizations", ana);
    expect(list.status).toBe(200);
    expect(list.body.data.map((o: { id: string }) => o.id)).toEqual(expect.arrayContaining([orgA, orgB]));

    const sus = await call("PATCH", `/v1/admin/organizations/${orgB}/status`, ana, { body: { status: "suspended", reason: "teste de suspensão" } });
    expect(sus.status).toBe(200);
    // empresa suspensa perde o acesso imediatamente (checado no banco)
    expect((await call("GET", "/v1/customers", bruno, { org: orgB })).status).toBe(403);
  });
});
