import { describe, expect, it } from "vitest";
import { z } from "zod";
import { diff } from "../src/core/audit/audit.js";
import { TenantContext } from "../src/core/context.js";
import { validateCustomFields, type CustomFieldDefinition } from "../src/core/custom-fields/custom-fields.js";
import { AppError } from "../src/core/errors.js";
import type { Permission } from "../src/core/rbac/permissions.js";
import type { AiActionRecord, AiActionStore } from "../src/ai/tools/action-store.js";
import { ToolRegistry } from "../src/ai/tools/registry.js";
import { defineTool } from "../src/ai/tools/tool.js";
import type pg from "pg";

describe("audit diff", () => {
  it("mantém só o que mudou e ignora updatedAt", () => {
    const r = diff({ a: 1, b: "x", updatedAt: "1" }, { a: 2, b: "x", updatedAt: "2" });
    expect(r).toEqual({ before: { a: 1 }, after: { a: 2 } });
  });
});

describe("campos personalizados", () => {
  const defs: CustomFieldDefinition[] = [
    { key: "pet_name", label: "Nome do pet", fieldType: "text", options: [], isRequired: true },
    { key: "porte", label: "Porte", fieldType: "select", options: ["P", "M", "G"], isRequired: false },
    { key: "peso", label: "Peso", fieldType: "number", options: [], isRequired: false },
  ];

  it("aceita valores válidos", () => {
    expect(validateCustomFields(defs, { pet_name: "Thor", porte: "G", peso: 32.5 }, "create"))
      .toEqual({ pet_name: "Thor", porte: "G", peso: 32.5 });
  });

  it("exige obrigatórios só na criação", () => {
    expect(() => validateCustomFields(defs, {}, "create")).toThrow(AppError);
    expect(validateCustomFields(defs, { peso: 10 }, "patch")).toEqual({ peso: 10 });
  });

  it("rejeita campo desconhecido e opção inválida", () => {
    try {
      validateCustomFields(defs, { pet_name: "Thor", raca: "SRD", porte: "XG" }, "create");
      expect.fail("deveria lançar");
    } catch (e) {
      const details = (e as AppError).details as { field: string }[];
      expect(details.map((d) => d.field).sort()).toEqual(["customFields.porte", "customFields.raca"]);
    }
  });
});

// ---------------------------------------------------------------------
// ToolRegistry com store em memória e contexto falso (sem banco)
// ---------------------------------------------------------------------
class MemoryStore implements AiActionStore {
  rows = new Map<string, AiActionRecord>();
  async create(_ctx: TenantContext, a: Omit<AiActionRecord, "createdAt">) {
    this.rows.set(a.id, { ...a, createdAt: new Date().toISOString() });
  }
  async decide(_ctx: TenantContext, id: string, d: "approved" | "rejected") {
    const r = this.rows.get(id);
    if (!r || r.status !== "awaiting_approval") return null;
    r.status = d;
    return r;
  }
  async finish(_ctx: TenantContext, id: string, f: { status: "executed" | "failed"; output?: unknown; error?: string }) {
    const r = this.rows.get(id)!;
    r.status = f.status;
    r.output = f.output ?? null;
    r.error = f.error ?? null;
  }
  async list() {
    return [...this.rows.values()];
  }
}

function fakeCtx(perms: Permission[]) {
  return new TenantContext(null as unknown as pg.Pool, "u1", "o1", new Set(perms), new Set(["core"]));
}

describe("ToolRegistry", () => {
  const calls: string[] = [];
  const echo = defineTool({
    name: "echo_name",
    description: "eco",
    permission: "customers.create",
    risk: "low",
    input: z.object({ name: z.string().min(2) }),
    summarize: (i) => `eco ${i.name}`,
    execute: async (ctx, i) => {
      calls.push(`${ctx.actor}:${i.name}`);
      return { ok: true };
    },
  });
  const wipe = defineTool({
    name: "wipe_things",
    description: "apaga",
    permission: "customers.delete",
    risk: "sensitive",
    input: z.object({ id: z.string() }),
    summarize: (i) => `apagar ${i.id}`,
    execute: async (ctx, i) => {
      calls.push(`${ctx.actor}:wipe:${i.id}`);
      return { deleted: i.id };
    },
  });

  it("executa tool de baixo risco como ator 'ai' e registra a ação", async () => {
    const store = new MemoryStore();
    const reg = new ToolRegistry(store).register(echo, wipe);
    const r = await reg.invoke(fakeCtx(["ai.use", "customers.create"]), "echo_name", { name: "Ana" });
    expect(r.status).toBe("executed");
    expect(calls).toContain("ai:Ana");
    expect([...store.rows.values()][0]?.status).toBe("executed");
  });

  it("devolve erros de entrada ao modelo em vez de quebrar", async () => {
    const reg = new ToolRegistry(new MemoryStore()).register(echo);
    const r = await reg.invoke(fakeCtx(["ai.use", "customers.create"]), "echo_name", { name: "A" });
    expect(r.status).toBe("invalid_input");
  });

  it("a IA nunca faz mais do que o usuário pode", async () => {
    const reg = new ToolRegistry(new MemoryStore()).register(echo);
    await expect(reg.invoke(fakeCtx(["ai.use"]), "echo_name", { name: "Ana" })).rejects.toMatchObject({ statusCode: 403 });
    expect(reg.specsFor(fakeCtx(["ai.use"]))).toEqual([]);
    expect(reg.specsFor(fakeCtx(["customers.create"]))).toEqual([]); // sem ai.use
  });

  it("ação sensível para em aprovação e só roda depois de aprovada por quem pode", async () => {
    const store = new MemoryStore();
    const reg = new ToolRegistry(store).register(wipe);
    const user = fakeCtx(["ai.use", "customers.delete"]);
    const r = await reg.invoke(user, "wipe_things", { id: "c9" });
    expect(r.status).toBe("awaiting_approval");
    expect(calls).not.toContain("ai:wipe:c9");

    await expect(reg.approve(user, (r as { actionId: string }).actionId)).rejects.toMatchObject({ statusCode: 403 });

    const approver = fakeCtx(["ai.use", "customers.delete", "ai.approve_actions"]);
    const done = await reg.approve(approver, (r as { actionId: string }).actionId);
    expect(done.status).toBe("executed");
    expect(calls).toContain("ai:wipe:c9");

    // não executa duas vezes
    await expect(reg.approve(approver, (r as { actionId: string }).actionId)).rejects.toMatchObject({ statusCode: 404 });
  });

  it("gera JSON Schema para a API do modelo", () => {
    const reg = new ToolRegistry(new MemoryStore()).register(echo, wipe);
    const specs = reg.specsFor(fakeCtx(["ai.use", "customers.create", "customers.delete"]));
    expect(specs.map((s) => s.name)).toEqual(["echo_name", "wipe_things"]);
    expect(specs[0]?.input_schema).toMatchObject({ type: "object", required: ["name"] });
    expect(specs[1]?.description).toMatch(/aprovação humana/);
  });
});

// ---------------------------------------------------------------------
// Cliente de IA (formato OpenAI): monta a requisição certa para o Groq
// ---------------------------------------------------------------------
import { createLlmClient } from "../src/ai/llm.js";

describe("cliente de IA", () => {
  it("sem chave, fica desligado", () => {
    expect(createLlmClient({ AI_PROVIDER: "groq", AI_API_KEY: undefined, AI_MODEL: undefined, AI_BASE_URL: undefined })).toBeNull();
  });

  it("chama /chat/completions do provedor com ferramentas e lê tool_calls", async () => {
    let seen: { url: string; body: Record<string, unknown>; auth: string } | null = null;
    const fakeFetch = (async (url: string, init: RequestInit) => {
      seen = { url, body: JSON.parse(init.body as string), auth: (init.headers as Record<string, string>).authorization! };
      return new Response(JSON.stringify({
        model: "llama-3.3-70b-versatile",
        choices: [{ message: { content: null, tool_calls: [{ id: "x", type: "function", function: { name: "list_services", arguments: "{}" } }] } }],
        usage: { prompt_tokens: 12, completion_tokens: 3 },
      }), { status: 200 });
    }) as unknown as typeof fetch;
    const c = createLlmClient({ AI_PROVIDER: "groq", AI_API_KEY: "gsk_test", AI_MODEL: undefined, AI_BASE_URL: undefined }, fakeFetch)!;
    const r = await c.chat({ messages: [{ role: "user", content: "oi" }], tools: [{ type: "function", function: { name: "list_services", description: "d", parameters: {} } }] });
    expect(seen!.url).toBe("https://api.groq.com/openai/v1/chat/completions");
    expect(seen!.auth).toBe("Bearer gsk_test");
    expect(seen!.body).toMatchObject({ model: "llama-3.3-70b-versatile", tool_choice: "auto" });
    expect(r.message.tool_calls?.[0]?.function.name).toBe("list_services");
    expect(r.usage).toEqual({ inputTokens: 12, outputTokens: 3 });
  });

  it("Gemini usa o endpoint compatível do Google", async () => {
    let url = "";
    const fakeFetch = (async (u: string) => {
      url = u;
      return new Response(JSON.stringify({ choices: [{ message: { content: "olá" } }] }), { status: 200 });
    }) as unknown as typeof fetch;
    const c = createLlmClient({ AI_PROVIDER: "gemini", AI_API_KEY: "k", AI_MODEL: undefined, AI_BASE_URL: undefined }, fakeFetch)!;
    expect((await c.chat({ messages: [], tools: [] })).message.content).toBe("olá");
    expect(url).toBe("https://generativelanguage.googleapis.com/v1beta/openai/chat/completions");
  });
});
