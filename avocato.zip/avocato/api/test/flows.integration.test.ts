/**
 * Fluxos de negócio ponta a ponta: catálogo → OS → financeiro → painel,
 * agenda, recorrência, formulário público, avatar e chat da IA (com um
 * modelo simulado, sem chamar a internet).
 */
import { randomUUID } from "node:crypto";
import { SignJWT } from "jose";
import pg from "pg";
import { afterAll, beforeAll, describe, expect, it } from "vitest";
import { buildApp } from "../src/app.js";
import type { LlmClient, LlmResponse } from "../src/ai/llm.js";
import { createSupabaseVerifier } from "../src/infra/auth/jwt.js";
import { createPool } from "../src/infra/db/pool.js";

const API_URL = process.env.TEST_DATABASE_URL;
const ADMIN_URL = process.env.TEST_ADMIN_DATABASE_URL;
const SUPABASE_URL = "https://local.supabase.test";
const SECRET = "test-secret-with-at-least-32-characters!!";

/** Modelo falso: devolve respostas pré-programadas e grava o que recebeu. */
function scriptedLlm(script: ((msgs: unknown[]) => LlmResponse["message"])[]): LlmClient & { calls: unknown[][] } {
  const calls: unknown[][] = [];
  let i = 0;
  return {
    provider: "fake", model: "fake-1", calls,
    async chat({ messages }) {
      calls.push(messages);
      const step = script[Math.min(i++, script.length - 1)]!;
      return { message: step(messages), usage: { inputTokens: 10, outputTokens: 5 }, model: "fake-1" };
    },
  };
}

describe.skipIf(!API_URL || !ADMIN_URL)("Fluxos do Avocato", () => {
  let app: Awaited<ReturnType<typeof buildApp>>;
  let pool: pg.Pool;
  let admin: pg.Pool;
  const owner = randomUUID();
  let org = "", slug = "", customer = "", service = "", staff = "", order = "";
  let llm: ReturnType<typeof scriptedLlm>;

  const token = (sub: string) =>
    new SignJWT({ role: "authenticated" }).setProtectedHeader({ alg: "HS256" }).setSubject(sub)
      .setIssuer(`${SUPABASE_URL}/auth/v1`).setAudience("authenticated").setIssuedAt().setExpirationTime("10m")
      .sign(new TextEncoder().encode(SECRET));

  async function call(method: "GET" | "POST" | "PATCH" | "DELETE", url: string, body?: unknown, opts: { anon?: boolean } = {}) {
    const headers: Record<string, string> = {};
    if (!opts.anon) {
      headers.authorization = `Bearer ${await token(owner)}`;
      if (org) headers["x-organization-id"] = org;
    }
    const res = await app.inject({ method, url, headers, ...(body !== undefined ? { payload: body as object } : {}) });
    return { status: res.statusCode, body: res.body ? JSON.parse(res.body) : null };
  }

  beforeAll(async () => {
    pool = createPool(API_URL!, 5);
    admin = new pg.Pool({ connectionString: ADMIN_URL });
    await admin.query(`insert into auth.users (id, email, raw_user_meta_data) values ($1, $2, '{"full_name":"Dona Rosa"}')`, [owner, `${owner}@t.test`]);
    llm = scriptedLlm([]);
    app = await buildApp({
      env: { NODE_ENV: "test", LOG_LEVEL: "silent", CORS_ORIGINS: [], RATE_LIMIT_MAX: 1000 },
      pool, verifyToken: createSupabaseVerifier({ supabaseUrl: SUPABASE_URL, jwtSecret: SECRET }), llm,
    });
    const created = await call("POST", "/v1/organizations", { name: "Elétrica Rosa" });
    org = created.body.id;
    slug = created.body.slug;
  });

  afterAll(async () => {
    await app?.close();
    await pool?.end();
    await admin?.end();
  });

  it("catálogo: serviço com margem calculada e equipe", async () => {
    const s = await call("POST", "/v1/services", { name: "Instalação de tomada", priceCents: 18000, costCents: 5000, commissionRate: 0.2, durationMinutes: 60 });
    expect(s.status).toBe(201);
    expect(s.body.marginCents).toBe(9400);
    service = s.body.id;
    const st = await call("POST", "/v1/staff", { name: "Carlos", kind: "freelancer", jobTitle: "Eletricista", commissionRate: 0.2 });
    expect(st.status).toBe(201);
    staff = st.body.id;
    const c = await call("POST", "/v1/customers", { name: "Paulo Mendes", phone: "21 98888-7777" });
    customer = c.body.id;
  });

  it("OS: totais pelos itens, transições válidas e recebível ao concluir", async () => {
    const o = await call("POST", "/v1/service-orders", {
      customerId: customer, staffId: staff, items: [{ serviceId: service, quantity: 2 }, { description: "Deslocamento", unitPriceCents: 3000 }],
    });
    expect(o.status).toBe(201);
    expect(o.body).toMatchObject({ number: 1, status: "open", totalCents: 39000, costCents: 10000, title: "Instalação de tomada" });
    order = o.body.id;

    const bad = await call("POST", `/v1/service-orders/${order}/status`, { status: "requested" });
    expect(bad.status).toBe(409);
    expect(bad.body.error.code).toBe("invalid_transition");

    expect((await call("POST", `/v1/service-orders/${order}/status`, { status: "in_progress" })).body.startedAt).toBeTruthy();
    const done = await call("POST", `/v1/service-orders/${order}/status`, { status: "done" });
    expect(done.body.status).toBe("done");

    const detail = await call("GET", `/v1/service-orders/${order}`);
    expect(detail.body.items).toHaveLength(2);
    expect(detail.body.receivable).toMatchObject({ amountCents: 39000, status: "open" });

    // concluir de novo não duplica o recebível
    await call("POST", `/v1/service-orders/${order}/status`, { status: "in_progress" });
    await call("POST", `/v1/service-orders/${order}/status`, { status: "done" });
    const { rows } = await admin.query(`select count(*)::int as n from app.financial_entries where service_order_id = $1`, [order]);
    expect(rows[0].n).toBe(1);

    const rated = await call("POST", `/v1/service-orders/${order}/rating`, { rating: 5, comment: "Ótimo" });
    expect(rated.body.rating).toBe(5);
  });

  it("financeiro: baixa, parcelamento, recorrência e painel", async () => {
    const list = await call("GET", "/v1/finance/entries?direction=in&status=open");
    const entry = list.body.data.find((e: { serviceOrderId: string }) => e.serviceOrderId === order);
    expect(list.body.totals.receivableOpenCents).toBe(39000);

    const partial = await call("POST", `/v1/finance/entries/${entry.id}/pay`, { amountCents: 9000, paymentMethod: "pix" });
    expect(partial.body).toMatchObject({ status: "partially_paid", paidAmountCents: 9000 });
    const full = await call("POST", `/v1/finance/entries/${entry.id}/pay`, {});
    expect(full.body.status).toBe("paid");
    expect((await call("POST", `/v1/finance/entries/${entry.id}/pay`, {})).status).toBe(409);

    const parc = await call("POST", "/v1/finance/entries", {
      direction: "out", description: "Ferramentas", amountCents: 10000, dueOn: "2026-10-10", installments: 3,
    });
    expect(parc.status).toBe(201);
    const parts = await admin.query(`select amount_cents, due_on::text from app.financial_entries where org_id = $1 and description like 'Ferramentas%' order by due_on`, [org]);
    expect(parts.rows.map((r) => r.amount_cents)).toEqual([3333, 3333, 3334]);
    expect(parts.rows.map((r) => r.due_on)).toEqual(["2026-10-10", "2026-11-10", "2026-12-10"]);

    const today = new Date().toISOString().slice(0, 10);
    const rec = await call("POST", "/v1/finance/entries", {
      direction: "out", description: "Internet", amountCents: 12000, dueOn: today, recurrence: "monthly", paidNow: true,
    });
    expect(rec.body.status).toBe("paid");
    const rules = await call("GET", "/v1/finance/recurring");
    expect(rules.body.data[0]).toMatchObject({ description: "Internet", frequency: "monthly", isActive: true });

    const dash = await call("GET", "/v1/dashboard");
    expect(dash.status).toBe(200);
    expect(dash.body.finance.receivedMonthCents).toBe(39000);
    expect(dash.body.finance.paidMonthCents).toBe(12000);
    expect(dash.body.orders.doneThisMonth).toBe(1);
    expect(dash.body.topServices[0]).toMatchObject({ name: "Instalação de tomada", quantity: 2, revenueCents: 36000 });
    expect(dash.body.averageRating).toBe(5);
    expect(dash.body.cashflow).toHaveLength(12);
  });

  it("agenda: duração do serviço, conflito de horário e recebível ao concluir", async () => {
    const startsAt = "2026-10-20T14:00:00-03:00";
    const a = await call("POST", "/v1/appointments", { customerId: customer, serviceId: service, staffId: staff, startsAt });
    expect(a.status).toBe(201);
    expect(new Date(a.body.endsAt).getTime() - new Date(a.body.startsAt).getTime()).toBe(60 * 60_000);
    expect(a.body.priceCents).toBe(18000);

    const clash = await call("POST", "/v1/appointments", { customerId: customer, staffId: staff, startsAt: "2026-10-20T14:30:00-03:00" });
    expect(clash.status).toBe(409);
    expect(clash.body.error.code).toBe("schedule_conflict");

    const done = await call("PATCH", `/v1/appointments/${a.body.id}`, { status: "done" });
    expect(done.body.status).toBe("done");
    const { rows } = await admin.query(`select amount_cents from app.financial_entries where appointment_id = $1`, [a.body.id]);
    expect(rows).toEqual([{ amount_cents: 18000 }]);

    const list = await call("GET", `/v1/appointments?from=2026-10-20T00:00:00-03:00&to=2026-10-21T00:00:00-03:00`);
    expect(list.body.data).toHaveLength(1);
  });

  it("formulário público: cria solicitação, reaproveita cliente e notifica", async () => {
    const form = await call("GET", `/v1/public/request-form/${slug}`, undefined, { anon: true });
    expect(form.status).toBe(200);
    expect(form.body.organization.name).toBe("Elétrica Rosa");
    expect(form.body.services.map((s: { name: string }) => s.name)).toEqual(["Instalação de tomada"]);

    const sent = await call("POST", `/v1/public/requests/${slug}`, {
      name: "Paulo Mendes", phone: "(21) 98888-7777", serviceId: service, description: "Tomada queimada na cozinha", website: "",
    }, { anon: true });
    expect(sent.status).toBe(201);
    expect(sent.body.number).toBe(2);

    const bot = await call("POST", `/v1/public/requests/${slug}`, { name: "Robô", phone: "21999999999", website: "spam.com" }, { anon: true });
    expect(bot.status).toBe(400);
    expect((await call("GET", "/v1/public/request-form/nao-existe", undefined, { anon: true })).status).toBe(404);

    const reqs = await call("GET", "/v1/service-orders?status=requested");
    expect(reqs.body.data[0]).toMatchObject({ status: "requested", source: "public_request", customer: { id: customer }, totalCents: 18000 });
    expect(reqs.body.counts.requested).toBe(1);

    const notes = await call("GET", "/v1/notifications");
    expect(notes.body.unread).toBe(1);
    expect(notes.body.data[0].title).toBe("Nova solicitação de serviço");
    await call("POST", "/v1/notifications/read-all");
    expect((await call("GET", "/v1/notifications")).body.unread).toBe(0);

    // aprovar a solicitação
    const approved = await call("POST", `/v1/service-orders/${reqs.body.data[0].id}/status`, { status: "open" });
    expect(approved.body.status).toBe("open");
  });

  it("empresa: renomear e configurar o fuso", async () => {
    const r = await call("PATCH", "/v1/organization", { name: "Elétrica Rosa & Filhos", timezone: "America/Manaus" });
    expect(r.body).toEqual({ name: "Elétrica Rosa & Filhos", timezone: "America/Manaus" });
    expect((await call("PATCH", "/v1/organization", { timezone: "Marte/Olympus" })).status).toBe(400);
    await call("PATCH", "/v1/organization", { name: "Elétrica Rosa", timezone: "America/Sao_Paulo" });
  });

  it("perfil: avatar personalizável salvo e devolvido no /me", async () => {
    const avatar = { style: "notionists", seed: "rosa-42", options: { hair: ["variant12"], glassesProbability: 100, backgroundColor: ["c8e6c9"] } };
    const r = await call("PATCH", "/v1/profile", { fullName: "Rosa Lima", avatar });
    expect(r.status).toBe(200);
    const me = await call("GET", "/v1/me");
    expect(me.body.user).toMatchObject({ fullName: "Rosa Lima", avatar });
    expect((await call("PATCH", "/v1/profile", { avatar: { style: "inexistente", seed: "x" } })).status).toBe(400);
  });

  it("IA: o modelo usa ferramentas, abre a OS e a ação sensível fica pendente", async () => {
    const st = await call("GET", "/v1/ai/status");
    expect(st.body).toEqual({ configured: true, provider: "fake", model: "fake-1" });

    const tc = (id: string, name: string, args: unknown) => ({
      content: null, tool_calls: [{ id, type: "function" as const, function: { name, arguments: JSON.stringify(args) } }],
    });
    llm.calls.length = 0;
    const script: ((m: unknown[]) => LlmResponse["message"])[] = [
      () => tc("c1", "search_customers", { query: "Paulo" }),
      () => tc("c2", "create_service_order", { customer_id: customer, items: [{ service_id: service }], description: "Pedido pelo chat" }),
      () => tc("c3", "cancel_service_order", { order_id: order, reason: "teste de aprovação" }),
      () => ({ content: "Abri a OS #4 para o Paulo. O cancelamento aguarda aprovação." }),
    ];
    let i = 0;
    (llm as { chat: LlmClient["chat"] }).chat = async ({ messages }) => {
      llm.calls.push(messages);
      return { message: script[i++]!(messages), usage: { inputTokens: 100, outputTokens: 20 }, model: "fake-1" };
    };

    const r = await call("POST", "/v1/ai/chat", { message: "Abre uma OS de tomada pro Paulo e cancela a antiga" });
    expect(r.status).toBe(200);
    expect(r.body.reply).toMatch(/OS #4/);
    expect(r.body.actions.map((a: { tool: string; status: string }) => `${a.tool}:${a.status}`)).toEqual([
      "search_customers:executed", "create_service_order:executed", "cancel_service_order:awaiting_approval",
    ]);

    // o resultado de cada ferramenta voltou para o modelo
    const lastCall = llm.calls.at(-1) as { role: string; content: string }[];
    expect(lastCall.filter((m) => m.role === "tool")).toHaveLength(3);
    expect(lastCall[0]!.content).toMatch(/Elétrica Rosa/);

    const aiOrders = await call("GET", "/v1/service-orders?q=Pedido");
    expect(aiOrders.body.data[0]).toMatchObject({ source: "ai", totalCents: 18000 });
    expect((await call("GET", `/v1/service-orders/${order}`)).body.status).toBe("done"); // ainda não cancelou

    const conv = await call("GET", `/v1/ai/conversations/${r.body.conversationId}`);
    expect(conv.body.data.map((m: { role: string }) => m.role)).toEqual(["user", "assistant"]);

    const { rows } = await admin.query(`select sum(input_tokens)::int as t from app.ai_messages where conversation_id = $1`, [r.body.conversationId]);
    expect(rows[0].t).toBe(400);
  });

  it("IA sem chave configurada responde com orientação clara", async () => {
    const bare = await buildApp({
      env: { NODE_ENV: "test", LOG_LEVEL: "silent", CORS_ORIGINS: [], RATE_LIMIT_MAX: 1000 },
      pool, verifyToken: createSupabaseVerifier({ supabaseUrl: SUPABASE_URL, jwtSecret: SECRET }),
    });
    const res = await bare.inject({
      method: "POST", url: "/v1/ai/chat", payload: { message: "oi" },
      headers: { authorization: `Bearer ${await token(owner)}`, "x-organization-id": org },
    });
    expect(res.statusCode).toBe(503);
    expect(JSON.parse(res.body).error.code).toBe("ai_not_configured");
    await bare.close();
  });
});
